<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_84d8e4234ad8da65ead528aca2feb7c0ec16b867fc9e73a841cdd2f377dc8b9a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_baedd3180d94c3136902f40c0dcc4fe072cab77eec20b3b9e0080fdf426603af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_baedd3180d94c3136902f40c0dcc4fe072cab77eec20b3b9e0080fdf426603af->enter($__internal_baedd3180d94c3136902f40c0dcc4fe072cab77eec20b3b9e0080fdf426603af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_121394e6a3773ab9baec4f1034a9e4ecb993b10d2ccfa7e29c80cdadd6209418 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_121394e6a3773ab9baec4f1034a9e4ecb993b10d2ccfa7e29c80cdadd6209418->enter($__internal_121394e6a3773ab9baec4f1034a9e4ecb993b10d2ccfa7e29c80cdadd6209418_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_baedd3180d94c3136902f40c0dcc4fe072cab77eec20b3b9e0080fdf426603af->leave($__internal_baedd3180d94c3136902f40c0dcc4fe072cab77eec20b3b9e0080fdf426603af_prof);

        
        $__internal_121394e6a3773ab9baec4f1034a9e4ecb993b10d2ccfa7e29c80cdadd6209418->leave($__internal_121394e6a3773ab9baec4f1034a9e4ecb993b10d2ccfa7e29c80cdadd6209418_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
