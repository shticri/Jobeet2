<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_a66f7feeccc64ec58a7671d7832396430d88f2e27434edb21459be8430e2f116 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7287ec574b71277ef4e51e9f7f918267757d04e8de16580b82a3f93cfeef820 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c7287ec574b71277ef4e51e9f7f918267757d04e8de16580b82a3f93cfeef820->enter($__internal_c7287ec574b71277ef4e51e9f7f918267757d04e8de16580b82a3f93cfeef820_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_8fd9630623c916ce71d136268268968e925f0fa12d3593202e9b5248bd9858f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fd9630623c916ce71d136268268968e925f0fa12d3593202e9b5248bd9858f8->enter($__internal_8fd9630623c916ce71d136268268968e925f0fa12d3593202e9b5248bd9858f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7287ec574b71277ef4e51e9f7f918267757d04e8de16580b82a3f93cfeef820->leave($__internal_c7287ec574b71277ef4e51e9f7f918267757d04e8de16580b82a3f93cfeef820_prof);

        
        $__internal_8fd9630623c916ce71d136268268968e925f0fa12d3593202e9b5248bd9858f8->leave($__internal_8fd9630623c916ce71d136268268968e925f0fa12d3593202e9b5248bd9858f8_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_347d716f4886fb170d91a27d2212a1bd154337f82e5617227ea01f8e8337bdca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_347d716f4886fb170d91a27d2212a1bd154337f82e5617227ea01f8e8337bdca->enter($__internal_347d716f4886fb170d91a27d2212a1bd154337f82e5617227ea01f8e8337bdca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_519e5a50bea88b9a97e1955cc99a557a835d1604200c92e2d3a389359469dcc8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_519e5a50bea88b9a97e1955cc99a557a835d1604200c92e2d3a389359469dcc8->enter($__internal_519e5a50bea88b9a97e1955cc99a557a835d1604200c92e2d3a389359469dcc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_519e5a50bea88b9a97e1955cc99a557a835d1604200c92e2d3a389359469dcc8->leave($__internal_519e5a50bea88b9a97e1955cc99a557a835d1604200c92e2d3a389359469dcc8_prof);

        
        $__internal_347d716f4886fb170d91a27d2212a1bd154337f82e5617227ea01f8e8337bdca->leave($__internal_347d716f4886fb170d91a27d2212a1bd154337f82e5617227ea01f8e8337bdca_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_86603a0fcb403988f6c060ba8aa694bb4af6ca10a235a686293f85b0f5476d1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_86603a0fcb403988f6c060ba8aa694bb4af6ca10a235a686293f85b0f5476d1d->enter($__internal_86603a0fcb403988f6c060ba8aa694bb4af6ca10a235a686293f85b0f5476d1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_314bb163b1c891ea1f8c1ae9235a1a900c1c79c7effc8641fbde1b73c902e27b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_314bb163b1c891ea1f8c1ae9235a1a900c1c79c7effc8641fbde1b73c902e27b->enter($__internal_314bb163b1c891ea1f8c1ae9235a1a900c1c79c7effc8641fbde1b73c902e27b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_314bb163b1c891ea1f8c1ae9235a1a900c1c79c7effc8641fbde1b73c902e27b->leave($__internal_314bb163b1c891ea1f8c1ae9235a1a900c1c79c7effc8641fbde1b73c902e27b_prof);

        
        $__internal_86603a0fcb403988f6c060ba8aa694bb4af6ca10a235a686293f85b0f5476d1d->leave($__internal_86603a0fcb403988f6c060ba8aa694bb4af6ca10a235a686293f85b0f5476d1d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_6bab139a87ffaf1c72ed8dd7d24f3dccc726cd07de02326d7019e0d8943df8dc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bab139a87ffaf1c72ed8dd7d24f3dccc726cd07de02326d7019e0d8943df8dc->enter($__internal_6bab139a87ffaf1c72ed8dd7d24f3dccc726cd07de02326d7019e0d8943df8dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_8bf74b96c0062dcbf6707c1f91dd5b2841136c2b58556289b9f4ac923fa6527f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bf74b96c0062dcbf6707c1f91dd5b2841136c2b58556289b9f4ac923fa6527f->enter($__internal_8bf74b96c0062dcbf6707c1f91dd5b2841136c2b58556289b9f4ac923fa6527f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_8bf74b96c0062dcbf6707c1f91dd5b2841136c2b58556289b9f4ac923fa6527f->leave($__internal_8bf74b96c0062dcbf6707c1f91dd5b2841136c2b58556289b9f4ac923fa6527f_prof);

        
        $__internal_6bab139a87ffaf1c72ed8dd7d24f3dccc726cd07de02326d7019e0d8943df8dc->leave($__internal_6bab139a87ffaf1c72ed8dd7d24f3dccc726cd07de02326d7019e0d8943df8dc_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
