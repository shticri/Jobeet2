<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_1baeefbcc2cca536797ec4095c6152b3354293a582477aa0cf923dae9a138d9d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c88aa45e476c74f900c38275e4a2fd54162374f3faaf9216284d3e72587ec65f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c88aa45e476c74f900c38275e4a2fd54162374f3faaf9216284d3e72587ec65f->enter($__internal_c88aa45e476c74f900c38275e4a2fd54162374f3faaf9216284d3e72587ec65f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_3cc7f131453761788dff0bc8ea48b29991d4278baba3e428d047d5cd646f35b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cc7f131453761788dff0bc8ea48b29991d4278baba3e428d047d5cd646f35b0->enter($__internal_3cc7f131453761788dff0bc8ea48b29991d4278baba3e428d047d5cd646f35b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_c88aa45e476c74f900c38275e4a2fd54162374f3faaf9216284d3e72587ec65f->leave($__internal_c88aa45e476c74f900c38275e4a2fd54162374f3faaf9216284d3e72587ec65f_prof);

        
        $__internal_3cc7f131453761788dff0bc8ea48b29991d4278baba3e428d047d5cd646f35b0->leave($__internal_3cc7f131453761788dff0bc8ea48b29991d4278baba3e428d047d5cd646f35b0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
