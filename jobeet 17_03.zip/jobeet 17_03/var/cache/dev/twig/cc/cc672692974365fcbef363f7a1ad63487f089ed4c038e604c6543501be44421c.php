<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_ec2d83d16d6b347dcd6335d25ed200b86bfcbd18655fa61b495f7406c4b46096 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bd5fdc1a2fb93dd35f7a370d3425bb5d87e08bdb717d79264bd921399109d232 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd5fdc1a2fb93dd35f7a370d3425bb5d87e08bdb717d79264bd921399109d232->enter($__internal_bd5fdc1a2fb93dd35f7a370d3425bb5d87e08bdb717d79264bd921399109d232_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_fc082be59d12d738d50ce69be83f9e07e032ccb6cc4b04a04571db28adf2c80b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc082be59d12d738d50ce69be83f9e07e032ccb6cc4b04a04571db28adf2c80b->enter($__internal_fc082be59d12d738d50ce69be83f9e07e032ccb6cc4b04a04571db28adf2c80b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_bd5fdc1a2fb93dd35f7a370d3425bb5d87e08bdb717d79264bd921399109d232->leave($__internal_bd5fdc1a2fb93dd35f7a370d3425bb5d87e08bdb717d79264bd921399109d232_prof);

        
        $__internal_fc082be59d12d738d50ce69be83f9e07e032ccb6cc4b04a04571db28adf2c80b->leave($__internal_fc082be59d12d738d50ce69be83f9e07e032ccb6cc4b04a04571db28adf2c80b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Icon\\forward.svg");
    }
}
