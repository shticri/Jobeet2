<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_b9722f19ed09fef2b51b2dd70e6c854f2e25abf70a6d3bbb338dcfaddfc89139 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_92566344acb06105928af8c759a8f18987dece7b0a9a34a650b8595ab88a16da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_92566344acb06105928af8c759a8f18987dece7b0a9a34a650b8595ab88a16da->enter($__internal_92566344acb06105928af8c759a8f18987dece7b0a9a34a650b8595ab88a16da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_85e2e60bb2aa97619563b5015405c7fbb92c24a1dce0f270940ff1ac059ace17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85e2e60bb2aa97619563b5015405c7fbb92c24a1dce0f270940ff1ac059ace17->enter($__internal_85e2e60bb2aa97619563b5015405c7fbb92c24a1dce0f270940ff1ac059ace17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_92566344acb06105928af8c759a8f18987dece7b0a9a34a650b8595ab88a16da->leave($__internal_92566344acb06105928af8c759a8f18987dece7b0a9a34a650b8595ab88a16da_prof);

        
        $__internal_85e2e60bb2aa97619563b5015405c7fbb92c24a1dce0f270940ff1ac059ace17->leave($__internal_85e2e60bb2aa97619563b5015405c7fbb92c24a1dce0f270940ff1ac059ace17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
