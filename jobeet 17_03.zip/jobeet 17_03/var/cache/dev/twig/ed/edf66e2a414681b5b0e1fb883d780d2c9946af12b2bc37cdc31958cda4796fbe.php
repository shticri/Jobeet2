<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_f5da74cc831cae1f4e2c8c48eb12db58e79b64c60996dd8bb885dd0b9b2b762f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0cd89b431bb7a0a37c9f5df993fd9652a040a060f95a6b2ed997dc5f1d7319b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d0cd89b431bb7a0a37c9f5df993fd9652a040a060f95a6b2ed997dc5f1d7319b->enter($__internal_d0cd89b431bb7a0a37c9f5df993fd9652a040a060f95a6b2ed997dc5f1d7319b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_625ec056477fb99223f9c138a8f415f62da05222124329db4dc1c70c9392cfc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_625ec056477fb99223f9c138a8f415f62da05222124329db4dc1c70c9392cfc0->enter($__internal_625ec056477fb99223f9c138a8f415f62da05222124329db4dc1c70c9392cfc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_d0cd89b431bb7a0a37c9f5df993fd9652a040a060f95a6b2ed997dc5f1d7319b->leave($__internal_d0cd89b431bb7a0a37c9f5df993fd9652a040a060f95a6b2ed997dc5f1d7319b_prof);

        
        $__internal_625ec056477fb99223f9c138a8f415f62da05222124329db4dc1c70c9392cfc0->leave($__internal_625ec056477fb99223f9c138a8f415f62da05222124329db4dc1c70c9392cfc0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_widget.html.php");
    }
}
