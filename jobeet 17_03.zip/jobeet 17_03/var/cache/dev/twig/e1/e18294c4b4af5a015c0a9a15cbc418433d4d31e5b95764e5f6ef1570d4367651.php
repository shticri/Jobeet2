<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_07e48d0a50392af885080e28f6130fa0a71811d01c3e6c9ab444d7df40a149e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6426dec0d9584206069d985d4e9b0a86c7dbb107d59137c97149896235b481a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6426dec0d9584206069d985d4e9b0a86c7dbb107d59137c97149896235b481a7->enter($__internal_6426dec0d9584206069d985d4e9b0a86c7dbb107d59137c97149896235b481a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_9b8ea9f901b12c6085d5785874ae0bf5bf5dc7aa3dc8eae140cb7b884642a169 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b8ea9f901b12c6085d5785874ae0bf5bf5dc7aa3dc8eae140cb7b884642a169->enter($__internal_9b8ea9f901b12c6085d5785874ae0bf5bf5dc7aa3dc8eae140cb7b884642a169_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_6426dec0d9584206069d985d4e9b0a86c7dbb107d59137c97149896235b481a7->leave($__internal_6426dec0d9584206069d985d4e9b0a86c7dbb107d59137c97149896235b481a7_prof);

        
        $__internal_9b8ea9f901b12c6085d5785874ae0bf5bf5dc7aa3dc8eae140cb7b884642a169->leave($__internal_9b8ea9f901b12c6085d5785874ae0bf5bf5dc7aa3dc8eae140cb7b884642a169_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
