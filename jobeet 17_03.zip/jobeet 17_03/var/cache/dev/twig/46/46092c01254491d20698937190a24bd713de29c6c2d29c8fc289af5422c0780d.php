<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_bc4aa508fa507f6e799d778c57026a449a85d83d46c32467104ce2b28c814a1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7eeb5c2cd1ba7641a7bc19848e3d1d8f617c4ea9168aa7ca5ff6087787702617 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7eeb5c2cd1ba7641a7bc19848e3d1d8f617c4ea9168aa7ca5ff6087787702617->enter($__internal_7eeb5c2cd1ba7641a7bc19848e3d1d8f617c4ea9168aa7ca5ff6087787702617_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_2fba2d2a31135c0eb592887dfd0108af3afb2253d7cdee3c5cca4b3bf6531306 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fba2d2a31135c0eb592887dfd0108af3afb2253d7cdee3c5cca4b3bf6531306->enter($__internal_2fba2d2a31135c0eb592887dfd0108af3afb2253d7cdee3c5cca4b3bf6531306_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_7eeb5c2cd1ba7641a7bc19848e3d1d8f617c4ea9168aa7ca5ff6087787702617->leave($__internal_7eeb5c2cd1ba7641a7bc19848e3d1d8f617c4ea9168aa7ca5ff6087787702617_prof);

        
        $__internal_2fba2d2a31135c0eb592887dfd0108af3afb2253d7cdee3c5cca4b3bf6531306->leave($__internal_2fba2d2a31135c0eb592887dfd0108af3afb2253d7cdee3c5cca4b3bf6531306_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.atom.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
