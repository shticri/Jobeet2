<?php

/* :job:list.html.twig */
class __TwigTemplate_6f92960f81579cf1ebfdcd16b96fc4eab17e8368321fbc12b8d30a4be16d7a86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d57f5952973e579d25d0d634dfe15f40be127b92a70bc085591db2d187b88fd5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d57f5952973e579d25d0d634dfe15f40be127b92a70bc085591db2d187b88fd5->enter($__internal_d57f5952973e579d25d0d634dfe15f40be127b92a70bc085591db2d187b88fd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:list.html.twig"));

        $__internal_a8b3926179aaf186b7d955836483e45c626ebb5a8a44bc41a1d5e872e728cee2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8b3926179aaf186b7d955836483e45c626ebb5a8a44bc41a1d5e872e728cee2->enter($__internal_a8b3926179aaf186b7d955836483e45c626ebb5a8a44bc41a1d5e872e728cee2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:list.html.twig"));

        // line 1
        echo "<table class=\"jobs\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "activejobs", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["job"]) {
            // line 3
            echo "      <tr class=\"";
            echo twig_escape_filter($this->env, twig_cycle(array(0 => "even", 1 => "odd"), $this->getAttribute($context["loop"], "index", array())), "html", null, true);
            echo "\">
        <td class=\"location\">";
            // line 4
            echo twig_escape_filter($this->env, $this->getAttribute($context["job"], "location", array()), "html", null, true);
            echo "</td>
        <td class=\"position\">
          <a href=\"";
            // line 6
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_show", array("id" => $this->getAttribute($context["job"], "id", array()), "company" => $this->getAttribute($context["job"], "companySlug", array()), "location" => $this->getAttribute($context["job"], "locationSlug", array()), "position" => $this->getAttribute($context["job"], "positionSlug", array()))), "html", null, true);
            echo "\">
            ";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute($context["job"], "position", array()), "html", null, true);
            echo "
          </a>
        </td>
        <td class=\"company\">";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["job"], "company", array()), "html", null, true);
            echo "</td>
      </tr>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['job'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo "  </table>
";
        
        $__internal_d57f5952973e579d25d0d634dfe15f40be127b92a70bc085591db2d187b88fd5->leave($__internal_d57f5952973e579d25d0d634dfe15f40be127b92a70bc085591db2d187b88fd5_prof);

        
        $__internal_a8b3926179aaf186b7d955836483e45c626ebb5a8a44bc41a1d5e872e728cee2->leave($__internal_a8b3926179aaf186b7d955836483e45c626ebb5a8a44bc41a1d5e872e728cee2_prof);

    }

    public function getTemplateName()
    {
        return ":job:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 13,  65 => 10,  59 => 7,  55 => 6,  50 => 4,  45 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table class=\"jobs\">
    {% for job in category.activejobs %}
      <tr class=\"{{ cycle(['even', 'odd'], loop.index) }}\">
        <td class=\"location\">{{ job.location }}</td>
        <td class=\"position\">
          <a href=\"{{ path('job_show', { 'id': job.id, 'company': job.companySlug, 'location': job.locationSlug, 'position': job.positionSlug }) }}\">
            {{ job.position }}
          </a>
        </td>
        <td class=\"company\">{{ job.company }}</td>
      </tr>
    {% endfor %}
  </table>
", ":job:list.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/job/list.html.twig");
    }
}
