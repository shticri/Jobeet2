<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_ec6d46555e2034d392cd4f045ddf46fc6f02ca06ac3658e287a7488bdcb299c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de0b4856e37122bb532d5456224261d16a2793897a35c66e993a51ee7cad7751 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de0b4856e37122bb532d5456224261d16a2793897a35c66e993a51ee7cad7751->enter($__internal_de0b4856e37122bb532d5456224261d16a2793897a35c66e993a51ee7cad7751_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_c7eb2d2aa252be89fb2b0bf9e82d09c68230111981da34d0593284c3bda6ad0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7eb2d2aa252be89fb2b0bf9e82d09c68230111981da34d0593284c3bda6ad0a->enter($__internal_c7eb2d2aa252be89fb2b0bf9e82d09c68230111981da34d0593284c3bda6ad0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_de0b4856e37122bb532d5456224261d16a2793897a35c66e993a51ee7cad7751->leave($__internal_de0b4856e37122bb532d5456224261d16a2793897a35c66e993a51ee7cad7751_prof);

        
        $__internal_c7eb2d2aa252be89fb2b0bf9e82d09c68230111981da34d0593284c3bda6ad0a->leave($__internal_c7eb2d2aa252be89fb2b0bf9e82d09c68230111981da34d0593284c3bda6ad0a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_errors.html.php");
    }
}
