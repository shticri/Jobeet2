<?php

/* category/new.html.twig */
class __TwigTemplate_bc170c050ec5040584fdf4651e5cfed7d17f47a8a2d3d8497e20727a70438941 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d9f33f475fbb39b8a57aeebbea0cd12f8c9c2018e1ea590a070cf68cae24d5e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d9f33f475fbb39b8a57aeebbea0cd12f8c9c2018e1ea590a070cf68cae24d5e->enter($__internal_7d9f33f475fbb39b8a57aeebbea0cd12f8c9c2018e1ea590a070cf68cae24d5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/new.html.twig"));

        $__internal_76ffffac94b534503f3727d0f8b7a0be580124dd347758a6440da4d61058582f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76ffffac94b534503f3727d0f8b7a0be580124dd347758a6440da4d61058582f->enter($__internal_76ffffac94b534503f3727d0f8b7a0be580124dd347758a6440da4d61058582f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7d9f33f475fbb39b8a57aeebbea0cd12f8c9c2018e1ea590a070cf68cae24d5e->leave($__internal_7d9f33f475fbb39b8a57aeebbea0cd12f8c9c2018e1ea590a070cf68cae24d5e_prof);

        
        $__internal_76ffffac94b534503f3727d0f8b7a0be580124dd347758a6440da4d61058582f->leave($__internal_76ffffac94b534503f3727d0f8b7a0be580124dd347758a6440da4d61058582f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6f485500a3d92843e1a796d929cc3e8b058efd8120750693e926e5cead7c9b9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6f485500a3d92843e1a796d929cc3e8b058efd8120750693e926e5cead7c9b9e->enter($__internal_6f485500a3d92843e1a796d929cc3e8b058efd8120750693e926e5cead7c9b9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_28d4689e506f0124080b8bfc0ca6bb5c64c01d5fb535906b2034e58f715b9291 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_28d4689e506f0124080b8bfc0ca6bb5c64c01d5fb535906b2034e58f715b9291->enter($__internal_28d4689e506f0124080b8bfc0ca6bb5c64c01d5fb535906b2034e58f715b9291_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Category creation</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_28d4689e506f0124080b8bfc0ca6bb5c64c01d5fb535906b2034e58f715b9291->leave($__internal_28d4689e506f0124080b8bfc0ca6bb5c64c01d5fb535906b2034e58f715b9291_prof);

        
        $__internal_6f485500a3d92843e1a796d929cc3e8b058efd8120750693e926e5cead7c9b9e->leave($__internal_6f485500a3d92843e1a796d929cc3e8b058efd8120750693e926e5cead7c9b9e_prof);

    }

    public function getTemplateName()
    {
        return "category/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Category creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('category_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "category/new.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\category\\new.html.twig");
    }
}
