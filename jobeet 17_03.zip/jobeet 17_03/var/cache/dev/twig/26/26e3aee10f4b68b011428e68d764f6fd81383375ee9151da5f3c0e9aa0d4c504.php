<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_dbe3596093799abfcc846c93c6aef5fe75cbd6a3fa3eb6d816cf5d49cfd6e8c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_376895fd59dcfcfa11fcbc4c3f31535c4cdf2e92fc4076682887155357c3863d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_376895fd59dcfcfa11fcbc4c3f31535c4cdf2e92fc4076682887155357c3863d->enter($__internal_376895fd59dcfcfa11fcbc4c3f31535c4cdf2e92fc4076682887155357c3863d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_ce0dd4f4cc898c788c5b2f4815364aa9cb382855059ce3bbc382febb4f6a53e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce0dd4f4cc898c788c5b2f4815364aa9cb382855059ce3bbc382febb4f6a53e2->enter($__internal_ce0dd4f4cc898c788c5b2f4815364aa9cb382855059ce3bbc382febb4f6a53e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_376895fd59dcfcfa11fcbc4c3f31535c4cdf2e92fc4076682887155357c3863d->leave($__internal_376895fd59dcfcfa11fcbc4c3f31535c4cdf2e92fc4076682887155357c3863d_prof);

        
        $__internal_ce0dd4f4cc898c788c5b2f4815364aa9cb382855059ce3bbc382febb4f6a53e2->leave($__internal_ce0dd4f4cc898c788c5b2f4815364aa9cb382855059ce3bbc382febb4f6a53e2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\submit_widget.html.php");
    }
}
