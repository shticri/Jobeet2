<?php

/* base.html.twig */
class __TwigTemplate_cacf579b6000f723f17482e8fbcf34b983262632f4c235fe52e12381e458265c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_124204fd45d801c4b2799e6d45958ed0db074bb782b41328bb463c4b90beb223 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_124204fd45d801c4b2799e6d45958ed0db074bb782b41328bb463c4b90beb223->enter($__internal_124204fd45d801c4b2799e6d45958ed0db074bb782b41328bb463c4b90beb223_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2fa6a8654c2fe675b1c7a0f093bdff5dc7c404d294f36b2f40d3f59897caa3ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fa6a8654c2fe675b1c7a0f093bdff5dc7c404d294f36b2f40d3f59897caa3ef->enter($__internal_2fa6a8654c2fe675b1c7a0f093bdff5dc7c404d294f36b2f40d3f59897caa3ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <title>
      ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 8
        echo "    </title>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 15
        echo "    <link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/favicon.ico"), "html", null, true);
        echo "\" />
  </head>
  <body>
    <div id=\"container\">
      <div id=\"header\">
        <div class=\"content\">
          <h1><a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_index");
        echo "\">
            <img src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/logo.jpg"), "html", null, true);
        echo "\" alt=\"Jobeet Job Board\" />
          </a></h1>
 
          <div id=\"sub_header\">
            <div class=\"post\">
              <h2>Ask for people</h2>
              <div>
                <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_new");
        echo "\">Post a Job</a>
              </div>
            </div>
 
            <div class=\"search\">
              <h2>Ask for a job</h2>
              <form action=\"\" method=\"get\">
                <input type=\"text\" name=\"keywords\" id=\"search_keywords\" />
                <input type=\"submit\" value=\"search\" />
                <div class=\"help\">
                  Enter some keywords (city, country, position, ...)
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
 
      <div id=\"content\">
        ";
        // line 48
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "FlashBag", array()), "get", array(0 => "notice"), "method")) {
            // line 49
            echo "          <div class=\"flash_notice\">
            ";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flash", array(0 => "notice"), "method"), "html", null, true);
            echo "
          </div>
        ";
        }
        // line 53
        echo " 
        ";
        // line 54
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "FlashBag", array()), "has", array(0 => "error"), "method")) {
            // line 55
            echo "          <div class=\"flash_error\">
            ";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flash", array(0 => "error"), "method"), "html", null, true);
            echo "
          </div>
        ";
        }
        // line 59
        echo " 
        <div class=\"content\">
            ";
        // line 61
        $this->displayBlock('content', $context, $blocks);
        // line 63
        echo "        </div>
      </div>
 
      <div id=\"footer\">
        <div class=\"content\">
          <span class=\"symfony\">
            <img src=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/jobeet-mini.png"), "html", null, true);
        echo "\" />
            powered by <a href=\"http://www.symfony.com/\">
              <img src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/symfony.gif"), "html", null, true);
        echo "\" alt=\"symfony framework\" />
            </a>
          </span>
          <ul>
            <li><a href=\"\">About Jobeet</a></li>
            <li class=\"feed\"><a href=\"\">Full feed</a></li>
            <li><a href=\"\">Jobeet API</a></li>
            <li class=\"last\"><a href=\"\">Affiliates</a></li>
          </ul>
        </div>
      </div>
    </div>
  </body>
</html>
";
        
        $__internal_124204fd45d801c4b2799e6d45958ed0db074bb782b41328bb463c4b90beb223->leave($__internal_124204fd45d801c4b2799e6d45958ed0db074bb782b41328bb463c4b90beb223_prof);

        
        $__internal_2fa6a8654c2fe675b1c7a0f093bdff5dc7c404d294f36b2f40d3f59897caa3ef->leave($__internal_2fa6a8654c2fe675b1c7a0f093bdff5dc7c404d294f36b2f40d3f59897caa3ef_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_642814fea0a3e9b4e168a744264eea24ca908c3a72f6882d65dff2454deb57f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_642814fea0a3e9b4e168a744264eea24ca908c3a72f6882d65dff2454deb57f6->enter($__internal_642814fea0a3e9b4e168a744264eea24ca908c3a72f6882d65dff2454deb57f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_6b846e34182588a06c3f46abc4ee09fb9b942c681dd3732a8d1420bfff64cda7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b846e34182588a06c3f46abc4ee09fb9b942c681dd3732a8d1420bfff64cda7->enter($__internal_6b846e34182588a06c3f46abc4ee09fb9b942c681dd3732a8d1420bfff64cda7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "        Jobeet - Your best job board
      ";
        
        $__internal_6b846e34182588a06c3f46abc4ee09fb9b942c681dd3732a8d1420bfff64cda7->leave($__internal_6b846e34182588a06c3f46abc4ee09fb9b942c681dd3732a8d1420bfff64cda7_prof);

        
        $__internal_642814fea0a3e9b4e168a744264eea24ca908c3a72f6882d65dff2454deb57f6->leave($__internal_642814fea0a3e9b4e168a744264eea24ca908c3a72f6882d65dff2454deb57f6_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_dba7c67cadbcb5695720a7d803c641c11c15b709f8a39049adc049e87b3c0998 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dba7c67cadbcb5695720a7d803c641c11c15b709f8a39049adc049e87b3c0998->enter($__internal_dba7c67cadbcb5695720a7d803c641c11c15b709f8a39049adc049e87b3c0998_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_a6edcd486e3db458bec2aeb27f825d446324629b0aba9587e14f133ee617950a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6edcd486e3db458bec2aeb27f825d446324629b0aba9587e14f133ee617950a->enter($__internal_a6edcd486e3db458bec2aeb27f825d446324629b0aba9587e14f133ee617950a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 11
        echo "      <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        
        $__internal_a6edcd486e3db458bec2aeb27f825d446324629b0aba9587e14f133ee617950a->leave($__internal_a6edcd486e3db458bec2aeb27f825d446324629b0aba9587e14f133ee617950a_prof);

        
        $__internal_dba7c67cadbcb5695720a7d803c641c11c15b709f8a39049adc049e87b3c0998->leave($__internal_dba7c67cadbcb5695720a7d803c641c11c15b709f8a39049adc049e87b3c0998_prof);

    }

    // line 13
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d86bc4be79e8705060675ffd00d079721c5155acd177b8ce4de5c1b12f8e8bda = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d86bc4be79e8705060675ffd00d079721c5155acd177b8ce4de5c1b12f8e8bda->enter($__internal_d86bc4be79e8705060675ffd00d079721c5155acd177b8ce4de5c1b12f8e8bda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_bf2f1ada398a81b2a78ef3100a86a5367be413523999530311deed98fde1d32c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf2f1ada398a81b2a78ef3100a86a5367be413523999530311deed98fde1d32c->enter($__internal_bf2f1ada398a81b2a78ef3100a86a5367be413523999530311deed98fde1d32c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 14
        echo "    ";
        
        $__internal_bf2f1ada398a81b2a78ef3100a86a5367be413523999530311deed98fde1d32c->leave($__internal_bf2f1ada398a81b2a78ef3100a86a5367be413523999530311deed98fde1d32c_prof);

        
        $__internal_d86bc4be79e8705060675ffd00d079721c5155acd177b8ce4de5c1b12f8e8bda->leave($__internal_d86bc4be79e8705060675ffd00d079721c5155acd177b8ce4de5c1b12f8e8bda_prof);

    }

    // line 61
    public function block_content($context, array $blocks = array())
    {
        $__internal_e16336f17c409addbc6cb2874213afa5e729134d2489677701fe06280a2419c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e16336f17c409addbc6cb2874213afa5e729134d2489677701fe06280a2419c4->enter($__internal_e16336f17c409addbc6cb2874213afa5e729134d2489677701fe06280a2419c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_57342e686d26c154aa855fb99341a5172a02868723d55a6aa303eb305b295d5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57342e686d26c154aa855fb99341a5172a02868723d55a6aa303eb305b295d5e->enter($__internal_57342e686d26c154aa855fb99341a5172a02868723d55a6aa303eb305b295d5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 62
        echo "            ";
        
        $__internal_57342e686d26c154aa855fb99341a5172a02868723d55a6aa303eb305b295d5e->leave($__internal_57342e686d26c154aa855fb99341a5172a02868723d55a6aa303eb305b295d5e_prof);

        
        $__internal_e16336f17c409addbc6cb2874213afa5e729134d2489677701fe06280a2419c4->leave($__internal_e16336f17c409addbc6cb2874213afa5e729134d2489677701fe06280a2419c4_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  231 => 62,  222 => 61,  212 => 14,  203 => 13,  190 => 11,  181 => 10,  170 => 6,  161 => 5,  136 => 71,  131 => 69,  123 => 63,  121 => 61,  117 => 59,  111 => 56,  108 => 55,  106 => 54,  103 => 53,  97 => 50,  94 => 49,  92 => 48,  70 => 29,  60 => 22,  56 => 21,  46 => 15,  43 => 13,  41 => 10,  37 => 8,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <title>
      {% block title %}
        Jobeet - Your best job board
      {% endblock %}
    </title>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    {% block stylesheets %}
      <link rel=\"stylesheet\" href=\"{{ asset('public/css/main.css') }}\" type=\"text/css\" media=\"all\" />
    {% endblock %}
    {% block javascripts %}
    {% endblock %}
    <link rel=\"shortcut icon\" href=\"{{ asset('public/images/favicon.ico') }}\" />
  </head>
  <body>
    <div id=\"container\">
      <div id=\"header\">
        <div class=\"content\">
          <h1><a href=\"{{ path('job_index') }}\">
            <img src=\"{{ asset('public/images/logo.jpg') }}\" alt=\"Jobeet Job Board\" />
          </a></h1>
 
          <div id=\"sub_header\">
            <div class=\"post\">
              <h2>Ask for people</h2>
              <div>
                <a href=\"{{ path('job_new') }}\">Post a Job</a>
              </div>
            </div>
 
            <div class=\"search\">
              <h2>Ask for a job</h2>
              <form action=\"\" method=\"get\">
                <input type=\"text\" name=\"keywords\" id=\"search_keywords\" />
                <input type=\"submit\" value=\"search\" />
                <div class=\"help\">
                  Enter some keywords (city, country, position, ...)
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
 
      <div id=\"content\">
        {% if app.session.FlashBag.get('notice') %}
          <div class=\"flash_notice\">
            {{ app.session.flash('notice') }}
          </div>
        {% endif %}
 
        {% if app.session.FlashBag.has('error') %}
          <div class=\"flash_error\">
            {{ app.session.flash('error') }}
          </div>
        {% endif %}
 
        <div class=\"content\">
            {% block content %}
            {% endblock %}
        </div>
      </div>
 
      <div id=\"footer\">
        <div class=\"content\">
          <span class=\"symfony\">
            <img src=\"{{ asset('public/images/jobeet-mini.png') }}\" />
            powered by <a href=\"http://www.symfony.com/\">
              <img src=\"{{ asset('public/images/symfony.gif') }}\" alt=\"symfony framework\" />
            </a>
          </span>
          <ul>
            <li><a href=\"\">About Jobeet</a></li>
            <li class=\"feed\"><a href=\"\">Full feed</a></li>
            <li><a href=\"\">Jobeet API</a></li>
            <li class=\"last\"><a href=\"\">Affiliates</a></li>
          </ul>
        </div>
      </div>
    </div>
  </body>
</html>
", "base.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\base.html.twig");
    }
}
