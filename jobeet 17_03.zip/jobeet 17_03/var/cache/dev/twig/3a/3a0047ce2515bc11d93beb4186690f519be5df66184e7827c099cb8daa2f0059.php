<?php

/* :affiliate:index.html.twig */
class __TwigTemplate_a66ce77ad44b0780a178bd95318cb8e33bba613b6e2c7a75817cb903dad8862b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":affiliate:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_da1f106a15d629d6e599397c69898012f68579487afef881423ea1566de6dbd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_da1f106a15d629d6e599397c69898012f68579487afef881423ea1566de6dbd0->enter($__internal_da1f106a15d629d6e599397c69898012f68579487afef881423ea1566de6dbd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":affiliate:index.html.twig"));

        $__internal_c26ede7223aaf15e4eefd87e7d38cf1d4d49d3d285ad17d3d47fe67d6424fbc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c26ede7223aaf15e4eefd87e7d38cf1d4d49d3d285ad17d3d47fe67d6424fbc0->enter($__internal_c26ede7223aaf15e4eefd87e7d38cf1d4d49d3d285ad17d3d47fe67d6424fbc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":affiliate:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_da1f106a15d629d6e599397c69898012f68579487afef881423ea1566de6dbd0->leave($__internal_da1f106a15d629d6e599397c69898012f68579487afef881423ea1566de6dbd0_prof);

        
        $__internal_c26ede7223aaf15e4eefd87e7d38cf1d4d49d3d285ad17d3d47fe67d6424fbc0->leave($__internal_c26ede7223aaf15e4eefd87e7d38cf1d4d49d3d285ad17d3d47fe67d6424fbc0_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_a80e9d5240ca8bde190b0ed13527c8e6fb87c1ebcef580363a739a6d7e13b4fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a80e9d5240ca8bde190b0ed13527c8e6fb87c1ebcef580363a739a6d7e13b4fc->enter($__internal_a80e9d5240ca8bde190b0ed13527c8e6fb87c1ebcef580363a739a6d7e13b4fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c91034d4a74927fcac70244ac1ffb362bfc0d30012083816603687758e3064d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c91034d4a74927fcac70244ac1ffb362bfc0d30012083816603687758e3064d3->enter($__internal_c91034d4a74927fcac70244ac1ffb362bfc0d30012083816603687758e3064d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Affiliates list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Url</th>
                <th>Email</th>
                <th>Token</th>
                <th>Isactive</th>
                <th>Createdat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["affiliates"]) ? $context["affiliates"] : $this->getContext($context, "affiliates")));
        foreach ($context['_seq'] as $context["_key"] => $context["affiliate"]) {
            // line 20
            echo "            <tr>
                <td><a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_show", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "url", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "token", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 25
            if ($this->getAttribute($context["affiliate"], "isActive", array())) {
                echo "Yes";
            } else {
                echo "No";
            }
            echo "</td>
                <td>";
            // line 26
            if ($this->getAttribute($context["affiliate"], "createdAt", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["affiliate"], "createdAt", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_show", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_edit", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['affiliate'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_new");
        echo "\">Create a new affiliate</a>
        </li>
    </ul>
";
        
        $__internal_c91034d4a74927fcac70244ac1ffb362bfc0d30012083816603687758e3064d3->leave($__internal_c91034d4a74927fcac70244ac1ffb362bfc0d30012083816603687758e3064d3_prof);

        
        $__internal_a80e9d5240ca8bde190b0ed13527c8e6fb87c1ebcef580363a739a6d7e13b4fc->leave($__internal_a80e9d5240ca8bde190b0ed13527c8e6fb87c1ebcef580363a739a6d7e13b4fc_prof);

    }

    public function getTemplateName()
    {
        return ":affiliate:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 44,  126 => 39,  114 => 33,  108 => 30,  99 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  73 => 21,  70 => 20,  66 => 19,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Affiliates list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Url</th>
                <th>Email</th>
                <th>Token</th>
                <th>Isactive</th>
                <th>Createdat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for affiliate in affiliates %}
            <tr>
                <td><a href=\"{{ path('affiliate_show', { 'id': affiliate.id }) }}\">{{ affiliate.id }}</a></td>
                <td>{{ affiliate.url }}</td>
                <td>{{ affiliate.email }}</td>
                <td>{{ affiliate.token }}</td>
                <td>{% if affiliate.isActive %}Yes{% else %}No{% endif %}</td>
                <td>{% if affiliate.createdAt %}{{ affiliate.createdAt|date('Y-m-d H:i:s') }}{% endif %}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('affiliate_show', { 'id': affiliate.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('affiliate_edit', { 'id': affiliate.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('affiliate_new') }}\">Create a new affiliate</a>
        </li>
    </ul>
{% endblock %}
", ":affiliate:index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/affiliate/index.html.twig");
    }
}
