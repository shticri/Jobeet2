<?php

/* affiliate/show.html.twig */
class __TwigTemplate_7ed8e076750b50081cd8cadb11995b24c94778aba93d5ebe0a1cc5910805baed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "affiliate/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bd3505635d5431093ebdd0c714ed7a1b1244320d9f568c586f7f95f970c0ce9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bd3505635d5431093ebdd0c714ed7a1b1244320d9f568c586f7f95f970c0ce9->enter($__internal_8bd3505635d5431093ebdd0c714ed7a1b1244320d9f568c586f7f95f970c0ce9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/show.html.twig"));

        $__internal_560d6f761047e3b9ff4517a6ce072517233e45306599b603ddabdc6888d4f733 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_560d6f761047e3b9ff4517a6ce072517233e45306599b603ddabdc6888d4f733->enter($__internal_560d6f761047e3b9ff4517a6ce072517233e45306599b603ddabdc6888d4f733_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8bd3505635d5431093ebdd0c714ed7a1b1244320d9f568c586f7f95f970c0ce9->leave($__internal_8bd3505635d5431093ebdd0c714ed7a1b1244320d9f568c586f7f95f970c0ce9_prof);

        
        $__internal_560d6f761047e3b9ff4517a6ce072517233e45306599b603ddabdc6888d4f733->leave($__internal_560d6f761047e3b9ff4517a6ce072517233e45306599b603ddabdc6888d4f733_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0f298b457ca014f8ac6a02b8cd61d825b488e375298caff0130a6f07dc45e596 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f298b457ca014f8ac6a02b8cd61d825b488e375298caff0130a6f07dc45e596->enter($__internal_0f298b457ca014f8ac6a02b8cd61d825b488e375298caff0130a6f07dc45e596_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f85dda1acb59f2804ca6770c1a81c2f0894f25018c7f39c7bded20fb082166b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f85dda1acb59f2804ca6770c1a81c2f0894f25018c7f39c7bded20fb082166b4->enter($__internal_f85dda1acb59f2804ca6770c1a81c2f0894f25018c7f39c7bded20fb082166b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Affiliate</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Url</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "url", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "email", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Token</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "token", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Isactive</th>
                <td>";
        // line 26
        if ($this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "isActive", array())) {
            echo "Yes";
        } else {
            echo "No";
        }
        echo "</td>
            </tr>
            <tr>
                <th>Createdat</th>
                <td>";
        // line 30
        if ($this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "createdAt", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "createdAt", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_edit", array("id" => $this->getAttribute((isset($context["affiliate"]) ? $context["affiliate"] : $this->getContext($context, "affiliate")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 43
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 45
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_f85dda1acb59f2804ca6770c1a81c2f0894f25018c7f39c7bded20fb082166b4->leave($__internal_f85dda1acb59f2804ca6770c1a81c2f0894f25018c7f39c7bded20fb082166b4_prof);

        
        $__internal_0f298b457ca014f8ac6a02b8cd61d825b488e375298caff0130a6f07dc45e596->leave($__internal_0f298b457ca014f8ac6a02b8cd61d825b488e375298caff0130a6f07dc45e596_prof);

    }

    public function getTemplateName()
    {
        return "affiliate/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 45,  120 => 43,  114 => 40,  108 => 37,  96 => 30,  85 => 26,  78 => 22,  71 => 18,  64 => 14,  57 => 10,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Affiliate</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ affiliate.id }}</td>
            </tr>
            <tr>
                <th>Url</th>
                <td>{{ affiliate.url }}</td>
            </tr>
            <tr>
                <th>Email</th>
                <td>{{ affiliate.email }}</td>
            </tr>
            <tr>
                <th>Token</th>
                <td>{{ affiliate.token }}</td>
            </tr>
            <tr>
                <th>Isactive</th>
                <td>{% if affiliate.isActive %}Yes{% else %}No{% endif %}</td>
            </tr>
            <tr>
                <th>Createdat</th>
                <td>{% if affiliate.createdAt %}{{ affiliate.createdAt|date('Y-m-d H:i:s') }}{% endif %}</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('affiliate_index') }}\">Back to the list</a>
        </li>
        <li>
            <a href=\"{{ path('affiliate_edit', { 'id': affiliate.id }) }}\">Edit</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "affiliate/show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\affiliate\\show.html.twig");
    }
}
