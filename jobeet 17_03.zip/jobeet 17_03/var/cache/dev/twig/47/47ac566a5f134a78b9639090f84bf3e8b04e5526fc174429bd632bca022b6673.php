<?php

/* @Jobeet/Default/index.html.twig */
class __TwigTemplate_d027be0214577815f4cb7a1828083f9b4a885cef84dd3f79ee6f59ec1d834b61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01674d752a259b2d7ab3c70a73d39a45fdb2b1c38dcfcc8e570b689d31784310 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01674d752a259b2d7ab3c70a73d39a45fdb2b1c38dcfcc8e570b689d31784310->enter($__internal_01674d752a259b2d7ab3c70a73d39a45fdb2b1c38dcfcc8e570b689d31784310_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Jobeet/Default/index.html.twig"));

        $__internal_63981d13f389e518403dc3602ea43756e889c3b2c527daa11539535b1d965972 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63981d13f389e518403dc3602ea43756e889c3b2c527daa11539535b1d965972->enter($__internal_63981d13f389e518403dc3602ea43756e889c3b2c527daa11539535b1d965972_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Jobeet/Default/index.html.twig"));

        // line 1
        echo "Hello Cristina!
";
        
        $__internal_01674d752a259b2d7ab3c70a73d39a45fdb2b1c38dcfcc8e570b689d31784310->leave($__internal_01674d752a259b2d7ab3c70a73d39a45fdb2b1c38dcfcc8e570b689d31784310_prof);

        
        $__internal_63981d13f389e518403dc3602ea43756e889c3b2c527daa11539535b1d965972->leave($__internal_63981d13f389e518403dc3602ea43756e889c3b2c527daa11539535b1d965972_prof);

    }

    public function getTemplateName()
    {
        return "@Jobeet/Default/index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello Cristina!
", "@Jobeet/Default/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\src\\Epfc\\JobeetBundle\\Resources\\views\\Default\\index.html.twig");
    }
}
