<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_2258561f07ff140e32c1f4f73224d9e8986815460ce10492ae868cda41c8499c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5280a4ddcf28889b1b7aa08a3d897096492538033a3238418a91d1b2d05ebcbf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5280a4ddcf28889b1b7aa08a3d897096492538033a3238418a91d1b2d05ebcbf->enter($__internal_5280a4ddcf28889b1b7aa08a3d897096492538033a3238418a91d1b2d05ebcbf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        $__internal_aaa1b08c3c4a14f33006987d84b35fe7525cb3f2ddb464782062cb27b607d6ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aaa1b08c3c4a14f33006987d84b35fe7525cb3f2ddb464782062cb27b607d6ee->enter($__internal_aaa1b08c3c4a14f33006987d84b35fe7525cb3f2ddb464782062cb27b607d6ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_5280a4ddcf28889b1b7aa08a3d897096492538033a3238418a91d1b2d05ebcbf->leave($__internal_5280a4ddcf28889b1b7aa08a3d897096492538033a3238418a91d1b2d05ebcbf_prof);

        
        $__internal_aaa1b08c3c4a14f33006987d84b35fe7525cb3f2ddb464782062cb27b607d6ee->leave($__internal_aaa1b08c3c4a14f33006987d84b35fe7525cb3f2ddb464782062cb27b607d6ee_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "TwigBundle:Exception:exception.js.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
