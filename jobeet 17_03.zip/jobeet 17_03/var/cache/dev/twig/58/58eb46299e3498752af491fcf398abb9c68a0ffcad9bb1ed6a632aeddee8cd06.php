<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_d6cb6cbeeb3e1f514801834123a9f84a251f9971f4810198e3a6366663d6eaf4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f548d88fe234b5fb10893afd540d56a2b956c2eb0502fb929870f008b46d007 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f548d88fe234b5fb10893afd540d56a2b956c2eb0502fb929870f008b46d007->enter($__internal_4f548d88fe234b5fb10893afd540d56a2b956c2eb0502fb929870f008b46d007_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_93e638103def99daa286d6e3be7cc70ff4f0401fb922acda4bd012500ba84646 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93e638103def99daa286d6e3be7cc70ff4f0401fb922acda4bd012500ba84646->enter($__internal_93e638103def99daa286d6e3be7cc70ff4f0401fb922acda4bd012500ba84646_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_4f548d88fe234b5fb10893afd540d56a2b956c2eb0502fb929870f008b46d007->leave($__internal_4f548d88fe234b5fb10893afd540d56a2b956c2eb0502fb929870f008b46d007_prof);

        
        $__internal_93e638103def99daa286d6e3be7cc70ff4f0401fb922acda4bd012500ba84646->leave($__internal_93e638103def99daa286d6e3be7cc70ff4f0401fb922acda4bd012500ba84646_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_fa9b604be3889ee544953c9e0bc8defbebf8f37145d0e881927c8dbb3f9443d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa9b604be3889ee544953c9e0bc8defbebf8f37145d0e881927c8dbb3f9443d6->enter($__internal_fa9b604be3889ee544953c9e0bc8defbebf8f37145d0e881927c8dbb3f9443d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_ddba50d42d92d3393b346e7191d33af3c1936eb36c46930cca4ade2f546327e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ddba50d42d92d3393b346e7191d33af3c1936eb36c46930cca4ade2f546327e0->enter($__internal_ddba50d42d92d3393b346e7191d33af3c1936eb36c46930cca4ade2f546327e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_ddba50d42d92d3393b346e7191d33af3c1936eb36c46930cca4ade2f546327e0->leave($__internal_ddba50d42d92d3393b346e7191d33af3c1936eb36c46930cca4ade2f546327e0_prof);

        
        $__internal_fa9b604be3889ee544953c9e0bc8defbebf8f37145d0e881927c8dbb3f9443d6->leave($__internal_fa9b604be3889ee544953c9e0bc8defbebf8f37145d0e881927c8dbb3f9443d6_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
