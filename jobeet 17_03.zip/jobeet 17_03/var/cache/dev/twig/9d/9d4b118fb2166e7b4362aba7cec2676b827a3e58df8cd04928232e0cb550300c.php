<?php

/* :category:new.html.twig */
class __TwigTemplate_5851ef7bfd5b45274f6bd04e606bf0c52e23a8c82ebdf63c34902fe13b331210 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6655ebb9c5ef4c1cde80e1ced16212df4575c24432673cb5444e5e254d5aade8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6655ebb9c5ef4c1cde80e1ced16212df4575c24432673cb5444e5e254d5aade8->enter($__internal_6655ebb9c5ef4c1cde80e1ced16212df4575c24432673cb5444e5e254d5aade8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:new.html.twig"));

        $__internal_ee1ac4d36679de4cd27c21c3cb8041f095f79603e0e86d41ee36f2262cf3180c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee1ac4d36679de4cd27c21c3cb8041f095f79603e0e86d41ee36f2262cf3180c->enter($__internal_ee1ac4d36679de4cd27c21c3cb8041f095f79603e0e86d41ee36f2262cf3180c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6655ebb9c5ef4c1cde80e1ced16212df4575c24432673cb5444e5e254d5aade8->leave($__internal_6655ebb9c5ef4c1cde80e1ced16212df4575c24432673cb5444e5e254d5aade8_prof);

        
        $__internal_ee1ac4d36679de4cd27c21c3cb8041f095f79603e0e86d41ee36f2262cf3180c->leave($__internal_ee1ac4d36679de4cd27c21c3cb8041f095f79603e0e86d41ee36f2262cf3180c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5b8a71869bed689ea4e6c8610d215ae7e249df55b957a121e858812a5afae0e4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b8a71869bed689ea4e6c8610d215ae7e249df55b957a121e858812a5afae0e4->enter($__internal_5b8a71869bed689ea4e6c8610d215ae7e249df55b957a121e858812a5afae0e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_378ede463c39a9de9a3289402bdcb9c600b8084494ebe83b9bf8aadfb936f1e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_378ede463c39a9de9a3289402bdcb9c600b8084494ebe83b9bf8aadfb936f1e0->enter($__internal_378ede463c39a9de9a3289402bdcb9c600b8084494ebe83b9bf8aadfb936f1e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Category creation</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_378ede463c39a9de9a3289402bdcb9c600b8084494ebe83b9bf8aadfb936f1e0->leave($__internal_378ede463c39a9de9a3289402bdcb9c600b8084494ebe83b9bf8aadfb936f1e0_prof);

        
        $__internal_5b8a71869bed689ea4e6c8610d215ae7e249df55b957a121e858812a5afae0e4->leave($__internal_5b8a71869bed689ea4e6c8610d215ae7e249df55b957a121e858812a5afae0e4_prof);

    }

    public function getTemplateName()
    {
        return ":category:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Category creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('category_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", ":category:new.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/category/new.html.twig");
    }
}
