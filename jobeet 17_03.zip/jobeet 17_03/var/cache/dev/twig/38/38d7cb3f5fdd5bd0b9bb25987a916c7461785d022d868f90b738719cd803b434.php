<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_85b25b27080361146b493977e63d8cfc90c12c43f5bfd11f29079cce126d93cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a537f5b673644e8492321c10089a0b22e28bcc5d2af7249f2013ee090225280e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a537f5b673644e8492321c10089a0b22e28bcc5d2af7249f2013ee090225280e->enter($__internal_a537f5b673644e8492321c10089a0b22e28bcc5d2af7249f2013ee090225280e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_09ee876eaa240d76572309f9dffa34c64a00bdfb9286a0aac5e95f394e93ab0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09ee876eaa240d76572309f9dffa34c64a00bdfb9286a0aac5e95f394e93ab0c->enter($__internal_09ee876eaa240d76572309f9dffa34c64a00bdfb9286a0aac5e95f394e93ab0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_a537f5b673644e8492321c10089a0b22e28bcc5d2af7249f2013ee090225280e->leave($__internal_a537f5b673644e8492321c10089a0b22e28bcc5d2af7249f2013ee090225280e_prof);

        
        $__internal_09ee876eaa240d76572309f9dffa34c64a00bdfb9286a0aac5e95f394e93ab0c->leave($__internal_09ee876eaa240d76572309f9dffa34c64a00bdfb9286a0aac5e95f394e93ab0c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
