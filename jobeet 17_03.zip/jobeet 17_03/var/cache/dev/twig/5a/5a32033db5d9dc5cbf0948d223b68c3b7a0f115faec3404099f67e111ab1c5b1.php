<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_6023dfddd742055927c2478bd8aca76cd5d258ed0deeafefe067b10a6c6dc2c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8ec60ab6bdb55fd8a67e53254257180861359a3a67508b08a7887bfb3dd7947 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8ec60ab6bdb55fd8a67e53254257180861359a3a67508b08a7887bfb3dd7947->enter($__internal_b8ec60ab6bdb55fd8a67e53254257180861359a3a67508b08a7887bfb3dd7947_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_e5a1e9f90cf444189db798bbe3cfe9d9e4b17619856b247977a92e39cc511e51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5a1e9f90cf444189db798bbe3cfe9d9e4b17619856b247977a92e39cc511e51->enter($__internal_e5a1e9f90cf444189db798bbe3cfe9d9e4b17619856b247977a92e39cc511e51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_b8ec60ab6bdb55fd8a67e53254257180861359a3a67508b08a7887bfb3dd7947->leave($__internal_b8ec60ab6bdb55fd8a67e53254257180861359a3a67508b08a7887bfb3dd7947_prof);

        
        $__internal_e5a1e9f90cf444189db798bbe3cfe9d9e4b17619856b247977a92e39cc511e51->leave($__internal_e5a1e9f90cf444189db798bbe3cfe9d9e4b17619856b247977a92e39cc511e51_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
