<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_552e9f692e8c66ced8d9be7d56200b5deea186d81e3a6021debbc8311c914dd2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19107dcee6a5f2a0fe5c5ebdc04b49df7e13151aa2eb57f6360a5ab6e3e09f28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19107dcee6a5f2a0fe5c5ebdc04b49df7e13151aa2eb57f6360a5ab6e3e09f28->enter($__internal_19107dcee6a5f2a0fe5c5ebdc04b49df7e13151aa2eb57f6360a5ab6e3e09f28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_76278bf21efc3fd0b8d21770a076048d2edf1768f9e9a34041579c010e32e02b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76278bf21efc3fd0b8d21770a076048d2edf1768f9e9a34041579c010e32e02b->enter($__internal_76278bf21efc3fd0b8d21770a076048d2edf1768f9e9a34041579c010e32e02b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_19107dcee6a5f2a0fe5c5ebdc04b49df7e13151aa2eb57f6360a5ab6e3e09f28->leave($__internal_19107dcee6a5f2a0fe5c5ebdc04b49df7e13151aa2eb57f6360a5ab6e3e09f28_prof);

        
        $__internal_76278bf21efc3fd0b8d21770a076048d2edf1768f9e9a34041579c010e32e02b->leave($__internal_76278bf21efc3fd0b8d21770a076048d2edf1768f9e9a34041579c010e32e02b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
