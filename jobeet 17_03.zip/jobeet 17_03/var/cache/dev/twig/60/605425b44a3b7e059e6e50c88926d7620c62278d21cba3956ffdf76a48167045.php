<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_ebb8106dc31eb97b3a188d8aa8937984ef45a6b8bb72ce572cb34f50ccab72be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1bba26f63425e139583a99790ad2a72d65847444b598c0ba5f53621fe13488ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1bba26f63425e139583a99790ad2a72d65847444b598c0ba5f53621fe13488ef->enter($__internal_1bba26f63425e139583a99790ad2a72d65847444b598c0ba5f53621fe13488ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_b42892765003d6c703ad26953aa415055d22e9b95d32fe2f26beea6d3ff9f30f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b42892765003d6c703ad26953aa415055d22e9b95d32fe2f26beea6d3ff9f30f->enter($__internal_b42892765003d6c703ad26953aa415055d22e9b95d32fe2f26beea6d3ff9f30f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_1bba26f63425e139583a99790ad2a72d65847444b598c0ba5f53621fe13488ef->leave($__internal_1bba26f63425e139583a99790ad2a72d65847444b598c0ba5f53621fe13488ef_prof);

        
        $__internal_b42892765003d6c703ad26953aa415055d22e9b95d32fe2f26beea6d3ff9f30f->leave($__internal_b42892765003d6c703ad26953aa415055d22e9b95d32fe2f26beea6d3ff9f30f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
