<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_d8e6638505157a324f24d52cc7106b82f2c80b68e7e7d4765fd3773aef3fea18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19c14b7356c50ba84719d91c747345d1e67e309a14560349cea2069d5ca66919 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19c14b7356c50ba84719d91c747345d1e67e309a14560349cea2069d5ca66919->enter($__internal_19c14b7356c50ba84719d91c747345d1e67e309a14560349cea2069d5ca66919_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_fefb3975b32a1e51a2561d7f6f4e94c0d9e475bb7d00a401419d8e863c79237f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fefb3975b32a1e51a2561d7f6f4e94c0d9e475bb7d00a401419d8e863c79237f->enter($__internal_fefb3975b32a1e51a2561d7f6f4e94c0d9e475bb7d00a401419d8e863c79237f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_19c14b7356c50ba84719d91c747345d1e67e309a14560349cea2069d5ca66919->leave($__internal_19c14b7356c50ba84719d91c747345d1e67e309a14560349cea2069d5ca66919_prof);

        
        $__internal_fefb3975b32a1e51a2561d7f6f4e94c0d9e475bb7d00a401419d8e863c79237f->leave($__internal_fefb3975b32a1e51a2561d7f6f4e94c0d9e475bb7d00a401419d8e863c79237f_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
