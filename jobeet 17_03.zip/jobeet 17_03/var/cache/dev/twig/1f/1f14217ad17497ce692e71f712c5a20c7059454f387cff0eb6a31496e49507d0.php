<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_f3defe0f75614e153998bf8fb316ac33a171f8ae713cd81fba113152e65f9515 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_148afdcb8f73b283abd5d0dee84f44cae57682dc4b9f8ab5cf63c8324916e1be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_148afdcb8f73b283abd5d0dee84f44cae57682dc4b9f8ab5cf63c8324916e1be->enter($__internal_148afdcb8f73b283abd5d0dee84f44cae57682dc4b9f8ab5cf63c8324916e1be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_dd4579a4a4255334ff55577b586418a18eabfd7f0034f290866af22da75808d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd4579a4a4255334ff55577b586418a18eabfd7f0034f290866af22da75808d2->enter($__internal_dd4579a4a4255334ff55577b586418a18eabfd7f0034f290866af22da75808d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_148afdcb8f73b283abd5d0dee84f44cae57682dc4b9f8ab5cf63c8324916e1be->leave($__internal_148afdcb8f73b283abd5d0dee84f44cae57682dc4b9f8ab5cf63c8324916e1be_prof);

        
        $__internal_dd4579a4a4255334ff55577b586418a18eabfd7f0034f290866af22da75808d2->leave($__internal_dd4579a4a4255334ff55577b586418a18eabfd7f0034f290866af22da75808d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
