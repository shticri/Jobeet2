<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_75deec35f7d633e2129b60d241f12f3698b8c5e9d1a72cd4f2b0e40681d28a99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ab10312f50603cb3e76b83b92296af5ef3cd29205f0d97340a4fd138a413f6c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ab10312f50603cb3e76b83b92296af5ef3cd29205f0d97340a4fd138a413f6c9->enter($__internal_ab10312f50603cb3e76b83b92296af5ef3cd29205f0d97340a4fd138a413f6c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_16f0130247c774bf1f4607be82e369677397bfe7582fb070823a10b0615d1d32 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16f0130247c774bf1f4607be82e369677397bfe7582fb070823a10b0615d1d32->enter($__internal_16f0130247c774bf1f4607be82e369677397bfe7582fb070823a10b0615d1d32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_ab10312f50603cb3e76b83b92296af5ef3cd29205f0d97340a4fd138a413f6c9->leave($__internal_ab10312f50603cb3e76b83b92296af5ef3cd29205f0d97340a4fd138a413f6c9_prof);

        
        $__internal_16f0130247c774bf1f4607be82e369677397bfe7582fb070823a10b0615d1d32->leave($__internal_16f0130247c774bf1f4607be82e369677397bfe7582fb070823a10b0615d1d32_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
