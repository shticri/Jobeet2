<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_dd9b472061677e100d0f0a19ab190dc4b4a04a6db43ba963cd690561170a9900 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f21773c4fa0f6af0b68c7106bc8f05927890580fd882c2f6eab8ac2472937abd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f21773c4fa0f6af0b68c7106bc8f05927890580fd882c2f6eab8ac2472937abd->enter($__internal_f21773c4fa0f6af0b68c7106bc8f05927890580fd882c2f6eab8ac2472937abd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_80a07f5b56f6e22b107873215c88ad10f4b0c33411fa2c19add4323b581a6593 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80a07f5b56f6e22b107873215c88ad10f4b0c33411fa2c19add4323b581a6593->enter($__internal_80a07f5b56f6e22b107873215c88ad10f4b0c33411fa2c19add4323b581a6593_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f21773c4fa0f6af0b68c7106bc8f05927890580fd882c2f6eab8ac2472937abd->leave($__internal_f21773c4fa0f6af0b68c7106bc8f05927890580fd882c2f6eab8ac2472937abd_prof);

        
        $__internal_80a07f5b56f6e22b107873215c88ad10f4b0c33411fa2c19add4323b581a6593->leave($__internal_80a07f5b56f6e22b107873215c88ad10f4b0c33411fa2c19add4323b581a6593_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bdab6424c8bbee5134434bed1b1a7489c097582e9becd25171aee63d91b79338 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bdab6424c8bbee5134434bed1b1a7489c097582e9becd25171aee63d91b79338->enter($__internal_bdab6424c8bbee5134434bed1b1a7489c097582e9becd25171aee63d91b79338_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3573d873e0432a19d29c8929dc820ccab5c1aca7538fa84e8e012784a952042b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3573d873e0432a19d29c8929dc820ccab5c1aca7538fa84e8e012784a952042b->enter($__internal_3573d873e0432a19d29c8929dc820ccab5c1aca7538fa84e8e012784a952042b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_3573d873e0432a19d29c8929dc820ccab5c1aca7538fa84e8e012784a952042b->leave($__internal_3573d873e0432a19d29c8929dc820ccab5c1aca7538fa84e8e012784a952042b_prof);

        
        $__internal_bdab6424c8bbee5134434bed1b1a7489c097582e9becd25171aee63d91b79338->leave($__internal_bdab6424c8bbee5134434bed1b1a7489c097582e9becd25171aee63d91b79338_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_f095271ccad25c911f9c34ee9749a9bba222d42b9f189ec70ca0519aa6c9759c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f095271ccad25c911f9c34ee9749a9bba222d42b9f189ec70ca0519aa6c9759c->enter($__internal_f095271ccad25c911f9c34ee9749a9bba222d42b9f189ec70ca0519aa6c9759c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e2d332c851653e96145d0d568d4961905bba0fae1eb98a8cd89decba0fb0c225 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2d332c851653e96145d0d568d4961905bba0fae1eb98a8cd89decba0fb0c225->enter($__internal_e2d332c851653e96145d0d568d4961905bba0fae1eb98a8cd89decba0fb0c225_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_e2d332c851653e96145d0d568d4961905bba0fae1eb98a8cd89decba0fb0c225->leave($__internal_e2d332c851653e96145d0d568d4961905bba0fae1eb98a8cd89decba0fb0c225_prof);

        
        $__internal_f095271ccad25c911f9c34ee9749a9bba222d42b9f189ec70ca0519aa6c9759c->leave($__internal_f095271ccad25c911f9c34ee9749a9bba222d42b9f189ec70ca0519aa6c9759c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
