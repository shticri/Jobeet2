<?php

/* category/show.html.twig */
class __TwigTemplate_13752db03b57fcd495847ac64ae9acc6950c994114b563ae5d295481df1f97d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d80412e68d74c57551f4c0b2233cb79afde8d0d2b463b632e6214d6b8436dc2e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d80412e68d74c57551f4c0b2233cb79afde8d0d2b463b632e6214d6b8436dc2e->enter($__internal_d80412e68d74c57551f4c0b2233cb79afde8d0d2b463b632e6214d6b8436dc2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/show.html.twig"));

        $__internal_a8ab69d61a6f0e6bd6e8093d6002954dda7cb4c13bd5310496e3fa7070d03865 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8ab69d61a6f0e6bd6e8093d6002954dda7cb4c13bd5310496e3fa7070d03865->enter($__internal_a8ab69d61a6f0e6bd6e8093d6002954dda7cb4c13bd5310496e3fa7070d03865_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d80412e68d74c57551f4c0b2233cb79afde8d0d2b463b632e6214d6b8436dc2e->leave($__internal_d80412e68d74c57551f4c0b2233cb79afde8d0d2b463b632e6214d6b8436dc2e_prof);

        
        $__internal_a8ab69d61a6f0e6bd6e8093d6002954dda7cb4c13bd5310496e3fa7070d03865->leave($__internal_a8ab69d61a6f0e6bd6e8093d6002954dda7cb4c13bd5310496e3fa7070d03865_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b9fbd252ce0614e54d286ba2fc9dd7592d7a08a1349315241b59876709e861ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b9fbd252ce0614e54d286ba2fc9dd7592d7a08a1349315241b59876709e861ed->enter($__internal_b9fbd252ce0614e54d286ba2fc9dd7592d7a08a1349315241b59876709e861ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e861b27768d42448e2be028343729deee44a8beb1d05105b85686cc19d4f7fc7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e861b27768d42448e2be028343729deee44a8beb1d05105b85686cc19d4f7fc7->enter($__internal_e861b27768d42448e2be028343729deee44a8beb1d05105b85686cc19d4f7fc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "  Jobs in the ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
        echo " category
";
        
        $__internal_e861b27768d42448e2be028343729deee44a8beb1d05105b85686cc19d4f7fc7->leave($__internal_e861b27768d42448e2be028343729deee44a8beb1d05105b85686cc19d4f7fc7_prof);

        
        $__internal_b9fbd252ce0614e54d286ba2fc9dd7592d7a08a1349315241b59876709e861ed->leave($__internal_b9fbd252ce0614e54d286ba2fc9dd7592d7a08a1349315241b59876709e861ed_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d4d98362f5481602765d190fc8d882315b13fa1ae63139e912c3886f496b2966 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d4d98362f5481602765d190fc8d882315b13fa1ae63139e912c3886f496b2966->enter($__internal_d4d98362f5481602765d190fc8d882315b13fa1ae63139e912c3886f496b2966_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d274e8ee20ce82c781890fd9185fb59d73f746f68e4f0835dde4bcd81a797450 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d274e8ee20ce82c781890fd9185fb59d73f746f68e4f0835dde4bcd81a797450->enter($__internal_d274e8ee20ce82c781890fd9185fb59d73f746f68e4f0835dde4bcd81a797450_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/jobs.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_d274e8ee20ce82c781890fd9185fb59d73f746f68e4f0835dde4bcd81a797450->leave($__internal_d274e8ee20ce82c781890fd9185fb59d73f746f68e4f0835dde4bcd81a797450_prof);

        
        $__internal_d4d98362f5481602765d190fc8d882315b13fa1ae63139e912c3886f496b2966->leave($__internal_d4d98362f5481602765d190fc8d882315b13fa1ae63139e912c3886f496b2966_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_7e6b85ecee2e1f8490d0d46dc8efecde7f3c567db4c72a046beb24c335d28f6c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7e6b85ecee2e1f8490d0d46dc8efecde7f3c567db4c72a046beb24c335d28f6c->enter($__internal_7e6b85ecee2e1f8490d0d46dc8efecde7f3c567db4c72a046beb24c335d28f6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_9c4e42fe36f699680158a746f47e863a6358d22a24699746a40929f18672e805 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c4e42fe36f699680158a746f47e863a6358d22a24699746a40929f18672e805->enter($__internal_9c4e42fe36f699680158a746f47e863a6358d22a24699746a40929f18672e805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 13
        echo "  <div class=\"category_";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "html", null, true);
        echo "\">
    <div class=\"feed\">
      <a href=\"\">Feed</a>
    </div>
    <h1>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
        echo "</h1>
   
    ";
        // line 19
        $this->loadTemplate("job/list.html.twig", "category/show.html.twig", 19)->display(array_merge($context, array("jobs" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "activejobs", array()))));
        // line 20
        echo "  
    
  </div>
    
  ";
        // line 24
        if (((isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")) > 1)) {
            // line 25
            echo "    <div class=\"pagination\">
      <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => 1)), "html", null, true);
            echo "\">
        <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/first.png"), "html", null, true);
            echo "\" alt=\"First page\" title=\"First page\" />
      </a>
 
      <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["previous_page"]) ? $context["previous_page"] : $this->getContext($context, "previous_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/previous.png"), "html", null, true);
            echo "\" alt=\"Previous page\" title=\"Previous page\" />
      </a>
 
      ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page"))));
            foreach ($context['_seq'] as $context["_key"] => $context["page"]) {
                // line 35
                echo "        ";
                if (($context["page"] == (isset($context["current_page"]) ? $context["current_page"] : $this->getContext($context, "current_page")))) {
                    // line 36
                    echo "          ";
                    echo twig_escape_filter($this->env, $context["page"], "html", null, true);
                    echo "
        ";
                } else {
                    // line 38
                    echo "          <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => $context["page"])), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $context["page"], "html", null, true);
                    echo "</a>
        ";
                }
                // line 40
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['page'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 41
            echo " 
      <a href=\"";
            // line 42
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["next_page"]) ? $context["next_page"] : $this->getContext($context, "next_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/next.png"), "html", null, true);
            echo "\" alt=\"Next page\" title=\"Next page\" />
      </a>
 
      <a href=\"";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 47
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/last.png"), "html", null, true);
            echo "\" alt=\"Last page\" title=\"Last page\" />
      </a>
    </div>
  ";
        }
        // line 51
        echo " 
  <div class=\"pagination_desc\">
    <strong>";
        // line 53
        echo twig_escape_filter($this->env, (isset($context["total_jobs"]) ? $context["total_jobs"] : $this->getContext($context, "total_jobs")), "html", null, true);
        echo "</strong> jobs in this category
 
    ";
        // line 55
        if (((isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")) > 1)) {
            // line 56
            echo "      - page <strong>";
            echo twig_escape_filter($this->env, (isset($context["current_page"]) ? $context["current_page"] : $this->getContext($context, "current_page")), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")), "html", null, true);
            echo "</strong>
    ";
        }
        // line 58
        echo "  </div>
";
        
        $__internal_9c4e42fe36f699680158a746f47e863a6358d22a24699746a40929f18672e805->leave($__internal_9c4e42fe36f699680158a746f47e863a6358d22a24699746a40929f18672e805_prof);

        
        $__internal_7e6b85ecee2e1f8490d0d46dc8efecde7f3c567db4c72a046beb24c335d28f6c->leave($__internal_7e6b85ecee2e1f8490d0d46dc8efecde7f3c567db4c72a046beb24c335d28f6c_prof);

    }

    public function getTemplateName()
    {
        return "category/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  215 => 58,  207 => 56,  205 => 55,  200 => 53,  196 => 51,  189 => 47,  185 => 46,  179 => 43,  175 => 42,  172 => 41,  166 => 40,  158 => 38,  152 => 36,  149 => 35,  145 => 34,  139 => 31,  135 => 30,  129 => 27,  125 => 26,  122 => 25,  120 => 24,  114 => 20,  112 => 19,  107 => 17,  99 => 13,  90 => 12,  78 => 9,  73 => 8,  64 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
  Jobs in the {{ category.name }} category
{% endblock %}
 
{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/jobs.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
  <div class=\"category_{{ category.slug }}\">
    <div class=\"feed\">
      <a href=\"\">Feed</a>
    </div>
    <h1>{{ category.name }}</h1>
   
    {% include 'job/list.html.twig' with {'jobs': category.activejobs} %}
  
    
  </div>
    
  {% if last_page > 1 %}
    <div class=\"pagination\">
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': 1 }) }}\">
        <img src=\"{{ asset('public/images/first.png') }}\" alt=\"First page\" title=\"First page\" />
      </a>
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': previous_page }) }}\">
        <img src=\"{{ asset('public/images/previous.png') }}\" alt=\"Previous page\" title=\"Previous page\" />
      </a>
 
      {% for page in 1..last_page %}
        {% if page == current_page %}
          {{ page }}
        {% else %}
          <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': page }) }}\">{{ page }}</a>
        {% endif %}
      {% endfor %}
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': next_page }) }}\">
        <img src=\"{{ asset('public/images/next.png') }}\" alt=\"Next page\" title=\"Next page\" />
      </a>
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': last_page }) }}\">
        <img src=\"{{ asset('public/images/last.png') }}\" alt=\"Last page\" title=\"Last page\" />
      </a>
    </div>
  {% endif %}
 
  <div class=\"pagination_desc\">
    <strong>{{ total_jobs }}</strong> jobs in this category
 
    {% if last_page > 1 %}
      - page <strong>{{ current_page }}/{{ last_page }}</strong>
    {% endif %}
  </div>
{% endblock %}
", "category/show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\category\\show.html.twig");
    }
}
