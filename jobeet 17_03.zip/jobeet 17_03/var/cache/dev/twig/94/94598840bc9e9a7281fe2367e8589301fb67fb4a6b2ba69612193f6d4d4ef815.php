<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_9f73aad1d1c41cba15b2554e9ba554bdecaeb1bafa27d9717867fe27e1d1473c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_857521c5c8e5ead4e54d4dc26ba064cdf9924b22e540d6383c18e053153ae8fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_857521c5c8e5ead4e54d4dc26ba064cdf9924b22e540d6383c18e053153ae8fd->enter($__internal_857521c5c8e5ead4e54d4dc26ba064cdf9924b22e540d6383c18e053153ae8fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_64bc12daf5bf89b08da2d10ef2f2c01e84225cd817903ea949d9277e22eb698b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64bc12daf5bf89b08da2d10ef2f2c01e84225cd817903ea949d9277e22eb698b->enter($__internal_64bc12daf5bf89b08da2d10ef2f2c01e84225cd817903ea949d9277e22eb698b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_857521c5c8e5ead4e54d4dc26ba064cdf9924b22e540d6383c18e053153ae8fd->leave($__internal_857521c5c8e5ead4e54d4dc26ba064cdf9924b22e540d6383c18e053153ae8fd_prof);

        
        $__internal_64bc12daf5bf89b08da2d10ef2f2c01e84225cd817903ea949d9277e22eb698b->leave($__internal_64bc12daf5bf89b08da2d10ef2f2c01e84225cd817903ea949d9277e22eb698b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f8aad1d0ef0e4dc159650be3f2a10b4bc59c5c3848b9f16df99bf576a81d8f5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8aad1d0ef0e4dc159650be3f2a10b4bc59c5c3848b9f16df99bf576a81d8f5f->enter($__internal_f8aad1d0ef0e4dc159650be3f2a10b4bc59c5c3848b9f16df99bf576a81d8f5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9add775812c4376d0e2f6afa76116d1266fcd9ef3bc9cc201508739e0ce24cff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9add775812c4376d0e2f6afa76116d1266fcd9ef3bc9cc201508739e0ce24cff->enter($__internal_9add775812c4376d0e2f6afa76116d1266fcd9ef3bc9cc201508739e0ce24cff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_9add775812c4376d0e2f6afa76116d1266fcd9ef3bc9cc201508739e0ce24cff->leave($__internal_9add775812c4376d0e2f6afa76116d1266fcd9ef3bc9cc201508739e0ce24cff_prof);

        
        $__internal_f8aad1d0ef0e4dc159650be3f2a10b4bc59c5c3848b9f16df99bf576a81d8f5f->leave($__internal_f8aad1d0ef0e4dc159650be3f2a10b4bc59c5c3848b9f16df99bf576a81d8f5f_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_2524c0feaea71f03e0c103b3d35a6c6413e7586b0239e1213d9ac57426885a81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2524c0feaea71f03e0c103b3d35a6c6413e7586b0239e1213d9ac57426885a81->enter($__internal_2524c0feaea71f03e0c103b3d35a6c6413e7586b0239e1213d9ac57426885a81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_18d00902b00991d5c0fbbcfdedbc922b884b620ffaf13b82b81ea31d86ebad1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18d00902b00991d5c0fbbcfdedbc922b884b620ffaf13b82b81ea31d86ebad1f->enter($__internal_18d00902b00991d5c0fbbcfdedbc922b884b620ffaf13b82b81ea31d86ebad1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_18d00902b00991d5c0fbbcfdedbc922b884b620ffaf13b82b81ea31d86ebad1f->leave($__internal_18d00902b00991d5c0fbbcfdedbc922b884b620ffaf13b82b81ea31d86ebad1f_prof);

        
        $__internal_2524c0feaea71f03e0c103b3d35a6c6413e7586b0239e1213d9ac57426885a81->leave($__internal_2524c0feaea71f03e0c103b3d35a6c6413e7586b0239e1213d9ac57426885a81_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
