<?php

/* :job:show.html.twig */
class __TwigTemplate_d5d9f89d889d88eb435256d51178fba192d5616b6bec85d1d211777881faabe4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":job:show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf694a64c93dce216f04106466cb13d923a3554f6334064355a6c17d1e345f94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf694a64c93dce216f04106466cb13d923a3554f6334064355a6c17d1e345f94->enter($__internal_cf694a64c93dce216f04106466cb13d923a3554f6334064355a6c17d1e345f94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:show.html.twig"));

        $__internal_ed3b652f26687d6cdecbe8b5bd44a2662536e0ec2f2ca178acab45a95feabff5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed3b652f26687d6cdecbe8b5bd44a2662536e0ec2f2ca178acab45a95feabff5->enter($__internal_ed3b652f26687d6cdecbe8b5bd44a2662536e0ec2f2ca178acab45a95feabff5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf694a64c93dce216f04106466cb13d923a3554f6334064355a6c17d1e345f94->leave($__internal_cf694a64c93dce216f04106466cb13d923a3554f6334064355a6c17d1e345f94_prof);

        
        $__internal_ed3b652f26687d6cdecbe8b5bd44a2662536e0ec2f2ca178acab45a95feabff5->leave($__internal_ed3b652f26687d6cdecbe8b5bd44a2662536e0ec2f2ca178acab45a95feabff5_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_3a239cff09a69ac7e4fe93c684906edb5e2b6beeb2259b2e2d471ff8a4a53f46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a239cff09a69ac7e4fe93c684906edb5e2b6beeb2259b2e2d471ff8a4a53f46->enter($__internal_3a239cff09a69ac7e4fe93c684906edb5e2b6beeb2259b2e2d471ff8a4a53f46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ee25eea71ef78c6e88e5f9a1e6071abbda7840f181c3c7e13aec5e960f86ce0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee25eea71ef78c6e88e5f9a1e6071abbda7840f181c3c7e13aec5e960f86ce0e->enter($__internal_ee25eea71ef78c6e88e5f9a1e6071abbda7840f181c3c7e13aec5e960f86ce0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo " is looking for a ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
";
        
        $__internal_ee25eea71ef78c6e88e5f9a1e6071abbda7840f181c3c7e13aec5e960f86ce0e->leave($__internal_ee25eea71ef78c6e88e5f9a1e6071abbda7840f181c3c7e13aec5e960f86ce0e_prof);

        
        $__internal_3a239cff09a69ac7e4fe93c684906edb5e2b6beeb2259b2e2d471ff8a4a53f46->leave($__internal_3a239cff09a69ac7e4fe93c684906edb5e2b6beeb2259b2e2d471ff8a4a53f46_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_dcc41555d88810d164d6d901e73189feaf036ed71f4685e514f2c833f5abfd93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dcc41555d88810d164d6d901e73189feaf036ed71f4685e514f2c833f5abfd93->enter($__internal_dcc41555d88810d164d6d901e73189feaf036ed71f4685e514f2c833f5abfd93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_017d1c4850786d04547fd3b426e881f6a358370b80d784a403d7fe7379d45034 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_017d1c4850786d04547fd3b426e881f6a358370b80d784a403d7fe7379d45034->enter($__internal_017d1c4850786d04547fd3b426e881f6a358370b80d784a403d7fe7379d45034_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/job.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_017d1c4850786d04547fd3b426e881f6a358370b80d784a403d7fe7379d45034->leave($__internal_017d1c4850786d04547fd3b426e881f6a358370b80d784a403d7fe7379d45034_prof);

        
        $__internal_dcc41555d88810d164d6d901e73189feaf036ed71f4685e514f2c833f5abfd93->leave($__internal_dcc41555d88810d164d6d901e73189feaf036ed71f4685e514f2c833f5abfd93_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_3a3a1959d865172efca799436db42a66164fbf3479152f6383d1a61dbb9bb556 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a3a1959d865172efca799436db42a66164fbf3479152f6383d1a61dbb9bb556->enter($__internal_3a3a1959d865172efca799436db42a66164fbf3479152f6383d1a61dbb9bb556_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_5583cd24225f836c79c236f2c4b29df7be251c46f85794f314805e2690d84553 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5583cd24225f836c79c236f2c4b29df7be251c46f85794f314805e2690d84553->enter($__internal_5583cd24225f836c79c236f2c4b29df7be251c46f85794f314805e2690d84553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 13
        echo "    <div id=\"job\">
      <h1>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo "</h1>
      <h2>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "location", array()), "html", null, true);
        echo "</h2>
      <h3>
        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
        <small> - ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "type", array()), "html", null, true);
        echo "</small>
      </h3>
 
      ";
        // line 21
        if ($this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array())) {
            // line 22
            echo "        <div class=\"logo\">
          <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "url", array()), "html", null, true);
            echo "\">
            <img src=\"/uploads/jobs/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array()), "html", null, true);
            echo "\"
              alt=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
            echo " logo\" />
          </a>
        </div>
      ";
        }
        // line 29
        echo " 
      <div class=\"description\">
        ";
        // line 31
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "description", array()), "html", null, true));
        echo "
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "howtoapply", array()), "html", null, true);
        echo "</p>
 
      <div class=\"meta\">
        <small>posted on ";
        // line 39
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "createdat", array()), "m/d/Y"), "html", null, true);
        echo "</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_edit", array("id" => $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "id", array()))), "html", null, true);
        echo "\">
          Edit
        </a>
      </div>
    </div>
";
        
        $__internal_5583cd24225f836c79c236f2c4b29df7be251c46f85794f314805e2690d84553->leave($__internal_5583cd24225f836c79c236f2c4b29df7be251c46f85794f314805e2690d84553_prof);

        
        $__internal_3a3a1959d865172efca799436db42a66164fbf3479152f6383d1a61dbb9bb556->leave($__internal_3a3a1959d865172efca799436db42a66164fbf3479152f6383d1a61dbb9bb556_prof);

    }

    public function getTemplateName()
    {
        return ":job:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  161 => 39,  155 => 36,  147 => 31,  143 => 29,  136 => 25,  132 => 24,  128 => 23,  125 => 22,  123 => 21,  117 => 18,  113 => 17,  108 => 15,  104 => 14,  101 => 13,  92 => 12,  80 => 9,  75 => 8,  66 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    {{ job.company }} is looking for a {{ job.position }}
{% endblock %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/job.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"job\">
      <h1>{{ job.company }}</h1>
      <h2>{{ job.location }}</h2>
      <h3>
        {{ job.position }}
        <small> - {{ job.type }}</small>
      </h3>
 
      {% if job.logo %}
        <div class=\"logo\">
          <a href=\"{{ job.url }}\">
            <img src=\"/uploads/jobs/{{ job.logo }}\"
              alt=\"{{ job.company }} logo\" />
          </a>
        </div>
      {% endif %}
 
      <div class=\"description\">
        {{ job.description|nl2br }}
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">{{ job.howtoapply }}</p>
 
      <div class=\"meta\">
        <small>posted on {{ job.createdat|date('m/d/Y') }}</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"{{ path('job_edit', { 'id': job.id }) }}\">
          Edit
        </a>
      </div>
    </div>
{% endblock %}
", ":job:show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/job/show.html.twig");
    }
}
