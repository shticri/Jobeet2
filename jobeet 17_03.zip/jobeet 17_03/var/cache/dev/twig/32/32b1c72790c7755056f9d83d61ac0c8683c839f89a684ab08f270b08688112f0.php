<?php

/* job/edit.html.twig */
class __TwigTemplate_dbe2184950c76bcc2557741fe0c10c0a281a9fbb8ff0e83fb433e3c0e18e426c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_19fc35abbd4273cfd609796de4d78c083d2cde5fe834210516b19c08235c6b8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19fc35abbd4273cfd609796de4d78c083d2cde5fe834210516b19c08235c6b8a->enter($__internal_19fc35abbd4273cfd609796de4d78c083d2cde5fe834210516b19c08235c6b8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/edit.html.twig"));

        $__internal_af8d29443b402375247dbcec729782d216ed7ed353832589325b90349021a89d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af8d29443b402375247dbcec729782d216ed7ed353832589325b90349021a89d->enter($__internal_af8d29443b402375247dbcec729782d216ed7ed353832589325b90349021a89d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_19fc35abbd4273cfd609796de4d78c083d2cde5fe834210516b19c08235c6b8a->leave($__internal_19fc35abbd4273cfd609796de4d78c083d2cde5fe834210516b19c08235c6b8a_prof);

        
        $__internal_af8d29443b402375247dbcec729782d216ed7ed353832589325b90349021a89d->leave($__internal_af8d29443b402375247dbcec729782d216ed7ed353832589325b90349021a89d_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_522317e2ac2da02d449cfc15265f7b6f49b5ca1b2aaef2baee88deeb3c8ab692 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_522317e2ac2da02d449cfc15265f7b6f49b5ca1b2aaef2baee88deeb3c8ab692->enter($__internal_522317e2ac2da02d449cfc15265f7b6f49b5ca1b2aaef2baee88deeb3c8ab692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_cc5e31b436156b59cf42ec1e660045376eb72c40550940ac549cba80047c43cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc5e31b436156b59cf42ec1e660045376eb72c40550940ac549cba80047c43cc->enter($__internal_cc5e31b436156b59cf42ec1e660045376eb72c40550940ac549cba80047c43cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Job edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_cc5e31b436156b59cf42ec1e660045376eb72c40550940ac549cba80047c43cc->leave($__internal_cc5e31b436156b59cf42ec1e660045376eb72c40550940ac549cba80047c43cc_prof);

        
        $__internal_522317e2ac2da02d449cfc15265f7b6f49b5ca1b2aaef2baee88deeb3c8ab692->leave($__internal_522317e2ac2da02d449cfc15265f7b6f49b5ca1b2aaef2baee88deeb3c8ab692_prof);

    }

    public function getTemplateName()
    {
        return "job/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block content %}
    <h1>Job edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('job_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "job/edit.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\edit.html.twig");
    }
}
