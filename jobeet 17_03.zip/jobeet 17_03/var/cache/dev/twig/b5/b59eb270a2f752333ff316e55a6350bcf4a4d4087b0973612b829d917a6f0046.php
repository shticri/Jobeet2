<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_8b2a29beef47614af8f624c4629a4dbd63828ec2fa153ac163f68ba72fd05d25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95c740cb032d6a838e61d596f915e025ac37a193344caefe0bb6810f3efaf7ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95c740cb032d6a838e61d596f915e025ac37a193344caefe0bb6810f3efaf7ec->enter($__internal_95c740cb032d6a838e61d596f915e025ac37a193344caefe0bb6810f3efaf7ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_22b41f961141efb1fe35f46205b40109ac04db2ccd4d9f6da07be937e043d1c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22b41f961141efb1fe35f46205b40109ac04db2ccd4d9f6da07be937e043d1c5->enter($__internal_22b41f961141efb1fe35f46205b40109ac04db2ccd4d9f6da07be937e043d1c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_95c740cb032d6a838e61d596f915e025ac37a193344caefe0bb6810f3efaf7ec->leave($__internal_95c740cb032d6a838e61d596f915e025ac37a193344caefe0bb6810f3efaf7ec_prof);

        
        $__internal_22b41f961141efb1fe35f46205b40109ac04db2ccd4d9f6da07be937e043d1c5->leave($__internal_22b41f961141efb1fe35f46205b40109ac04db2ccd4d9f6da07be937e043d1c5_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "@Twig/Exception/exception.css.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.css.twig");
    }
}
