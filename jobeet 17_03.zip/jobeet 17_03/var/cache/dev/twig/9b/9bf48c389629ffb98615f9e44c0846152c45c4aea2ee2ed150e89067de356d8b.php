<?php

/* affiliate/new.html.twig */
class __TwigTemplate_dbf0bfddcb7d8a161dcd97369122af5cb9efb9ec884bdf9bf849ba0742b5df0f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "affiliate/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb0715a97ea040edb603f9bf4cf600c05f45b1702424ed447001f31884b063d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb0715a97ea040edb603f9bf4cf600c05f45b1702424ed447001f31884b063d2->enter($__internal_fb0715a97ea040edb603f9bf4cf600c05f45b1702424ed447001f31884b063d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/new.html.twig"));

        $__internal_ab4d305796c15bec043e5d9fe9762ea7cc4c87b5474fd4697c8758b658b760b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab4d305796c15bec043e5d9fe9762ea7cc4c87b5474fd4697c8758b658b760b1->enter($__internal_ab4d305796c15bec043e5d9fe9762ea7cc4c87b5474fd4697c8758b658b760b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb0715a97ea040edb603f9bf4cf600c05f45b1702424ed447001f31884b063d2->leave($__internal_fb0715a97ea040edb603f9bf4cf600c05f45b1702424ed447001f31884b063d2_prof);

        
        $__internal_ab4d305796c15bec043e5d9fe9762ea7cc4c87b5474fd4697c8758b658b760b1->leave($__internal_ab4d305796c15bec043e5d9fe9762ea7cc4c87b5474fd4697c8758b658b760b1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5906a66be5f72c8be84c117a0f4eb10379796eb269ae8df023c76e0151921c8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5906a66be5f72c8be84c117a0f4eb10379796eb269ae8df023c76e0151921c8f->enter($__internal_5906a66be5f72c8be84c117a0f4eb10379796eb269ae8df023c76e0151921c8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d82db2f3cc4ca3240bbdaa2198b6e622478c9ae6a5836090079eada150b0e9ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d82db2f3cc4ca3240bbdaa2198b6e622478c9ae6a5836090079eada150b0e9ca->enter($__internal_d82db2f3cc4ca3240bbdaa2198b6e622478c9ae6a5836090079eada150b0e9ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Affiliate creation</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_d82db2f3cc4ca3240bbdaa2198b6e622478c9ae6a5836090079eada150b0e9ca->leave($__internal_d82db2f3cc4ca3240bbdaa2198b6e622478c9ae6a5836090079eada150b0e9ca_prof);

        
        $__internal_5906a66be5f72c8be84c117a0f4eb10379796eb269ae8df023c76e0151921c8f->leave($__internal_5906a66be5f72c8be84c117a0f4eb10379796eb269ae8df023c76e0151921c8f_prof);

    }

    public function getTemplateName()
    {
        return "affiliate/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Affiliate creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('affiliate_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "affiliate/new.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\affiliate\\new.html.twig");
    }
}
