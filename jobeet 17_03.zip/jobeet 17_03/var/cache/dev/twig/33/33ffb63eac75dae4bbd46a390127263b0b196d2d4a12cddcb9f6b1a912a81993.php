<?php

/* :category:index.html.twig */
class __TwigTemplate_f6a8b69eb4ce82d33e6293260a3ecace8a54d68c61722a959adbee685d4ba36f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35f275127d64486e45515540419626618ca8c6ae0e06adef71b156b4fde72324 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35f275127d64486e45515540419626618ca8c6ae0e06adef71b156b4fde72324->enter($__internal_35f275127d64486e45515540419626618ca8c6ae0e06adef71b156b4fde72324_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:index.html.twig"));

        $__internal_20ae85059889888a4a0485284428047173af55fcd68f09039159e6948b62a741 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20ae85059889888a4a0485284428047173af55fcd68f09039159e6948b62a741->enter($__internal_20ae85059889888a4a0485284428047173af55fcd68f09039159e6948b62a741_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_35f275127d64486e45515540419626618ca8c6ae0e06adef71b156b4fde72324->leave($__internal_35f275127d64486e45515540419626618ca8c6ae0e06adef71b156b4fde72324_prof);

        
        $__internal_20ae85059889888a4a0485284428047173af55fcd68f09039159e6948b62a741->leave($__internal_20ae85059889888a4a0485284428047173af55fcd68f09039159e6948b62a741_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_af574c57cf31a386f3b4ce7c4ed190273d746d6b39a8cd9673f5cc4cbc90560d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af574c57cf31a386f3b4ce7c4ed190273d746d6b39a8cd9673f5cc4cbc90560d->enter($__internal_af574c57cf31a386f3b4ce7c4ed190273d746d6b39a8cd9673f5cc4cbc90560d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_5d189406258e4c0cb33431a44676d172eb7d4f8b8dcf9c061326fbd34c75bb8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d189406258e4c0cb33431a44676d172eb7d4f8b8dcf9c061326fbd34c75bb8c->enter($__internal_5d189406258e4c0cb33431a44676d172eb7d4f8b8dcf9c061326fbd34c75bb8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_5d189406258e4c0cb33431a44676d172eb7d4f8b8dcf9c061326fbd34c75bb8c->leave($__internal_5d189406258e4c0cb33431a44676d172eb7d4f8b8dcf9c061326fbd34c75bb8c_prof);

        
        $__internal_af574c57cf31a386f3b4ce7c4ed190273d746d6b39a8cd9673f5cc4cbc90560d->leave($__internal_af574c57cf31a386f3b4ce7c4ed190273d746d6b39a8cd9673f5cc4cbc90560d_prof);

    }

    // line 46
    public function block_content($context, array $blocks = array())
    {
        $__internal_76ac7e86c28651c1c91d7a8bc7d4c7c06fb87b5e5d9e186ecaf56448a9b2df84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76ac7e86c28651c1c91d7a8bc7d4c7c06fb87b5e5d9e186ecaf56448a9b2df84->enter($__internal_76ac7e86c28651c1c91d7a8bc7d4c7c06fb87b5e5d9e186ecaf56448a9b2df84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_feea0c23ea54ac289006946b6202169af7bbd74deb2b093d01bd9f0b3fef30bc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feea0c23ea54ac289006946b6202169af7bbd74deb2b093d01bd9f0b3fef30bc->enter($__internal_feea0c23ea54ac289006946b6202169af7bbd74deb2b093d01bd9f0b3fef30bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 47
        echo "    <div id=\"categories\">
      <table class=\"categories\">
        ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 50
            echo "          <tr class=\"";
            echo twig_escape_filter($this->env, twig_cycle(array(0 => "even", 1 => "odd"), $this->getAttribute($context["loop"], "index", array())), "html", null, true);
            echo "\">
            <td>
              <a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                ";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "
              </a>
            </td>
            
          </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "      </table>
    </div>
";
        
        $__internal_feea0c23ea54ac289006946b6202169af7bbd74deb2b093d01bd9f0b3fef30bc->leave($__internal_feea0c23ea54ac289006946b6202169af7bbd74deb2b093d01bd9f0b3fef30bc_prof);

        
        $__internal_76ac7e86c28651c1c91d7a8bc7d4c7c06fb87b5e5d9e186ecaf56448a9b2df84->leave($__internal_76ac7e86c28651c1c91d7a8bc7d4c7c06fb87b5e5d9e186ecaf56448a9b2df84_prof);

    }

    public function getTemplateName()
    {
        return ":category:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 59,  107 => 53,  103 => 52,  97 => 50,  80 => 49,  76 => 47,  67 => 46,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/main.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{#{% block content%}
    <h1>Categories list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for category in categories %}
            <tr>
                <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                <td>{{ category.name }}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_show', { 'id': category.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('category_edit', { 'id': category.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('category_new') }}\">Create a new category</a>
        </li>
    </ul>
{% endblock %} #}

{% block content %}
    <div id=\"categories\">
      <table class=\"categories\">
        {% for category in categories %}
          <tr class=\"{{ cycle(['even', 'odd'], loop.index) }}\">
            <td>
              <a href=\"{{ path('category_show', { 'id': category.id }) }}\">
                {{ category.name }}
              </a>
            </td>
            
          </tr>
        {% endfor %}
      </table>
    </div>
{% endblock %}
", ":category:index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/category/index.html.twig");
    }
}
