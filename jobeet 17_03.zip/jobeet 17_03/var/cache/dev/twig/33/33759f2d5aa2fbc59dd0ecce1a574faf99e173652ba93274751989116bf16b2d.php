<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_0d8317a3fd0ec22eaf2fc0b395b7762cf7194e61fbe4efd96498ee899771b688 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1ba66a683cccd0dfff5ebdfe852c24e554f6553634fd279ce036f9ac9536d92c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1ba66a683cccd0dfff5ebdfe852c24e554f6553634fd279ce036f9ac9536d92c->enter($__internal_1ba66a683cccd0dfff5ebdfe852c24e554f6553634fd279ce036f9ac9536d92c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_885c7eddaf1b260f65311aa30886514c860b9bb795eb7a428170b1483c0c1da4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_885c7eddaf1b260f65311aa30886514c860b9bb795eb7a428170b1483c0c1da4->enter($__internal_885c7eddaf1b260f65311aa30886514c860b9bb795eb7a428170b1483c0c1da4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1ba66a683cccd0dfff5ebdfe852c24e554f6553634fd279ce036f9ac9536d92c->leave($__internal_1ba66a683cccd0dfff5ebdfe852c24e554f6553634fd279ce036f9ac9536d92c_prof);

        
        $__internal_885c7eddaf1b260f65311aa30886514c860b9bb795eb7a428170b1483c0c1da4->leave($__internal_885c7eddaf1b260f65311aa30886514c860b9bb795eb7a428170b1483c0c1da4_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_33bc9410d81c5d91b2b4778f489364f0108cb3da4ab611b13b9016d3844a1934 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_33bc9410d81c5d91b2b4778f489364f0108cb3da4ab611b13b9016d3844a1934->enter($__internal_33bc9410d81c5d91b2b4778f489364f0108cb3da4ab611b13b9016d3844a1934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_100cb2e1cb6ae37ddd7e51f868fdbc5c6c3f9dcba61e86f00fce5ea76f996e1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_100cb2e1cb6ae37ddd7e51f868fdbc5c6c3f9dcba61e86f00fce5ea76f996e1a->enter($__internal_100cb2e1cb6ae37ddd7e51f868fdbc5c6c3f9dcba61e86f00fce5ea76f996e1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_100cb2e1cb6ae37ddd7e51f868fdbc5c6c3f9dcba61e86f00fce5ea76f996e1a->leave($__internal_100cb2e1cb6ae37ddd7e51f868fdbc5c6c3f9dcba61e86f00fce5ea76f996e1a_prof);

        
        $__internal_33bc9410d81c5d91b2b4778f489364f0108cb3da4ab611b13b9016d3844a1934->leave($__internal_33bc9410d81c5d91b2b4778f489364f0108cb3da4ab611b13b9016d3844a1934_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_3ea1e8c045064e1e645ff8c58db558b6ef9e847ea9a0fbde67a0f9dd58aa3456 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ea1e8c045064e1e645ff8c58db558b6ef9e847ea9a0fbde67a0f9dd58aa3456->enter($__internal_3ea1e8c045064e1e645ff8c58db558b6ef9e847ea9a0fbde67a0f9dd58aa3456_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_86be71892cbf33aeeadb303a27d755edc354ac6a329eb76643bbc740d098281b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86be71892cbf33aeeadb303a27d755edc354ac6a329eb76643bbc740d098281b->enter($__internal_86be71892cbf33aeeadb303a27d755edc354ac6a329eb76643bbc740d098281b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_86be71892cbf33aeeadb303a27d755edc354ac6a329eb76643bbc740d098281b->leave($__internal_86be71892cbf33aeeadb303a27d755edc354ac6a329eb76643bbc740d098281b_prof);

        
        $__internal_3ea1e8c045064e1e645ff8c58db558b6ef9e847ea9a0fbde67a0f9dd58aa3456->leave($__internal_3ea1e8c045064e1e645ff8c58db558b6ef9e847ea9a0fbde67a0f9dd58aa3456_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
