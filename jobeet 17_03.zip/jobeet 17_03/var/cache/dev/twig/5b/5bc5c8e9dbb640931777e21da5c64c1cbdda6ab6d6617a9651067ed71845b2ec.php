<?php

/* job/index.html.twig */
class __TwigTemplate_90299236952703648a952c74bcf18b58276774d27a1f2318976ba30218dbc3e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4028cb05703ebeb07b2e66cbafae0dd2e4b6e9dbafd846d43025dc1796b928d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4028cb05703ebeb07b2e66cbafae0dd2e4b6e9dbafd846d43025dc1796b928d6->enter($__internal_4028cb05703ebeb07b2e66cbafae0dd2e4b6e9dbafd846d43025dc1796b928d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/index.html.twig"));

        $__internal_037e686ecffd7403a9d98d2d1cc59c1d40dfa2ab31230ac00064c093c170381c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_037e686ecffd7403a9d98d2d1cc59c1d40dfa2ab31230ac00064c093c170381c->enter($__internal_037e686ecffd7403a9d98d2d1cc59c1d40dfa2ab31230ac00064c093c170381c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4028cb05703ebeb07b2e66cbafae0dd2e4b6e9dbafd846d43025dc1796b928d6->leave($__internal_4028cb05703ebeb07b2e66cbafae0dd2e4b6e9dbafd846d43025dc1796b928d6_prof);

        
        $__internal_037e686ecffd7403a9d98d2d1cc59c1d40dfa2ab31230ac00064c093c170381c->leave($__internal_037e686ecffd7403a9d98d2d1cc59c1d40dfa2ab31230ac00064c093c170381c_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fe120fb61bc483502b7b298f141c22454a9c48ce28c0b3e72425535d9f5be8f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe120fb61bc483502b7b298f141c22454a9c48ce28c0b3e72425535d9f5be8f3->enter($__internal_fe120fb61bc483502b7b298f141c22454a9c48ce28c0b3e72425535d9f5be8f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6c01263ba926f1f9c38db1c1b71770cca26191c0ec44e8b48b835de2b2c3ead3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c01263ba926f1f9c38db1c1b71770cca26191c0ec44e8b48b835de2b2c3ead3->enter($__internal_6c01263ba926f1f9c38db1c1b71770cca26191c0ec44e8b48b835de2b2c3ead3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/jobs.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_6c01263ba926f1f9c38db1c1b71770cca26191c0ec44e8b48b835de2b2c3ead3->leave($__internal_6c01263ba926f1f9c38db1c1b71770cca26191c0ec44e8b48b835de2b2c3ead3_prof);

        
        $__internal_fe120fb61bc483502b7b298f141c22454a9c48ce28c0b3e72425535d9f5be8f3->leave($__internal_fe120fb61bc483502b7b298f141c22454a9c48ce28c0b3e72425535d9f5be8f3_prof);

    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        $__internal_d6b454da6fb710576a9c79d625267eb72f10aff411071816d105b699d5555ae8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6b454da6fb710576a9c79d625267eb72f10aff411071816d105b699d5555ae8->enter($__internal_d6b454da6fb710576a9c79d625267eb72f10aff411071816d105b699d5555ae8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_6e27faca15ac9bf87cc7239955017582cb18ed7d8b3c35cd3e7fdafa14928bc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e27faca15ac9bf87cc7239955017582cb18ed7d8b3c35cd3e7fdafa14928bc0->enter($__internal_6e27faca15ac9bf87cc7239955017582cb18ed7d8b3c35cd3e7fdafa14928bc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "    <div id=\"jobs\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 11
            echo "        <div>
            <div class=\"category_";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "slug", array()), "html", null, true);
            echo "\">
                <div class=\"feed\">
                  <a href=\"\">Feed</a>
                </div>
                <h1><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</a></h1>
            
            
            ";
            // line 19
            $this->loadTemplate("job/list.html.twig", "job/index.html.twig", 19)->display(array_merge($context, array("jobs" => $this->getAttribute($context["category"], "activejobs", array()))));
            // line 20
            echo "            
            ";
            // line 21
            if ($this->getAttribute($context["category"], "morejobs", array())) {
                // line 22
                echo "                <div class=\"more_jobs\">
                  and <a href=\"";
                // line 23
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "morejobs", array()), "html", null, true);
                echo "</a>
                  more...
                </div>
            ";
            }
            // line 27
            echo "            </div>
        </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "    </div>
";
        
        $__internal_6e27faca15ac9bf87cc7239955017582cb18ed7d8b3c35cd3e7fdafa14928bc0->leave($__internal_6e27faca15ac9bf87cc7239955017582cb18ed7d8b3c35cd3e7fdafa14928bc0_prof);

        
        $__internal_d6b454da6fb710576a9c79d625267eb72f10aff411071816d105b699d5555ae8->leave($__internal_d6b454da6fb710576a9c79d625267eb72f10aff411071816d105b699d5555ae8_prof);

    }

    public function getTemplateName()
    {
        return "job/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 30,  133 => 27,  124 => 23,  121 => 22,  119 => 21,  116 => 20,  114 => 19,  106 => 16,  99 => 12,  96 => 11,  79 => 10,  76 => 9,  67 => 8,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/jobs.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"jobs\">
        {% for category in categories %}
        <div>
            <div class=\"category_{{ category.slug }}\">
                <div class=\"feed\">
                  <a href=\"\">Feed</a>
                </div>
                <h1><a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.name }}</a></h1>
            
            
            {% include 'job/list.html.twig' with {'jobs': category.activejobs} %}
            
            {% if category.morejobs %}
                <div class=\"more_jobs\">
                  and <a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.morejobs }}</a>
                  more...
                </div>
            {% endif %}
            </div>
        </div>
        {% endfor %}
    </div>
{% endblock %}
", "job/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\index.html.twig");
    }
}
