<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_f124d37a05b2262eb56cd6ffd21cd10989e9b2c0d575529b58e1af382450dda8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_800f6538abcad9fa62fd49bd4f9d926e7091e54a2f227e531bd7188cf224943c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_800f6538abcad9fa62fd49bd4f9d926e7091e54a2f227e531bd7188cf224943c->enter($__internal_800f6538abcad9fa62fd49bd4f9d926e7091e54a2f227e531bd7188cf224943c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_f8b3d7436ce3534dd32b32730984511025a78b97b385b2e6f6196fcc221a59d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8b3d7436ce3534dd32b32730984511025a78b97b385b2e6f6196fcc221a59d8->enter($__internal_f8b3d7436ce3534dd32b32730984511025a78b97b385b2e6f6196fcc221a59d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_800f6538abcad9fa62fd49bd4f9d926e7091e54a2f227e531bd7188cf224943c->leave($__internal_800f6538abcad9fa62fd49bd4f9d926e7091e54a2f227e531bd7188cf224943c_prof);

        
        $__internal_f8b3d7436ce3534dd32b32730984511025a78b97b385b2e6f6196fcc221a59d8->leave($__internal_f8b3d7436ce3534dd32b32730984511025a78b97b385b2e6f6196fcc221a59d8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
