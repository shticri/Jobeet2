<?php

/* :category:edit.html.twig */
class __TwigTemplate_826792f3a49e47d05dd9a7d2076e9999d9934ce83b2206885385522b036779f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3903e60d7ba4004404e73a885c0b574fcce86bc7eec4487b4c4de1c8e3a7b6b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3903e60d7ba4004404e73a885c0b574fcce86bc7eec4487b4c4de1c8e3a7b6b7->enter($__internal_3903e60d7ba4004404e73a885c0b574fcce86bc7eec4487b4c4de1c8e3a7b6b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:edit.html.twig"));

        $__internal_3a4fc70e21d33bd99b4802bc10fb5f2e0fdee7d4fb6ff330caa73ad29e783a78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a4fc70e21d33bd99b4802bc10fb5f2e0fdee7d4fb6ff330caa73ad29e783a78->enter($__internal_3a4fc70e21d33bd99b4802bc10fb5f2e0fdee7d4fb6ff330caa73ad29e783a78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3903e60d7ba4004404e73a885c0b574fcce86bc7eec4487b4c4de1c8e3a7b6b7->leave($__internal_3903e60d7ba4004404e73a885c0b574fcce86bc7eec4487b4c4de1c8e3a7b6b7_prof);

        
        $__internal_3a4fc70e21d33bd99b4802bc10fb5f2e0fdee7d4fb6ff330caa73ad29e783a78->leave($__internal_3a4fc70e21d33bd99b4802bc10fb5f2e0fdee7d4fb6ff330caa73ad29e783a78_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0f364c5580992d4364961aa82d5986c3bc268df5e1cae7300f0123071a08371e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f364c5580992d4364961aa82d5986c3bc268df5e1cae7300f0123071a08371e->enter($__internal_0f364c5580992d4364961aa82d5986c3bc268df5e1cae7300f0123071a08371e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_08a09c208ffe062be371b1cf05c187a45009206ab07effaab97f004d96902f90 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08a09c208ffe062be371b1cf05c187a45009206ab07effaab97f004d96902f90->enter($__internal_08a09c208ffe062be371b1cf05c187a45009206ab07effaab97f004d96902f90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Category edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_08a09c208ffe062be371b1cf05c187a45009206ab07effaab97f004d96902f90->leave($__internal_08a09c208ffe062be371b1cf05c187a45009206ab07effaab97f004d96902f90_prof);

        
        $__internal_0f364c5580992d4364961aa82d5986c3bc268df5e1cae7300f0123071a08371e->leave($__internal_0f364c5580992d4364961aa82d5986c3bc268df5e1cae7300f0123071a08371e_prof);

    }

    public function getTemplateName()
    {
        return ":category:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Category edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('category_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":category:edit.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/category/edit.html.twig");
    }
}
