<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_0d6da3d269b57df170a380cd12cf14a9b588638f1fba119c9176bbf5197566c0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0cef0af4a9c26c47508fa56b62752f5132c3937bacde75fca4e3a290cd9f272f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0cef0af4a9c26c47508fa56b62752f5132c3937bacde75fca4e3a290cd9f272f->enter($__internal_0cef0af4a9c26c47508fa56b62752f5132c3937bacde75fca4e3a290cd9f272f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_c89892aca78f80df70a63160eba52462e814cebd2cbe653d6ac04f8afa118266 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c89892aca78f80df70a63160eba52462e814cebd2cbe653d6ac04f8afa118266->enter($__internal_c89892aca78f80df70a63160eba52462e814cebd2cbe653d6ac04f8afa118266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_0cef0af4a9c26c47508fa56b62752f5132c3937bacde75fca4e3a290cd9f272f->leave($__internal_0cef0af4a9c26c47508fa56b62752f5132c3937bacde75fca4e3a290cd9f272f_prof);

        
        $__internal_c89892aca78f80df70a63160eba52462e814cebd2cbe653d6ac04f8afa118266->leave($__internal_c89892aca78f80df70a63160eba52462e814cebd2cbe653d6ac04f8afa118266_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
