<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_7345753f1263fb07fdb6bb031c63503a12ea2307d17e7e833d223670dc9697be extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_efeaa996f2e91aa22882075b58a6f89ef87e34667c3c3cc50d2313165885c806 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efeaa996f2e91aa22882075b58a6f89ef87e34667c3c3cc50d2313165885c806->enter($__internal_efeaa996f2e91aa22882075b58a6f89ef87e34667c3c3cc50d2313165885c806_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_1e2ceee3485d70744c191445bbefdb218eaeae57d368dbe33420ab9c1e0aea4f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e2ceee3485d70744c191445bbefdb218eaeae57d368dbe33420ab9c1e0aea4f->enter($__internal_1e2ceee3485d70744c191445bbefdb218eaeae57d368dbe33420ab9c1e0aea4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_efeaa996f2e91aa22882075b58a6f89ef87e34667c3c3cc50d2313165885c806->leave($__internal_efeaa996f2e91aa22882075b58a6f89ef87e34667c3c3cc50d2313165885c806_prof);

        
        $__internal_1e2ceee3485d70744c191445bbefdb218eaeae57d368dbe33420ab9c1e0aea4f->leave($__internal_1e2ceee3485d70744c191445bbefdb218eaeae57d368dbe33420ab9c1e0aea4f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
