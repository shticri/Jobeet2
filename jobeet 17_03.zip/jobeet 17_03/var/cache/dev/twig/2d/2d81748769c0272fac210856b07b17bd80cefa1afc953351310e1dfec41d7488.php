<?php

/* JobeetBundle:Default:index.html.twig */
class __TwigTemplate_9f5f72222660f6c9a2fb505574b831a37cbace838a5a2a2512410810572263e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_34e6396de64f5971b8bb95947e964a0a74715baeb8deabdf865132ead8144a64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34e6396de64f5971b8bb95947e964a0a74715baeb8deabdf865132ead8144a64->enter($__internal_34e6396de64f5971b8bb95947e964a0a74715baeb8deabdf865132ead8144a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JobeetBundle:Default:index.html.twig"));

        $__internal_b305be701b8478c51c671751f4b238ae7ef28a34e8e874636c510bb2c8664b0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b305be701b8478c51c671751f4b238ae7ef28a34e8e874636c510bb2c8664b0e->enter($__internal_b305be701b8478c51c671751f4b238ae7ef28a34e8e874636c510bb2c8664b0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JobeetBundle:Default:index.html.twig"));

        // line 1
        echo "Hello Cristina!
";
        
        $__internal_34e6396de64f5971b8bb95947e964a0a74715baeb8deabdf865132ead8144a64->leave($__internal_34e6396de64f5971b8bb95947e964a0a74715baeb8deabdf865132ead8144a64_prof);

        
        $__internal_b305be701b8478c51c671751f4b238ae7ef28a34e8e874636c510bb2c8664b0e->leave($__internal_b305be701b8478c51c671751f4b238ae7ef28a34e8e874636c510bb2c8664b0e_prof);

    }

    public function getTemplateName()
    {
        return "JobeetBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello Cristina!
", "JobeetBundle:Default:index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\src\\Epfc\\JobeetBundle/Resources/views/Default/index.html.twig");
    }
}
