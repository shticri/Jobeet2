<?php

/* :affiliate:edit.html.twig */
class __TwigTemplate_d53eaee97780a2f35689c1f11262a14f51bcdc0587e0f6bfd84c3f79f7b93028 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":affiliate:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_632242ebbbcb75ec0868f51e9b8b5deb983760de22a6cacab9fce56a590b1899 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_632242ebbbcb75ec0868f51e9b8b5deb983760de22a6cacab9fce56a590b1899->enter($__internal_632242ebbbcb75ec0868f51e9b8b5deb983760de22a6cacab9fce56a590b1899_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":affiliate:edit.html.twig"));

        $__internal_95f38589aa208ef40592f53d6a51c92113e7fe4bc7b3eb6199006c893639a8d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95f38589aa208ef40592f53d6a51c92113e7fe4bc7b3eb6199006c893639a8d1->enter($__internal_95f38589aa208ef40592f53d6a51c92113e7fe4bc7b3eb6199006c893639a8d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":affiliate:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_632242ebbbcb75ec0868f51e9b8b5deb983760de22a6cacab9fce56a590b1899->leave($__internal_632242ebbbcb75ec0868f51e9b8b5deb983760de22a6cacab9fce56a590b1899_prof);

        
        $__internal_95f38589aa208ef40592f53d6a51c92113e7fe4bc7b3eb6199006c893639a8d1->leave($__internal_95f38589aa208ef40592f53d6a51c92113e7fe4bc7b3eb6199006c893639a8d1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_98f0e2a1f4e47868d17c706d17e518a6f471449503efdeac464916f48bb0b8ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98f0e2a1f4e47868d17c706d17e518a6f471449503efdeac464916f48bb0b8ca->enter($__internal_98f0e2a1f4e47868d17c706d17e518a6f471449503efdeac464916f48bb0b8ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_823dc9e380646a17c0388354ff3f4e1492169264e53910f70261e3331c365348 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_823dc9e380646a17c0388354ff3f4e1492169264e53910f70261e3331c365348->enter($__internal_823dc9e380646a17c0388354ff3f4e1492169264e53910f70261e3331c365348_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Affiliate edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_823dc9e380646a17c0388354ff3f4e1492169264e53910f70261e3331c365348->leave($__internal_823dc9e380646a17c0388354ff3f4e1492169264e53910f70261e3331c365348_prof);

        
        $__internal_98f0e2a1f4e47868d17c706d17e518a6f471449503efdeac464916f48bb0b8ca->leave($__internal_98f0e2a1f4e47868d17c706d17e518a6f471449503efdeac464916f48bb0b8ca_prof);

    }

    public function getTemplateName()
    {
        return ":affiliate:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Affiliate edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('affiliate_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":affiliate:edit.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/affiliate/edit.html.twig");
    }
}
