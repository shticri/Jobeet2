<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_9a6d5f7db34d8bfb78f904a4ffb0f245ac568bf24fbbbf9b5594f504735cc98f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b62864fcaf989ceea73fd1bc7e9c0d547110814d6c13895e16d6247cb9cf09d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b62864fcaf989ceea73fd1bc7e9c0d547110814d6c13895e16d6247cb9cf09d->enter($__internal_8b62864fcaf989ceea73fd1bc7e9c0d547110814d6c13895e16d6247cb9cf09d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_803715401f3f4d27fc5b3b53a2ecb586d35ae29a40238abe05e147cc5d268637 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_803715401f3f4d27fc5b3b53a2ecb586d35ae29a40238abe05e147cc5d268637->enter($__internal_803715401f3f4d27fc5b3b53a2ecb586d35ae29a40238abe05e147cc5d268637_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_8b62864fcaf989ceea73fd1bc7e9c0d547110814d6c13895e16d6247cb9cf09d->leave($__internal_8b62864fcaf989ceea73fd1bc7e9c0d547110814d6c13895e16d6247cb9cf09d_prof);

        
        $__internal_803715401f3f4d27fc5b3b53a2ecb586d35ae29a40238abe05e147cc5d268637->leave($__internal_803715401f3f4d27fc5b3b53a2ecb586d35ae29a40238abe05e147cc5d268637_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
