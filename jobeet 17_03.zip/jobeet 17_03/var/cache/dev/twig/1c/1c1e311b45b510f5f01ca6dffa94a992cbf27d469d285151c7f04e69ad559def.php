<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_633e562032fc2c207cb7b9d09c6a739a81d66b6c442451a74eeb29393ef2e537 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e5407b1df5d147e71e8deda0795770176caa8456ebb848183105dd4914ffac8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e5407b1df5d147e71e8deda0795770176caa8456ebb848183105dd4914ffac8->enter($__internal_1e5407b1df5d147e71e8deda0795770176caa8456ebb848183105dd4914ffac8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_8dcdd7ea30f9f178b2de17f99b61dfabf29c5cb1063e9b62bdfe218a7c6c6a6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8dcdd7ea30f9f178b2de17f99b61dfabf29c5cb1063e9b62bdfe218a7c6c6a6a->enter($__internal_8dcdd7ea30f9f178b2de17f99b61dfabf29c5cb1063e9b62bdfe218a7c6c6a6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_1e5407b1df5d147e71e8deda0795770176caa8456ebb848183105dd4914ffac8->leave($__internal_1e5407b1df5d147e71e8deda0795770176caa8456ebb848183105dd4914ffac8_prof);

        
        $__internal_8dcdd7ea30f9f178b2de17f99b61dfabf29c5cb1063e9b62bdfe218a7c6c6a6a->leave($__internal_8dcdd7ea30f9f178b2de17f99b61dfabf29c5cb1063e9b62bdfe218a7c6c6a6a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}
