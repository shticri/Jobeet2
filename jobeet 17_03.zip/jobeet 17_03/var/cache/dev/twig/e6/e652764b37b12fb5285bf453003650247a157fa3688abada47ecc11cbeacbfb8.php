<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_ba2c9c6653249656a5b527bfb1a065ad7669a2343aa93f250caf2227fcfe53ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e7254ae5690f3b36c85abd157e39d6784a359f4fc6d10f224e9039f205062a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e7254ae5690f3b36c85abd157e39d6784a359f4fc6d10f224e9039f205062a9->enter($__internal_4e7254ae5690f3b36c85abd157e39d6784a359f4fc6d10f224e9039f205062a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_5e57c63735987ca03ccdd5e68376d90b07d1a362ec8a72f3b06dd044be41db96 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e57c63735987ca03ccdd5e68376d90b07d1a362ec8a72f3b06dd044be41db96->enter($__internal_5e57c63735987ca03ccdd5e68376d90b07d1a362ec8a72f3b06dd044be41db96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_4e7254ae5690f3b36c85abd157e39d6784a359f4fc6d10f224e9039f205062a9->leave($__internal_4e7254ae5690f3b36c85abd157e39d6784a359f4fc6d10f224e9039f205062a9_prof);

        
        $__internal_5e57c63735987ca03ccdd5e68376d90b07d1a362ec8a72f3b06dd044be41db96->leave($__internal_5e57c63735987ca03ccdd5e68376d90b07d1a362ec8a72f3b06dd044be41db96_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
