<?php

/* :job:edit.html.twig */
class __TwigTemplate_5f050d697700cd7190a18312f82805c83486d4591e06abb722444ca3bb1dd275 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":job:edit.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a08b4b4e6aeb11b2a64b833913f63182eb64ecda679d9e8ca5916bd041db459b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a08b4b4e6aeb11b2a64b833913f63182eb64ecda679d9e8ca5916bd041db459b->enter($__internal_a08b4b4e6aeb11b2a64b833913f63182eb64ecda679d9e8ca5916bd041db459b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:edit.html.twig"));

        $__internal_2145b2b02b8d3cc5aed02e87246f6a4d8abb8c1593a77eb557d2bdfc3bb2ab49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2145b2b02b8d3cc5aed02e87246f6a4d8abb8c1593a77eb557d2bdfc3bb2ab49->enter($__internal_2145b2b02b8d3cc5aed02e87246f6a4d8abb8c1593a77eb557d2bdfc3bb2ab49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a08b4b4e6aeb11b2a64b833913f63182eb64ecda679d9e8ca5916bd041db459b->leave($__internal_a08b4b4e6aeb11b2a64b833913f63182eb64ecda679d9e8ca5916bd041db459b_prof);

        
        $__internal_2145b2b02b8d3cc5aed02e87246f6a4d8abb8c1593a77eb557d2bdfc3bb2ab49->leave($__internal_2145b2b02b8d3cc5aed02e87246f6a4d8abb8c1593a77eb557d2bdfc3bb2ab49_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_2b8ca900bcf243363d70128dbd5be555d9e67dd49497c532a960bb64df25cebd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b8ca900bcf243363d70128dbd5be555d9e67dd49497c532a960bb64df25cebd->enter($__internal_2b8ca900bcf243363d70128dbd5be555d9e67dd49497c532a960bb64df25cebd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_521e950cee9f068c8dc07a0d42d6c13f01b26a8dad7762fdc50811fd8f04e8cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_521e950cee9f068c8dc07a0d42d6c13f01b26a8dad7762fdc50811fd8f04e8cd->enter($__internal_521e950cee9f068c8dc07a0d42d6c13f01b26a8dad7762fdc50811fd8f04e8cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Job edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_521e950cee9f068c8dc07a0d42d6c13f01b26a8dad7762fdc50811fd8f04e8cd->leave($__internal_521e950cee9f068c8dc07a0d42d6c13f01b26a8dad7762fdc50811fd8f04e8cd_prof);

        
        $__internal_2b8ca900bcf243363d70128dbd5be555d9e67dd49497c532a960bb64df25cebd->leave($__internal_2b8ca900bcf243363d70128dbd5be555d9e67dd49497c532a960bb64df25cebd_prof);

    }

    public function getTemplateName()
    {
        return ":job:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block content %}
    <h1>Job edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('job_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", ":job:edit.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/job/edit.html.twig");
    }
}
