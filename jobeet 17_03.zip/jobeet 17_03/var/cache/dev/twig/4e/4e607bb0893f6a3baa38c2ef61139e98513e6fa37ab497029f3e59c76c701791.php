<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_415ead967e717ee7456672796cc78232cafb69075362f92cbf8c3e651373f519 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_563786e00ad288600f0cd67200255da4a8ad181ab1c88f1811d8397ab96565de = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_563786e00ad288600f0cd67200255da4a8ad181ab1c88f1811d8397ab96565de->enter($__internal_563786e00ad288600f0cd67200255da4a8ad181ab1c88f1811d8397ab96565de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_999ccc24897e2f53d9307efb07e426455b92f7f4884e1bbf12a62fe29280e4a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_999ccc24897e2f53d9307efb07e426455b92f7f4884e1bbf12a62fe29280e4a6->enter($__internal_999ccc24897e2f53d9307efb07e426455b92f7f4884e1bbf12a62fe29280e4a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_563786e00ad288600f0cd67200255da4a8ad181ab1c88f1811d8397ab96565de->leave($__internal_563786e00ad288600f0cd67200255da4a8ad181ab1c88f1811d8397ab96565de_prof);

        
        $__internal_999ccc24897e2f53d9307efb07e426455b92f7f4884e1bbf12a62fe29280e4a6->leave($__internal_999ccc24897e2f53d9307efb07e426455b92f7f4884e1bbf12a62fe29280e4a6_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_9904f8e7648e370a44f26b0b83cdf3446d6bb43242a78ab060dac2baa0ac3756 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9904f8e7648e370a44f26b0b83cdf3446d6bb43242a78ab060dac2baa0ac3756->enter($__internal_9904f8e7648e370a44f26b0b83cdf3446d6bb43242a78ab060dac2baa0ac3756_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_beb46f84e32a6db5dc154b93318d6189e101dcf338a09084b726cd8f509fe732 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_beb46f84e32a6db5dc154b93318d6189e101dcf338a09084b726cd8f509fe732->enter($__internal_beb46f84e32a6db5dc154b93318d6189e101dcf338a09084b726cd8f509fe732_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_beb46f84e32a6db5dc154b93318d6189e101dcf338a09084b726cd8f509fe732->leave($__internal_beb46f84e32a6db5dc154b93318d6189e101dcf338a09084b726cd8f509fe732_prof);

        
        $__internal_9904f8e7648e370a44f26b0b83cdf3446d6bb43242a78ab060dac2baa0ac3756->leave($__internal_9904f8e7648e370a44f26b0b83cdf3446d6bb43242a78ab060dac2baa0ac3756_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_931aaa27ce1f4e534eb26906ff63d1ad3f8e68be32b5104912110cede768d8f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_931aaa27ce1f4e534eb26906ff63d1ad3f8e68be32b5104912110cede768d8f2->enter($__internal_931aaa27ce1f4e534eb26906ff63d1ad3f8e68be32b5104912110cede768d8f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_9d100829fa56e64d366434fb5fde01d0cab0d500bb517f1a917416daa108674a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d100829fa56e64d366434fb5fde01d0cab0d500bb517f1a917416daa108674a->enter($__internal_9d100829fa56e64d366434fb5fde01d0cab0d500bb517f1a917416daa108674a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_9d100829fa56e64d366434fb5fde01d0cab0d500bb517f1a917416daa108674a->leave($__internal_9d100829fa56e64d366434fb5fde01d0cab0d500bb517f1a917416daa108674a_prof);

        
        $__internal_931aaa27ce1f4e534eb26906ff63d1ad3f8e68be32b5104912110cede768d8f2->leave($__internal_931aaa27ce1f4e534eb26906ff63d1ad3f8e68be32b5104912110cede768d8f2_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_cb3227e9c2ee72214f49b3cea1833a2bda28b44081c132f1d54d70636f210040 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb3227e9c2ee72214f49b3cea1833a2bda28b44081c132f1d54d70636f210040->enter($__internal_cb3227e9c2ee72214f49b3cea1833a2bda28b44081c132f1d54d70636f210040_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_fd6179e341d8372716cadc0ba908d8fdf56ea14c37cc62ec3ae61b41002bb59c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd6179e341d8372716cadc0ba908d8fdf56ea14c37cc62ec3ae61b41002bb59c->enter($__internal_fd6179e341d8372716cadc0ba908d8fdf56ea14c37cc62ec3ae61b41002bb59c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_fd6179e341d8372716cadc0ba908d8fdf56ea14c37cc62ec3ae61b41002bb59c->leave($__internal_fd6179e341d8372716cadc0ba908d8fdf56ea14c37cc62ec3ae61b41002bb59c_prof);

        
        $__internal_cb3227e9c2ee72214f49b3cea1833a2bda28b44081c132f1d54d70636f210040->leave($__internal_cb3227e9c2ee72214f49b3cea1833a2bda28b44081c132f1d54d70636f210040_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
