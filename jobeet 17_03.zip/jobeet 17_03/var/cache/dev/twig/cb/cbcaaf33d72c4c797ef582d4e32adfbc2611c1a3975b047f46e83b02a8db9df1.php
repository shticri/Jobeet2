<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_de1f5f72e120339d190fec1b11a3597a53c62af32e76a907f28ce77092c7d32d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b1427c8f81d651a6c3e9fe1e6933d455e1d32ed1c70811b5872e3dafa1b7c79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b1427c8f81d651a6c3e9fe1e6933d455e1d32ed1c70811b5872e3dafa1b7c79->enter($__internal_5b1427c8f81d651a6c3e9fe1e6933d455e1d32ed1c70811b5872e3dafa1b7c79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_020f17d22426c46c2655c12c61d3ed2d56297be0f45a61f287594b050b6d468f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_020f17d22426c46c2655c12c61d3ed2d56297be0f45a61f287594b050b6d468f->enter($__internal_020f17d22426c46c2655c12c61d3ed2d56297be0f45a61f287594b050b6d468f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_5b1427c8f81d651a6c3e9fe1e6933d455e1d32ed1c70811b5872e3dafa1b7c79->leave($__internal_5b1427c8f81d651a6c3e9fe1e6933d455e1d32ed1c70811b5872e3dafa1b7c79_prof);

        
        $__internal_020f17d22426c46c2655c12c61d3ed2d56297be0f45a61f287594b050b6d468f->leave($__internal_020f17d22426c46c2655c12c61d3ed2d56297be0f45a61f287594b050b6d468f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.rdf.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
