<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_e6a617f70ceb20ccf700a800676314ea2830de0d56a1bd622841f731eda41c61 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15acbb928e4106ec4218e70a137e962fc7d1d77340ebde1c7a5e7d4089f87912 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15acbb928e4106ec4218e70a137e962fc7d1d77340ebde1c7a5e7d4089f87912->enter($__internal_15acbb928e4106ec4218e70a137e962fc7d1d77340ebde1c7a5e7d4089f87912_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_5d37ce91e4dc3b4c22752aaadacbaf0d46ce508c73d395c9af5135d10c7d2be8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5d37ce91e4dc3b4c22752aaadacbaf0d46ce508c73d395c9af5135d10c7d2be8->enter($__internal_5d37ce91e4dc3b4c22752aaadacbaf0d46ce508c73d395c9af5135d10c7d2be8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_15acbb928e4106ec4218e70a137e962fc7d1d77340ebde1c7a5e7d4089f87912->leave($__internal_15acbb928e4106ec4218e70a137e962fc7d1d77340ebde1c7a5e7d4089f87912_prof);

        
        $__internal_5d37ce91e4dc3b4c22752aaadacbaf0d46ce508c73d395c9af5135d10c7d2be8->leave($__internal_5d37ce91e4dc3b4c22752aaadacbaf0d46ce508c73d395c9af5135d10c7d2be8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
