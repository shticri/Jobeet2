<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_01fed0029900e44b2838fb67e2d9354201c506726aa420fb8cab8ade03165235 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2eba2a045c4213d9c916f8ebba8eba69f5b9065c4d8bf1ca3f89d765a0eb2af2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2eba2a045c4213d9c916f8ebba8eba69f5b9065c4d8bf1ca3f89d765a0eb2af2->enter($__internal_2eba2a045c4213d9c916f8ebba8eba69f5b9065c4d8bf1ca3f89d765a0eb2af2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_e06f101bbc41a80145796abdd340c450fa7c262cd60b8984941452d6d48433a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e06f101bbc41a80145796abdd340c450fa7c262cd60b8984941452d6d48433a6->enter($__internal_e06f101bbc41a80145796abdd340c450fa7c262cd60b8984941452d6d48433a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_2eba2a045c4213d9c916f8ebba8eba69f5b9065c4d8bf1ca3f89d765a0eb2af2->leave($__internal_2eba2a045c4213d9c916f8ebba8eba69f5b9065c4d8bf1ca3f89d765a0eb2af2_prof);

        
        $__internal_e06f101bbc41a80145796abdd340c450fa7c262cd60b8984941452d6d48433a6->leave($__internal_e06f101bbc41a80145796abdd340c450fa7c262cd60b8984941452d6d48433a6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "@Twig/Exception/exception.rdf.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
