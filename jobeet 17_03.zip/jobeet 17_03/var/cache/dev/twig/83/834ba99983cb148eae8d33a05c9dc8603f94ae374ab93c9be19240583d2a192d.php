<?php

/* :category:show.html.twig */
class __TwigTemplate_52eacc7eb06554d696c388d69082f3e42e6e767153211fc28d1245992f71b0a2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":category:show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76c1332f0b62054709060db05c1ee03d2a35f8f1ebef0661e4e162b84372f8f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76c1332f0b62054709060db05c1ee03d2a35f8f1ebef0661e4e162b84372f8f3->enter($__internal_76c1332f0b62054709060db05c1ee03d2a35f8f1ebef0661e4e162b84372f8f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:show.html.twig"));

        $__internal_cd536a40c28757e18a50167c3c5d59cd494d37b7fab13d6b05d06096653fb253 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd536a40c28757e18a50167c3c5d59cd494d37b7fab13d6b05d06096653fb253->enter($__internal_cd536a40c28757e18a50167c3c5d59cd494d37b7fab13d6b05d06096653fb253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":category:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76c1332f0b62054709060db05c1ee03d2a35f8f1ebef0661e4e162b84372f8f3->leave($__internal_76c1332f0b62054709060db05c1ee03d2a35f8f1ebef0661e4e162b84372f8f3_prof);

        
        $__internal_cd536a40c28757e18a50167c3c5d59cd494d37b7fab13d6b05d06096653fb253->leave($__internal_cd536a40c28757e18a50167c3c5d59cd494d37b7fab13d6b05d06096653fb253_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1ca854cad8b0f06cbc32d6233999e5caea6f12382476234bf912370643f1064f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1ca854cad8b0f06cbc32d6233999e5caea6f12382476234bf912370643f1064f->enter($__internal_1ca854cad8b0f06cbc32d6233999e5caea6f12382476234bf912370643f1064f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_1b9e1faf610ea9a81c9466a5a7cf7e2a0828915405cd1ea49084629fab21c8c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b9e1faf610ea9a81c9466a5a7cf7e2a0828915405cd1ea49084629fab21c8c4->enter($__internal_1b9e1faf610ea9a81c9466a5a7cf7e2a0828915405cd1ea49084629fab21c8c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "  Jobs in the ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
        echo " category
";
        
        $__internal_1b9e1faf610ea9a81c9466a5a7cf7e2a0828915405cd1ea49084629fab21c8c4->leave($__internal_1b9e1faf610ea9a81c9466a5a7cf7e2a0828915405cd1ea49084629fab21c8c4_prof);

        
        $__internal_1ca854cad8b0f06cbc32d6233999e5caea6f12382476234bf912370643f1064f->leave($__internal_1ca854cad8b0f06cbc32d6233999e5caea6f12382476234bf912370643f1064f_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d6972c018cd3453d4526470466d622b0e2a87735b726cf1e31918d3a10c29493 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6972c018cd3453d4526470466d622b0e2a87735b726cf1e31918d3a10c29493->enter($__internal_d6972c018cd3453d4526470466d622b0e2a87735b726cf1e31918d3a10c29493_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_dd4ba169dd258e7932b40a58c2cb42a50f598b0473158d1bc3fea71a096e37ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd4ba169dd258e7932b40a58c2cb42a50f598b0473158d1bc3fea71a096e37ce->enter($__internal_dd4ba169dd258e7932b40a58c2cb42a50f598b0473158d1bc3fea71a096e37ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/jobs.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_dd4ba169dd258e7932b40a58c2cb42a50f598b0473158d1bc3fea71a096e37ce->leave($__internal_dd4ba169dd258e7932b40a58c2cb42a50f598b0473158d1bc3fea71a096e37ce_prof);

        
        $__internal_d6972c018cd3453d4526470466d622b0e2a87735b726cf1e31918d3a10c29493->leave($__internal_d6972c018cd3453d4526470466d622b0e2a87735b726cf1e31918d3a10c29493_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_e651e4b5fc9bd30cca53b305ac31c11db7eeaa2a0648e1e3dcf1af80fabaa67b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e651e4b5fc9bd30cca53b305ac31c11db7eeaa2a0648e1e3dcf1af80fabaa67b->enter($__internal_e651e4b5fc9bd30cca53b305ac31c11db7eeaa2a0648e1e3dcf1af80fabaa67b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_d70ce08bcebee310d08ba7763cbb3fb6163cec320cba5ae235ee5e349fd2ecf6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d70ce08bcebee310d08ba7763cbb3fb6163cec320cba5ae235ee5e349fd2ecf6->enter($__internal_d70ce08bcebee310d08ba7763cbb3fb6163cec320cba5ae235ee5e349fd2ecf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 13
        echo "  <div class=\"category\">
    <div class=\"feed\">
      <a href=\"\">Feed</a>
    </div>
    <h1>";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "name", array()), "html", null, true);
        echo "</h1>
  </div>
 
  ";
        // line 20
        $this->loadTemplate("job/list.html.twig", ":category:show.html.twig", 20)->display(array_merge($context, array("jobs" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "activejobs", array()))));
        // line 21
        echo "  
  ";
        // line 22
        if (((isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")) > 1)) {
            // line 23
            echo "    <div class=\"pagination\">
      <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => 1)), "html", null, true);
            echo "\">
        <img src=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/first.png"), "html", null, true);
            echo "\" alt=\"First page\" title=\"First page\" />
      </a>
 
      <a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["previous_page"]) ? $context["previous_page"] : $this->getContext($context, "previous_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/previous.png"), "html", null, true);
            echo "\" alt=\"Previous page\" title=\"Previous page\" />
      </a>
 
      ";
            // line 32
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page"))));
            foreach ($context['_seq'] as $context["_key"] => $context["page"]) {
                // line 33
                echo "        ";
                if (($context["page"] == (isset($context["current_page"]) ? $context["current_page"] : $this->getContext($context, "current_page")))) {
                    // line 34
                    echo "          ";
                    echo twig_escape_filter($this->env, $context["page"], "html", null, true);
                    echo "
        ";
                } else {
                    // line 36
                    echo "          <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => $context["page"])), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $context["page"], "html", null, true);
                    echo "</a>
        ";
                }
                // line 38
                echo "      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['page'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 39
            echo " 
      <a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["next_page"]) ? $context["next_page"] : $this->getContext($context, "next_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 41
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/next.png"), "html", null, true);
            echo "\" alt=\"Next page\" title=\"Next page\" />
      </a>
 
      <a href=\"";
            // line 44
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute((isset($context["category"]) ? $context["category"] : $this->getContext($context, "category")), "slug", array()), "page" => (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")))), "html", null, true);
            echo "\">
        <img src=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/last.png"), "html", null, true);
            echo "\" alt=\"Last page\" title=\"Last page\" />
      </a>
    </div>
  ";
        }
        // line 49
        echo " 
  <div class=\"pagination_desc\">
    <strong>";
        // line 51
        echo twig_escape_filter($this->env, (isset($context["total_jobs"]) ? $context["total_jobs"] : $this->getContext($context, "total_jobs")), "html", null, true);
        echo "</strong> jobs in this category
 
    ";
        // line 53
        if (((isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")) > 1)) {
            // line 54
            echo "      - page <strong>";
            echo twig_escape_filter($this->env, (isset($context["current_page"]) ? $context["current_page"] : $this->getContext($context, "current_page")), "html", null, true);
            echo "/";
            echo twig_escape_filter($this->env, (isset($context["last_page"]) ? $context["last_page"] : $this->getContext($context, "last_page")), "html", null, true);
            echo "</strong>
    ";
        }
        // line 56
        echo "  </div>
";
        
        $__internal_d70ce08bcebee310d08ba7763cbb3fb6163cec320cba5ae235ee5e349fd2ecf6->leave($__internal_d70ce08bcebee310d08ba7763cbb3fb6163cec320cba5ae235ee5e349fd2ecf6_prof);

        
        $__internal_e651e4b5fc9bd30cca53b305ac31c11db7eeaa2a0648e1e3dcf1af80fabaa67b->leave($__internal_e651e4b5fc9bd30cca53b305ac31c11db7eeaa2a0648e1e3dcf1af80fabaa67b_prof);

    }

    public function getTemplateName()
    {
        return ":category:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  211 => 56,  203 => 54,  201 => 53,  196 => 51,  192 => 49,  185 => 45,  181 => 44,  175 => 41,  171 => 40,  168 => 39,  162 => 38,  154 => 36,  148 => 34,  145 => 33,  141 => 32,  135 => 29,  131 => 28,  125 => 25,  121 => 24,  118 => 23,  116 => 22,  113 => 21,  111 => 20,  105 => 17,  99 => 13,  90 => 12,  78 => 9,  73 => 8,  64 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
  Jobs in the {{ category.name }} category
{% endblock %}
 
{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/jobs.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
  <div class=\"category\">
    <div class=\"feed\">
      <a href=\"\">Feed</a>
    </div>
    <h1>{{ category.name }}</h1>
  </div>
 
  {% include 'job/list.html.twig' with {'jobs': category.activejobs} %}
  
  {% if last_page > 1 %}
    <div class=\"pagination\">
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': 1 }) }}\">
        <img src=\"{{ asset('public/images/first.png') }}\" alt=\"First page\" title=\"First page\" />
      </a>
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': previous_page }) }}\">
        <img src=\"{{ asset('public/images/previous.png') }}\" alt=\"Previous page\" title=\"Previous page\" />
      </a>
 
      {% for page in 1..last_page %}
        {% if page == current_page %}
          {{ page }}
        {% else %}
          <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': page }) }}\">{{ page }}</a>
        {% endif %}
      {% endfor %}
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': next_page }) }}\">
        <img src=\"{{ asset('public/images/next.png') }}\" alt=\"Next page\" title=\"Next page\" />
      </a>
 
      <a href=\"{{ path('category_show', { 'slug': category.slug, 'page': last_page }) }}\">
        <img src=\"{{ asset('public/images/last.png') }}\" alt=\"Last page\" title=\"Last page\" />
      </a>
    </div>
  {% endif %}
 
  <div class=\"pagination_desc\">
    <strong>{{ total_jobs }}</strong> jobs in this category
 
    {% if last_page > 1 %}
      - page <strong>{{ current_page }}/{{ last_page }}</strong>
    {% endif %}
  </div>
{% endblock %}
", ":category:show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/category/show.html.twig");
    }
}
