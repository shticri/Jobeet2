<?php

/* :job:index.html.twig */
class __TwigTemplate_4d83d3379a1ab17c0e87e97f7289a8a4226cd9a649da094130cd698a4fd6677c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":job:index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8b964de8de9f35ef7306614b6dc67cbbbb5534ef9e29fd55fcb6415d7cb961b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8b964de8de9f35ef7306614b6dc67cbbbb5534ef9e29fd55fcb6415d7cb961b5->enter($__internal_8b964de8de9f35ef7306614b6dc67cbbbb5534ef9e29fd55fcb6415d7cb961b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:index.html.twig"));

        $__internal_49447f71004a2914b9d1fea599d3f5a21b0750d203f2838dceb19f42266a99e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49447f71004a2914b9d1fea599d3f5a21b0750d203f2838dceb19f42266a99e7->enter($__internal_49447f71004a2914b9d1fea599d3f5a21b0750d203f2838dceb19f42266a99e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":job:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8b964de8de9f35ef7306614b6dc67cbbbb5534ef9e29fd55fcb6415d7cb961b5->leave($__internal_8b964de8de9f35ef7306614b6dc67cbbbb5534ef9e29fd55fcb6415d7cb961b5_prof);

        
        $__internal_49447f71004a2914b9d1fea599d3f5a21b0750d203f2838dceb19f42266a99e7->leave($__internal_49447f71004a2914b9d1fea599d3f5a21b0750d203f2838dceb19f42266a99e7_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a3d04744128e6e3181e9a6656a01c144fed1c445cb65c557280b4b9fd439a8fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3d04744128e6e3181e9a6656a01c144fed1c445cb65c557280b4b9fd439a8fe->enter($__internal_a3d04744128e6e3181e9a6656a01c144fed1c445cb65c557280b4b9fd439a8fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8fd9aaed1fa2c0f39d1b7c3f523bc879e60a57b80fa1fa25a19ca602e6b2bf42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fd9aaed1fa2c0f39d1b7c3f523bc879e60a57b80fa1fa25a19ca602e6b2bf42->enter($__internal_8fd9aaed1fa2c0f39d1b7c3f523bc879e60a57b80fa1fa25a19ca602e6b2bf42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/jobs.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_8fd9aaed1fa2c0f39d1b7c3f523bc879e60a57b80fa1fa25a19ca602e6b2bf42->leave($__internal_8fd9aaed1fa2c0f39d1b7c3f523bc879e60a57b80fa1fa25a19ca602e6b2bf42_prof);

        
        $__internal_a3d04744128e6e3181e9a6656a01c144fed1c445cb65c557280b4b9fd439a8fe->leave($__internal_a3d04744128e6e3181e9a6656a01c144fed1c445cb65c557280b4b9fd439a8fe_prof);

    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        $__internal_a99aca4c90d4fd4a49198254124fea4fa024b1c41cc0e378ced9d8db41ce6bfd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a99aca4c90d4fd4a49198254124fea4fa024b1c41cc0e378ced9d8db41ce6bfd->enter($__internal_a99aca4c90d4fd4a49198254124fea4fa024b1c41cc0e378ced9d8db41ce6bfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_93c5ce9132411d3f99776d68039d9a198359385e65b03200a05def963c150c88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93c5ce9132411d3f99776d68039d9a198359385e65b03200a05def963c150c88->enter($__internal_93c5ce9132411d3f99776d68039d9a198359385e65b03200a05def963c150c88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "    <div id=\"jobs\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 11
            echo "        <div>
          <div class=\"category_";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "slug", array()), "html", null, true);
            echo "\">
            <div class=\"feed\">
              <a href=\"\">Feed</a>
            </div>
            <h1><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</a></h1>
          </div>
            
            ";
            // line 19
            $this->loadTemplate("job/list.html.twig", ":job:index.html.twig", 19)->display(array_merge($context, array("jobs" => $this->getAttribute($context["category"], "activejobs", array()))));
            // line 20
            echo "            
            ";
            // line 21
            if ($this->getAttribute($context["category"], "morejobs", array())) {
                // line 22
                echo "                <div class=\"more_jobs\">
                  and <a href=\"";
                // line 23
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "morejobs", array()), "html", null, true);
                echo "</a>
                  more...
                </div>
            ";
            }
            // line 27
            echo "        </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "    </div>
";
        
        $__internal_93c5ce9132411d3f99776d68039d9a198359385e65b03200a05def963c150c88->leave($__internal_93c5ce9132411d3f99776d68039d9a198359385e65b03200a05def963c150c88_prof);

        
        $__internal_a99aca4c90d4fd4a49198254124fea4fa024b1c41cc0e378ced9d8db41ce6bfd->leave($__internal_a99aca4c90d4fd4a49198254124fea4fa024b1c41cc0e378ced9d8db41ce6bfd_prof);

    }

    public function getTemplateName()
    {
        return ":job:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  148 => 29,  133 => 27,  124 => 23,  121 => 22,  119 => 21,  116 => 20,  114 => 19,  106 => 16,  99 => 12,  96 => 11,  79 => 10,  76 => 9,  67 => 8,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/jobs.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"jobs\">
        {% for category in categories %}
        <div>
          <div class=\"category_{{ category.slug }}\">
            <div class=\"feed\">
              <a href=\"\">Feed</a>
            </div>
            <h1><a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.name }}</a></h1>
          </div>
            
            {% include 'job/list.html.twig' with {'jobs': category.activejobs} %}
            
            {% if category.morejobs %}
                <div class=\"more_jobs\">
                  and <a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.morejobs }}</a>
                  more...
                </div>
            {% endif %}
        </div>
        {% endfor %}
    </div>
{% endblock %}
", ":job:index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app/Resources\\views/job/index.html.twig");
    }
}
