<?php

/* affiliate/index.html.twig */
class __TwigTemplate_ccd947c5831609af7478211bbdba732bc7a2886529b65be8afb4903c7e4542cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "affiliate/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_104c2ce5b864058b4d04ed2b8d136344c926b9eb9222dbdfa5f87e153d7ae973 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_104c2ce5b864058b4d04ed2b8d136344c926b9eb9222dbdfa5f87e153d7ae973->enter($__internal_104c2ce5b864058b4d04ed2b8d136344c926b9eb9222dbdfa5f87e153d7ae973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/index.html.twig"));

        $__internal_b29b5610407aa537aa1fcce7b2255131559c77fed7df25921e1df8f0f2901d5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b29b5610407aa537aa1fcce7b2255131559c77fed7df25921e1df8f0f2901d5b->enter($__internal_b29b5610407aa537aa1fcce7b2255131559c77fed7df25921e1df8f0f2901d5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "affiliate/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_104c2ce5b864058b4d04ed2b8d136344c926b9eb9222dbdfa5f87e153d7ae973->leave($__internal_104c2ce5b864058b4d04ed2b8d136344c926b9eb9222dbdfa5f87e153d7ae973_prof);

        
        $__internal_b29b5610407aa537aa1fcce7b2255131559c77fed7df25921e1df8f0f2901d5b->leave($__internal_b29b5610407aa537aa1fcce7b2255131559c77fed7df25921e1df8f0f2901d5b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_cce27aea950243d14f04304d1e52e85312ad4ab36f6e052762f0089e268cfdf5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cce27aea950243d14f04304d1e52e85312ad4ab36f6e052762f0089e268cfdf5->enter($__internal_cce27aea950243d14f04304d1e52e85312ad4ab36f6e052762f0089e268cfdf5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e27c73018be0a18bd2e2cc71fa2acb33400083440b4158aec196b1c376854089 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e27c73018be0a18bd2e2cc71fa2acb33400083440b4158aec196b1c376854089->enter($__internal_e27c73018be0a18bd2e2cc71fa2acb33400083440b4158aec196b1c376854089_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Affiliates list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Url</th>
                <th>Email</th>
                <th>Token</th>
                <th>Isactive</th>
                <th>Createdat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["affiliates"]) ? $context["affiliates"] : $this->getContext($context, "affiliates")));
        foreach ($context['_seq'] as $context["_key"] => $context["affiliate"]) {
            // line 20
            echo "            <tr>
                <td><a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_show", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "url", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["affiliate"], "token", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 25
            if ($this->getAttribute($context["affiliate"], "isActive", array())) {
                echo "Yes";
            } else {
                echo "No";
            }
            echo "</td>
                <td>";
            // line 26
            if ($this->getAttribute($context["affiliate"], "createdAt", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["affiliate"], "createdAt", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_show", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_edit", array("id" => $this->getAttribute($context["affiliate"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['affiliate'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 44
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("affiliate_new");
        echo "\">Create a new affiliate</a>
        </li>
    </ul>
";
        
        $__internal_e27c73018be0a18bd2e2cc71fa2acb33400083440b4158aec196b1c376854089->leave($__internal_e27c73018be0a18bd2e2cc71fa2acb33400083440b4158aec196b1c376854089_prof);

        
        $__internal_cce27aea950243d14f04304d1e52e85312ad4ab36f6e052762f0089e268cfdf5->leave($__internal_cce27aea950243d14f04304d1e52e85312ad4ab36f6e052762f0089e268cfdf5_prof);

    }

    public function getTemplateName()
    {
        return "affiliate/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 44,  126 => 39,  114 => 33,  108 => 30,  99 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  73 => 21,  70 => 20,  66 => 19,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Affiliates list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Url</th>
                <th>Email</th>
                <th>Token</th>
                <th>Isactive</th>
                <th>Createdat</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for affiliate in affiliates %}
            <tr>
                <td><a href=\"{{ path('affiliate_show', { 'id': affiliate.id }) }}\">{{ affiliate.id }}</a></td>
                <td>{{ affiliate.url }}</td>
                <td>{{ affiliate.email }}</td>
                <td>{{ affiliate.token }}</td>
                <td>{% if affiliate.isActive %}Yes{% else %}No{% endif %}</td>
                <td>{% if affiliate.createdAt %}{{ affiliate.createdAt|date('Y-m-d H:i:s') }}{% endif %}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('affiliate_show', { 'id': affiliate.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('affiliate_edit', { 'id': affiliate.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('affiliate_new') }}\">Create a new affiliate</a>
        </li>
    </ul>
{% endblock %}
", "affiliate/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\affiliate\\index.html.twig");
    }
}
