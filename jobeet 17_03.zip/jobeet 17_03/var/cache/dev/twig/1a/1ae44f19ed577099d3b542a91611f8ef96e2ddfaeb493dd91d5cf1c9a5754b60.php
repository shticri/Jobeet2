<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_07b9dd8bb00f04fbdf98042be15f69075581e401b4e98e42a2cf4d6eca16055c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46ce25fb41ab7e6c756fd1f94bd6cccf826a907d727b4020a85ad19f524a0aa7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46ce25fb41ab7e6c756fd1f94bd6cccf826a907d727b4020a85ad19f524a0aa7->enter($__internal_46ce25fb41ab7e6c756fd1f94bd6cccf826a907d727b4020a85ad19f524a0aa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_6c98586db7c43fb83748042ff3a9aaaa4f95d5643068fea6f21717dd81f940e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c98586db7c43fb83748042ff3a9aaaa4f95d5643068fea6f21717dd81f940e0->enter($__internal_6c98586db7c43fb83748042ff3a9aaaa4f95d5643068fea6f21717dd81f940e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_46ce25fb41ab7e6c756fd1f94bd6cccf826a907d727b4020a85ad19f524a0aa7->leave($__internal_46ce25fb41ab7e6c756fd1f94bd6cccf826a907d727b4020a85ad19f524a0aa7_prof);

        
        $__internal_6c98586db7c43fb83748042ff3a9aaaa4f95d5643068fea6f21717dd81f940e0->leave($__internal_6c98586db7c43fb83748042ff3a9aaaa4f95d5643068fea6f21717dd81f940e0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
