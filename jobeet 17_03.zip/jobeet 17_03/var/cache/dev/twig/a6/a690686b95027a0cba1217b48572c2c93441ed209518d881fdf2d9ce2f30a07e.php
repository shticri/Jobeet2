<?php

/* job/show.html.twig */
class __TwigTemplate_39cdcc8d8b1d2fe5840d0f3d77701dc7899e971bdbde6be17f785a1a7b14e0f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fa98a19c56739c1a0749e262a2d94b3e5a1d5c2b6bceb1f7f6085434757bb9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fa98a19c56739c1a0749e262a2d94b3e5a1d5c2b6bceb1f7f6085434757bb9e->enter($__internal_4fa98a19c56739c1a0749e262a2d94b3e5a1d5c2b6bceb1f7f6085434757bb9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/show.html.twig"));

        $__internal_ad55046fec57a67d49e333b2ce3de1ea384acbdc768ddeb9c72f431433fa4d21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad55046fec57a67d49e333b2ce3de1ea384acbdc768ddeb9c72f431433fa4d21->enter($__internal_ad55046fec57a67d49e333b2ce3de1ea384acbdc768ddeb9c72f431433fa4d21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4fa98a19c56739c1a0749e262a2d94b3e5a1d5c2b6bceb1f7f6085434757bb9e->leave($__internal_4fa98a19c56739c1a0749e262a2d94b3e5a1d5c2b6bceb1f7f6085434757bb9e_prof);

        
        $__internal_ad55046fec57a67d49e333b2ce3de1ea384acbdc768ddeb9c72f431433fa4d21->leave($__internal_ad55046fec57a67d49e333b2ce3de1ea384acbdc768ddeb9c72f431433fa4d21_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_687a58e32eb3f8a1e5ae3759ec3b0c6d013b9914c1c01940868088b7696b8e34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_687a58e32eb3f8a1e5ae3759ec3b0c6d013b9914c1c01940868088b7696b8e34->enter($__internal_687a58e32eb3f8a1e5ae3759ec3b0c6d013b9914c1c01940868088b7696b8e34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_3e162f4fdbf34504edc5dbe49b2b5d76e0dc7943c22ffbff649734f781986f71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e162f4fdbf34504edc5dbe49b2b5d76e0dc7943c22ffbff649734f781986f71->enter($__internal_3e162f4fdbf34504edc5dbe49b2b5d76e0dc7943c22ffbff649734f781986f71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo " is looking for a ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
";
        
        $__internal_3e162f4fdbf34504edc5dbe49b2b5d76e0dc7943c22ffbff649734f781986f71->leave($__internal_3e162f4fdbf34504edc5dbe49b2b5d76e0dc7943c22ffbff649734f781986f71_prof);

        
        $__internal_687a58e32eb3f8a1e5ae3759ec3b0c6d013b9914c1c01940868088b7696b8e34->leave($__internal_687a58e32eb3f8a1e5ae3759ec3b0c6d013b9914c1c01940868088b7696b8e34_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c91e300fe65e6b9faedc0caf0bb9c200782f3742b1ca2f24c943b699b38a7e05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c91e300fe65e6b9faedc0caf0bb9c200782f3742b1ca2f24c943b699b38a7e05->enter($__internal_c91e300fe65e6b9faedc0caf0bb9c200782f3742b1ca2f24c943b699b38a7e05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_77b781eb54cdb2839d324bfbe1bc8b1c75336edf12b13ff36ba08d308c057f44 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77b781eb54cdb2839d324bfbe1bc8b1c75336edf12b13ff36ba08d308c057f44->enter($__internal_77b781eb54cdb2839d324bfbe1bc8b1c75336edf12b13ff36ba08d308c057f44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/job.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_77b781eb54cdb2839d324bfbe1bc8b1c75336edf12b13ff36ba08d308c057f44->leave($__internal_77b781eb54cdb2839d324bfbe1bc8b1c75336edf12b13ff36ba08d308c057f44_prof);

        
        $__internal_c91e300fe65e6b9faedc0caf0bb9c200782f3742b1ca2f24c943b699b38a7e05->leave($__internal_c91e300fe65e6b9faedc0caf0bb9c200782f3742b1ca2f24c943b699b38a7e05_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_350bfd53b59aa7bb78cabcd720bc001f887ce49f983e6a25bd650e501cffe711 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_350bfd53b59aa7bb78cabcd720bc001f887ce49f983e6a25bd650e501cffe711->enter($__internal_350bfd53b59aa7bb78cabcd720bc001f887ce49f983e6a25bd650e501cffe711_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_f5140aa6e6d762cda4a874549d485cda01363908d0ee2c0cd537c2c654431e8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5140aa6e6d762cda4a874549d485cda01363908d0ee2c0cd537c2c654431e8d->enter($__internal_f5140aa6e6d762cda4a874549d485cda01363908d0ee2c0cd537c2c654431e8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 13
        echo "    <div id=\"job\">
      <h1>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo "</h1>
      <h2>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "location", array()), "html", null, true);
        echo "</h2>
      <h3>
        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
        <small> - ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "type", array()), "html", null, true);
        echo "</small>
      </h3>
 
      ";
        // line 21
        if ($this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array())) {
            // line 22
            echo "        <div class=\"logo\">
          <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "url", array()), "html", null, true);
            echo "\">
            <img src=\"/uploads/jobs/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array()), "html", null, true);
            echo "\"
              alt=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
            echo " logo\" />
          </a>
        </div>
      ";
        }
        // line 29
        echo " 
      <div class=\"description\">
        ";
        // line 31
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "description", array()), "html", null, true));
        echo "
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "howtoapply", array()), "html", null, true);
        echo "</p>
 
      <div class=\"meta\">
        <small>posted on ";
        // line 39
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "createdat", array()), "m/d/Y"), "html", null, true);
        echo "</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_edit", array("id" => $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "id", array()))), "html", null, true);
        echo "\">
          Edit
        </a>
      </div>
    </div>
";
        
        $__internal_f5140aa6e6d762cda4a874549d485cda01363908d0ee2c0cd537c2c654431e8d->leave($__internal_f5140aa6e6d762cda4a874549d485cda01363908d0ee2c0cd537c2c654431e8d_prof);

        
        $__internal_350bfd53b59aa7bb78cabcd720bc001f887ce49f983e6a25bd650e501cffe711->leave($__internal_350bfd53b59aa7bb78cabcd720bc001f887ce49f983e6a25bd650e501cffe711_prof);

    }

    public function getTemplateName()
    {
        return "job/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  161 => 39,  155 => 36,  147 => 31,  143 => 29,  136 => 25,  132 => 24,  128 => 23,  125 => 22,  123 => 21,  117 => 18,  113 => 17,  108 => 15,  104 => 14,  101 => 13,  92 => 12,  80 => 9,  75 => 8,  66 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    {{ job.company }} is looking for a {{ job.position }}
{% endblock %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/job.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"job\">
      <h1>{{ job.company }}</h1>
      <h2>{{ job.location }}</h2>
      <h3>
        {{ job.position }}
        <small> - {{ job.type }}</small>
      </h3>
 
      {% if job.logo %}
        <div class=\"logo\">
          <a href=\"{{ job.url }}\">
            <img src=\"/uploads/jobs/{{ job.logo }}\"
              alt=\"{{ job.company }} logo\" />
          </a>
        </div>
      {% endif %}
 
      <div class=\"description\">
        {{ job.description|nl2br }}
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">{{ job.howtoapply }}</p>
 
      <div class=\"meta\">
        <small>posted on {{ job.createdat|date('m/d/Y') }}</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"{{ path('job_edit', { 'id': job.id }) }}\">
          Edit
        </a>
      </div>
    </div>
{% endblock %}
", "job/show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\show.html.twig");
    }
}
