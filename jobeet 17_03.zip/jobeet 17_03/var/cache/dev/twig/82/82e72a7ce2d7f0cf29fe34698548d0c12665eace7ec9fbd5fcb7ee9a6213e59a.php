<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_81adae75faad2e6ba3c986a31a7c8b6df32ae167cdececdf2a290bce27b530a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6aed5b1ef23917c207acc43c5d98e72a4df4284c9243d282437c9344f89ada8f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6aed5b1ef23917c207acc43c5d98e72a4df4284c9243d282437c9344f89ada8f->enter($__internal_6aed5b1ef23917c207acc43c5d98e72a4df4284c9243d282437c9344f89ada8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_8926b427c4d6a3ab863bb7b3486569376f552a45238cb90aa5a9c6a180398909 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8926b427c4d6a3ab863bb7b3486569376f552a45238cb90aa5a9c6a180398909->enter($__internal_8926b427c4d6a3ab863bb7b3486569376f552a45238cb90aa5a9c6a180398909_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_6aed5b1ef23917c207acc43c5d98e72a4df4284c9243d282437c9344f89ada8f->leave($__internal_6aed5b1ef23917c207acc43c5d98e72a4df4284c9243d282437c9344f89ada8f_prof);

        
        $__internal_8926b427c4d6a3ab863bb7b3486569376f552a45238cb90aa5a9c6a180398909->leave($__internal_8926b427c4d6a3ab863bb7b3486569376f552a45238cb90aa5a9c6a180398909_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
