<?php

/* job/new.html.twig */
class __TwigTemplate_052936909d743558e99a6303df2d9d43598a03a8772f9c364a2d229760955308 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/new.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b094e2a5ae19e37f7b6ecb4e97e20665cf1c8f8208cd6055ccb94194fd686d8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b094e2a5ae19e37f7b6ecb4e97e20665cf1c8f8208cd6055ccb94194fd686d8e->enter($__internal_b094e2a5ae19e37f7b6ecb4e97e20665cf1c8f8208cd6055ccb94194fd686d8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/new.html.twig"));

        $__internal_aea6188b52addb9d3627bcfb6790dc033ba1f7de86b270ff7fa4825ed898e522 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aea6188b52addb9d3627bcfb6790dc033ba1f7de86b270ff7fa4825ed898e522->enter($__internal_aea6188b52addb9d3627bcfb6790dc033ba1f7de86b270ff7fa4825ed898e522_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b094e2a5ae19e37f7b6ecb4e97e20665cf1c8f8208cd6055ccb94194fd686d8e->leave($__internal_b094e2a5ae19e37f7b6ecb4e97e20665cf1c8f8208cd6055ccb94194fd686d8e_prof);

        
        $__internal_aea6188b52addb9d3627bcfb6790dc033ba1f7de86b270ff7fa4825ed898e522->leave($__internal_aea6188b52addb9d3627bcfb6790dc033ba1f7de86b270ff7fa4825ed898e522_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_f1878a210fd685dbacb26caa25d0f53e0a450ec6d85104c50b0181628361907a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1878a210fd685dbacb26caa25d0f53e0a450ec6d85104c50b0181628361907a->enter($__internal_f1878a210fd685dbacb26caa25d0f53e0a450ec6d85104c50b0181628361907a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_a4f4b9a0d0f632d573b54f1e212672639399d10ab06b62e958a34fbf6dec166c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4f4b9a0d0f632d573b54f1e212672639399d10ab06b62e958a34fbf6dec166c->enter($__internal_a4f4b9a0d0f632d573b54f1e212672639399d10ab06b62e958a34fbf6dec166c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Job creation</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_a4f4b9a0d0f632d573b54f1e212672639399d10ab06b62e958a34fbf6dec166c->leave($__internal_a4f4b9a0d0f632d573b54f1e212672639399d10ab06b62e958a34fbf6dec166c_prof);

        
        $__internal_f1878a210fd685dbacb26caa25d0f53e0a450ec6d85104c50b0181628361907a->leave($__internal_f1878a210fd685dbacb26caa25d0f53e0a450ec6d85104c50b0181628361907a_prof);

    }

    public function getTemplateName()
    {
        return "job/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block content %}
    <h1>Job creation</h1>

    {{ form_start(form) }}
        {{ form_widget(form) }}
        <input type=\"submit\" value=\"Create\" />
    {{ form_end(form) }}

    <ul>
        <li>
            <a href=\"{{ path('job_index') }}\">Back to the list</a>
        </li>
    </ul>
{% endblock %}
", "job/new.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\new.html.twig");
    }
}
