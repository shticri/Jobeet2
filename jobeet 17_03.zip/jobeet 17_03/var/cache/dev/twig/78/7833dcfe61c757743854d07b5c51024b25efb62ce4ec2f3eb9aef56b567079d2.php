<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_2217e951f851b5300708fb402981f8cf553a5d24f371a268136f234a1fe2dfc1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca33de22d9b86ae619e1dab9b38ef2cb2eb02dab45fd9eaa7838df5c8fbee2d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca33de22d9b86ae619e1dab9b38ef2cb2eb02dab45fd9eaa7838df5c8fbee2d3->enter($__internal_ca33de22d9b86ae619e1dab9b38ef2cb2eb02dab45fd9eaa7838df5c8fbee2d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_8d39f4d7e04004d553f6538f40ce361c66559032bfc66d08e2bbb6d1ba7a9ec4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d39f4d7e04004d553f6538f40ce361c66559032bfc66d08e2bbb6d1ba7a9ec4->enter($__internal_8d39f4d7e04004d553f6538f40ce361c66559032bfc66d08e2bbb6d1ba7a9ec4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca33de22d9b86ae619e1dab9b38ef2cb2eb02dab45fd9eaa7838df5c8fbee2d3->leave($__internal_ca33de22d9b86ae619e1dab9b38ef2cb2eb02dab45fd9eaa7838df5c8fbee2d3_prof);

        
        $__internal_8d39f4d7e04004d553f6538f40ce361c66559032bfc66d08e2bbb6d1ba7a9ec4->leave($__internal_8d39f4d7e04004d553f6538f40ce361c66559032bfc66d08e2bbb6d1ba7a9ec4_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_0ae2dd910e2babbdf70e73836ad2aff40e597e16aa69e4d8a7f75c853c831cd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ae2dd910e2babbdf70e73836ad2aff40e597e16aa69e4d8a7f75c853c831cd7->enter($__internal_0ae2dd910e2babbdf70e73836ad2aff40e597e16aa69e4d8a7f75c853c831cd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_def44b4baaa2bd39fc4d454186787d0913e6d69bf67c2309d131039d41efb5fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_def44b4baaa2bd39fc4d454186787d0913e6d69bf67c2309d131039d41efb5fd->enter($__internal_def44b4baaa2bd39fc4d454186787d0913e6d69bf67c2309d131039d41efb5fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_def44b4baaa2bd39fc4d454186787d0913e6d69bf67c2309d131039d41efb5fd->leave($__internal_def44b4baaa2bd39fc4d454186787d0913e6d69bf67c2309d131039d41efb5fd_prof);

        
        $__internal_0ae2dd910e2babbdf70e73836ad2aff40e597e16aa69e4d8a7f75c853c831cd7->leave($__internal_0ae2dd910e2babbdf70e73836ad2aff40e597e16aa69e4d8a7f75c853c831cd7_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_dc2b04480c3d5da548d6dbeedd4eac5f7fa3747c2028ab0373e947773e68e161 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc2b04480c3d5da548d6dbeedd4eac5f7fa3747c2028ab0373e947773e68e161->enter($__internal_dc2b04480c3d5da548d6dbeedd4eac5f7fa3747c2028ab0373e947773e68e161_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ace0a267feee0e1b351fefbc61b7e24f2cf4223705be43453313bfb051759c93 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ace0a267feee0e1b351fefbc61b7e24f2cf4223705be43453313bfb051759c93->enter($__internal_ace0a267feee0e1b351fefbc61b7e24f2cf4223705be43453313bfb051759c93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_ace0a267feee0e1b351fefbc61b7e24f2cf4223705be43453313bfb051759c93->leave($__internal_ace0a267feee0e1b351fefbc61b7e24f2cf4223705be43453313bfb051759c93_prof);

        
        $__internal_dc2b04480c3d5da548d6dbeedd4eac5f7fa3747c2028ab0373e947773e68e161->leave($__internal_dc2b04480c3d5da548d6dbeedd4eac5f7fa3747c2028ab0373e947773e68e161_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
