<?php

/* category/index.html.twig */
class __TwigTemplate_70a0d894f4260ded5be32096d311b498a776ba5ddb1617ff1de6d8e36004e93a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_138c13bb9186ea0857ec78ff5e693614443e0b4ff1cb255e79afb0933cf7f927 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_138c13bb9186ea0857ec78ff5e693614443e0b4ff1cb255e79afb0933cf7f927->enter($__internal_138c13bb9186ea0857ec78ff5e693614443e0b4ff1cb255e79afb0933cf7f927_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $__internal_d885841cde701f35259af75b7d7a62be8758cf059640229e4fb94d0bed096ee6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d885841cde701f35259af75b7d7a62be8758cf059640229e4fb94d0bed096ee6->enter($__internal_d885841cde701f35259af75b7d7a62be8758cf059640229e4fb94d0bed096ee6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_138c13bb9186ea0857ec78ff5e693614443e0b4ff1cb255e79afb0933cf7f927->leave($__internal_138c13bb9186ea0857ec78ff5e693614443e0b4ff1cb255e79afb0933cf7f927_prof);

        
        $__internal_d885841cde701f35259af75b7d7a62be8758cf059640229e4fb94d0bed096ee6->leave($__internal_d885841cde701f35259af75b7d7a62be8758cf059640229e4fb94d0bed096ee6_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6ebf2ba422595ad7fb53efe7709a99435e40d61dfcdf0cc24aafda82a020b9b2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ebf2ba422595ad7fb53efe7709a99435e40d61dfcdf0cc24aafda82a020b9b2->enter($__internal_6ebf2ba422595ad7fb53efe7709a99435e40d61dfcdf0cc24aafda82a020b9b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_90bd0f51ff385628ad1e0ca3504fdc3b97dc59396fd0c427c58276de3abd95fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90bd0f51ff385628ad1e0ca3504fdc3b97dc59396fd0c427c58276de3abd95fd->enter($__internal_90bd0f51ff385628ad1e0ca3504fdc3b97dc59396fd0c427c58276de3abd95fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_90bd0f51ff385628ad1e0ca3504fdc3b97dc59396fd0c427c58276de3abd95fd->leave($__internal_90bd0f51ff385628ad1e0ca3504fdc3b97dc59396fd0c427c58276de3abd95fd_prof);

        
        $__internal_6ebf2ba422595ad7fb53efe7709a99435e40d61dfcdf0cc24aafda82a020b9b2->leave($__internal_6ebf2ba422595ad7fb53efe7709a99435e40d61dfcdf0cc24aafda82a020b9b2_prof);

    }

    // line 46
    public function block_content($context, array $blocks = array())
    {
        $__internal_8ea596adebc82bc9da89cdbf17ffe18b52ec34f21aef1739fa568969c7fd564d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ea596adebc82bc9da89cdbf17ffe18b52ec34f21aef1739fa568969c7fd564d->enter($__internal_8ea596adebc82bc9da89cdbf17ffe18b52ec34f21aef1739fa568969c7fd564d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_e3fd6c7e01e0eca3004078f8190a77a12f76732877e7a88a31899a97492cddd0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e3fd6c7e01e0eca3004078f8190a77a12f76732877e7a88a31899a97492cddd0->enter($__internal_e3fd6c7e01e0eca3004078f8190a77a12f76732877e7a88a31899a97492cddd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 47
        echo "    <div id=\"categories\">
      <table class=\"categories\">
        ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 50
            echo "          <tr class=\"";
            echo twig_escape_filter($this->env, twig_cycle(array(0 => "even", 1 => "odd"), $this->getAttribute($context["loop"], "index", array())), "html", null, true);
            echo "\">
            <td>
              <a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                ";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "
              </a>
            </td>
            
          </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "      </table>
    </div>
";
        
        $__internal_e3fd6c7e01e0eca3004078f8190a77a12f76732877e7a88a31899a97492cddd0->leave($__internal_e3fd6c7e01e0eca3004078f8190a77a12f76732877e7a88a31899a97492cddd0_prof);

        
        $__internal_8ea596adebc82bc9da89cdbf17ffe18b52ec34f21aef1739fa568969c7fd564d->leave($__internal_8ea596adebc82bc9da89cdbf17ffe18b52ec34f21aef1739fa568969c7fd564d_prof);

    }

    public function getTemplateName()
    {
        return "category/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 59,  107 => 53,  103 => 52,  97 => 50,  80 => 49,  76 => 47,  67 => 46,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/main.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{#{% block content%}
    <h1>Categories list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for category in categories %}
            <tr>
                <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                <td>{{ category.name }}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_show', { 'id': category.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('category_edit', { 'id': category.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('category_new') }}\">Create a new category</a>
        </li>
    </ul>
{% endblock %} #}

{% block content %}
    <div id=\"categories\">
      <table class=\"categories\">
        {% for category in categories %}
          <tr class=\"{{ cycle(['even', 'odd'], loop.index) }}\">
            <td>
              <a href=\"{{ path('category_show', { 'id': category.id }) }}\">
                {{ category.name }}
              </a>
            </td>
            
          </tr>
        {% endfor %}
      </table>
    </div>
{% endblock %}
", "category/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\category\\index.html.twig");
    }
}
