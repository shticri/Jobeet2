<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_12070d718bfc51e8a51c7abb3735953deaf59e9121363fd43fe8f77c18067e86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ccbc34d2f9a1918f1e17ef056ad13db660f61d3ad05c4c29d4b1f2c9e074d876 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ccbc34d2f9a1918f1e17ef056ad13db660f61d3ad05c4c29d4b1f2c9e074d876->enter($__internal_ccbc34d2f9a1918f1e17ef056ad13db660f61d3ad05c4c29d4b1f2c9e074d876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_e986e94ee4cd1f8f4c833220ef940d1a289bd1630e90df85f4d691e52696a86b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e986e94ee4cd1f8f4c833220ef940d1a289bd1630e90df85f4d691e52696a86b->enter($__internal_e986e94ee4cd1f8f4c833220ef940d1a289bd1630e90df85f4d691e52696a86b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_ccbc34d2f9a1918f1e17ef056ad13db660f61d3ad05c4c29d4b1f2c9e074d876->leave($__internal_ccbc34d2f9a1918f1e17ef056ad13db660f61d3ad05c4c29d4b1f2c9e074d876_prof);

        
        $__internal_e986e94ee4cd1f8f4c833220ef940d1a289bd1630e90df85f4d691e52696a86b->leave($__internal_e986e94ee4cd1f8f4c833220ef940d1a289bd1630e90df85f4d691e52696a86b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
