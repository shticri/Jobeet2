<?php

/* category/edit.html.twig */
class __TwigTemplate_06e2617b0fb1d316b3b31bc0c08f5bd41f99b19136f8bdf399b4c2a8da525b42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0a0e920a5128e8c05792bf251f5ccec6827b38365b335c374e34612860fee7b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0a0e920a5128e8c05792bf251f5ccec6827b38365b335c374e34612860fee7b1->enter($__internal_0a0e920a5128e8c05792bf251f5ccec6827b38365b335c374e34612860fee7b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/edit.html.twig"));

        $__internal_9c57e3ee00139bba4d3939200ee6403e60b161df64147ca1c256ad6874e05736 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9c57e3ee00139bba4d3939200ee6403e60b161df64147ca1c256ad6874e05736->enter($__internal_9c57e3ee00139bba4d3939200ee6403e60b161df64147ca1c256ad6874e05736_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0a0e920a5128e8c05792bf251f5ccec6827b38365b335c374e34612860fee7b1->leave($__internal_0a0e920a5128e8c05792bf251f5ccec6827b38365b335c374e34612860fee7b1_prof);

        
        $__internal_9c57e3ee00139bba4d3939200ee6403e60b161df64147ca1c256ad6874e05736->leave($__internal_9c57e3ee00139bba4d3939200ee6403e60b161df64147ca1c256ad6874e05736_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_f99c80241c70977fb79eda9c4bc63b55358d40c884d8174c2424f572838d82b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f99c80241c70977fb79eda9c4bc63b55358d40c884d8174c2424f572838d82b7->enter($__internal_f99c80241c70977fb79eda9c4bc63b55358d40c884d8174c2424f572838d82b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_739a0ee1965c924b05ee426b34b52b5236ab53efba7a9b03b83c3fcaff2bca8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_739a0ee1965c924b05ee426b34b52b5236ab53efba7a9b03b83c3fcaff2bca8d->enter($__internal_739a0ee1965c924b05ee426b34b52b5236ab53efba7a9b03b83c3fcaff2bca8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Category edit</h1>

    ";
        // line 6
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_739a0ee1965c924b05ee426b34b52b5236ab53efba7a9b03b83c3fcaff2bca8d->leave($__internal_739a0ee1965c924b05ee426b34b52b5236ab53efba7a9b03b83c3fcaff2bca8d_prof);

        
        $__internal_f99c80241c70977fb79eda9c4bc63b55358d40c884d8174c2424f572838d82b7->leave($__internal_f99c80241c70977fb79eda9c4bc63b55358d40c884d8174c2424f572838d82b7_prof);

    }

    public function getTemplateName()
    {
        return "category/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 18,  75 => 16,  69 => 13,  62 => 9,  57 => 7,  53 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <h1>Category edit</h1>

    {{ form_start(edit_form) }}
        {{ form_widget(edit_form) }}
        <input type=\"submit\" value=\"Edit\" />
    {{ form_end(edit_form) }}

    <ul>
        <li>
            <a href=\"{{ path('category_index') }}\">Back to the list</a>
        </li>
        <li>
            {{ form_start(delete_form) }}
                <input type=\"submit\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </li>
    </ul>
{% endblock %}
", "category/edit.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\category\\edit.html.twig");
    }
}
