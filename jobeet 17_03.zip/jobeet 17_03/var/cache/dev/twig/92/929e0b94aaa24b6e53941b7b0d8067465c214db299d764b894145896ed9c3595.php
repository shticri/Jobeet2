<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_3cba77f24485a488e8e4fa4cecf0b42bca5aaef7b9a81ac0312000eb5f8851f7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5661dd4f674044c9a1ae1fe4b91653745bd710eb82615367dca3a36e81bd006e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5661dd4f674044c9a1ae1fe4b91653745bd710eb82615367dca3a36e81bd006e->enter($__internal_5661dd4f674044c9a1ae1fe4b91653745bd710eb82615367dca3a36e81bd006e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_3e064596e6c91fe90f0603d68828110d5e6ba7877f12780cd5cc08138a0b584c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e064596e6c91fe90f0603d68828110d5e6ba7877f12780cd5cc08138a0b584c->enter($__internal_3e064596e6c91fe90f0603d68828110d5e6ba7877f12780cd5cc08138a0b584c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_5661dd4f674044c9a1ae1fe4b91653745bd710eb82615367dca3a36e81bd006e->leave($__internal_5661dd4f674044c9a1ae1fe4b91653745bd710eb82615367dca3a36e81bd006e_prof);

        
        $__internal_3e064596e6c91fe90f0603d68828110d5e6ba7877f12780cd5cc08138a0b584c->leave($__internal_3e064596e6c91fe90f0603d68828110d5e6ba7877f12780cd5cc08138a0b584c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
