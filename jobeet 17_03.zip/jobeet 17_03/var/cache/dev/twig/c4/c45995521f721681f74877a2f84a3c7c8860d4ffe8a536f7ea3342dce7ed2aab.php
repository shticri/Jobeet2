<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_637ea6d981c4efa12ff6c816857c78892404fdbcde9751d62d5407c67d7d4a37 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d49b5ff2d2d1c83bfe9e6c6135a8b891c6864af5e7446be5a45a1cdb1f5238f9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d49b5ff2d2d1c83bfe9e6c6135a8b891c6864af5e7446be5a45a1cdb1f5238f9->enter($__internal_d49b5ff2d2d1c83bfe9e6c6135a8b891c6864af5e7446be5a45a1cdb1f5238f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_02dd6e7c55751461adcd583f40567d3a725262660dd4fa0e7833e5e2fa2ecc2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02dd6e7c55751461adcd583f40567d3a725262660dd4fa0e7833e5e2fa2ecc2f->enter($__internal_02dd6e7c55751461adcd583f40567d3a725262660dd4fa0e7833e5e2fa2ecc2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_d49b5ff2d2d1c83bfe9e6c6135a8b891c6864af5e7446be5a45a1cdb1f5238f9->leave($__internal_d49b5ff2d2d1c83bfe9e6c6135a8b891c6864af5e7446be5a45a1cdb1f5238f9_prof);

        
        $__internal_02dd6e7c55751461adcd583f40567d3a725262660dd4fa0e7833e5e2fa2ecc2f->leave($__internal_02dd6e7c55751461adcd583f40567d3a725262660dd4fa0e7833e5e2fa2ecc2f_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_167d8d3befd0432bdc11603d4ebd22e65d1e172f624f1a7a8f896b98f57d6bf0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_167d8d3befd0432bdc11603d4ebd22e65d1e172f624f1a7a8f896b98f57d6bf0->enter($__internal_167d8d3befd0432bdc11603d4ebd22e65d1e172f624f1a7a8f896b98f57d6bf0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f09ea4466dbc4745f8c0e76fe08e06b58dd155f0d76b4e38262fc821975e0e6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f09ea4466dbc4745f8c0e76fe08e06b58dd155f0d76b4e38262fc821975e0e6a->enter($__internal_f09ea4466dbc4745f8c0e76fe08e06b58dd155f0d76b4e38262fc821975e0e6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_f09ea4466dbc4745f8c0e76fe08e06b58dd155f0d76b4e38262fc821975e0e6a->leave($__internal_f09ea4466dbc4745f8c0e76fe08e06b58dd155f0d76b4e38262fc821975e0e6a_prof);

        
        $__internal_167d8d3befd0432bdc11603d4ebd22e65d1e172f624f1a7a8f896b98f57d6bf0->leave($__internal_167d8d3befd0432bdc11603d4ebd22e65d1e172f624f1a7a8f896b98f57d6bf0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
