<?php

/* JobeetBundle:Default:index.html.twig */
class __TwigTemplate_6e52a31fd7875ca92885f6d9686f5b96ba488bf2b2d24abc629d65969e3cb34d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello Cristina!
";
    }

    public function getTemplateName()
    {
        return "JobeetBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "JobeetBundle:Default:index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\src\\Epfc\\JobeetBundle/Resources/views/Default/index.html.twig");
    }
}
