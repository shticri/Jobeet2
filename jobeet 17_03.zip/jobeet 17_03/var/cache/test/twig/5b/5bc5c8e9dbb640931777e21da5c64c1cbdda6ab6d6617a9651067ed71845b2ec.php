<?php

/* job/index.html.twig */
class __TwigTemplate_90299236952703648a952c74bcf18b58276774d27a1f2318976ba30218dbc3e6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e662f670efbf20dde94b64e105078e165e88df6d48b86ae68e37e85be3f81b1d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e662f670efbf20dde94b64e105078e165e88df6d48b86ae68e37e85be3f81b1d->enter($__internal_e662f670efbf20dde94b64e105078e165e88df6d48b86ae68e37e85be3f81b1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/index.html.twig"));

        $__internal_a5752e3cd82feb1ce9a3ff949c65e2cee41348a01b71c0b1f5b20ea21fa2d1bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a5752e3cd82feb1ce9a3ff949c65e2cee41348a01b71c0b1f5b20ea21fa2d1bb->enter($__internal_a5752e3cd82feb1ce9a3ff949c65e2cee41348a01b71c0b1f5b20ea21fa2d1bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e662f670efbf20dde94b64e105078e165e88df6d48b86ae68e37e85be3f81b1d->leave($__internal_e662f670efbf20dde94b64e105078e165e88df6d48b86ae68e37e85be3f81b1d_prof);

        
        $__internal_a5752e3cd82feb1ce9a3ff949c65e2cee41348a01b71c0b1f5b20ea21fa2d1bb->leave($__internal_a5752e3cd82feb1ce9a3ff949c65e2cee41348a01b71c0b1f5b20ea21fa2d1bb_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_53a221ef055df317dc9a5571a1be315fef37e67fc3303e3d7468d1197ecffa45 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_53a221ef055df317dc9a5571a1be315fef37e67fc3303e3d7468d1197ecffa45->enter($__internal_53a221ef055df317dc9a5571a1be315fef37e67fc3303e3d7468d1197ecffa45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_957f7f768c525ac17a7703d71ac3ea1073a5a67f1c3f76cc5619f9e00be88cc5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_957f7f768c525ac17a7703d71ac3ea1073a5a67f1c3f76cc5619f9e00be88cc5->enter($__internal_957f7f768c525ac17a7703d71ac3ea1073a5a67f1c3f76cc5619f9e00be88cc5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/jobs.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_957f7f768c525ac17a7703d71ac3ea1073a5a67f1c3f76cc5619f9e00be88cc5->leave($__internal_957f7f768c525ac17a7703d71ac3ea1073a5a67f1c3f76cc5619f9e00be88cc5_prof);

        
        $__internal_53a221ef055df317dc9a5571a1be315fef37e67fc3303e3d7468d1197ecffa45->leave($__internal_53a221ef055df317dc9a5571a1be315fef37e67fc3303e3d7468d1197ecffa45_prof);

    }

    // line 8
    public function block_content($context, array $blocks = array())
    {
        $__internal_b01b7f014d5498bc30f96d4f04337fa521c5ad72b6c7095331dc16e86bc49673 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b01b7f014d5498bc30f96d4f04337fa521c5ad72b6c7095331dc16e86bc49673->enter($__internal_b01b7f014d5498bc30f96d4f04337fa521c5ad72b6c7095331dc16e86bc49673_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_92f1b91e38b346676b3a98909153126d173209cf3fe5ce26845d61960bf824ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92f1b91e38b346676b3a98909153126d173209cf3fe5ce26845d61960bf824ee->enter($__internal_92f1b91e38b346676b3a98909153126d173209cf3fe5ce26845d61960bf824ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "    <div id=\"jobs\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 11
            echo "        <div>
          <div class=\"category_";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "slug", array()), "html", null, true);
            echo "\">
            <div class=\"feed\">
              <a href=\"\">Feed</a>
            </div>
            <h1><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "</a></h1>
          
            
            ";
            // line 19
            $this->loadTemplate("job/list.html.twig", "job/index.html.twig", 19)->display(array_merge($context, array("jobs" => $this->getAttribute($context["category"], "activejobs", array()))));
            // line 20
            echo "            
            ";
            // line 21
            if ($this->getAttribute($context["category"], "morejobs", array())) {
                // line 22
                echo "                <div class=\"more_jobs\">
                  and <a href=\"";
                // line 23
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("slug" => $this->getAttribute($context["category"], "slug", array()))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "morejobs", array()), "html", null, true);
                echo "</a>
                  more...
                </div>
            ";
            }
            // line 27
            echo "            </div>
        </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "    </div>
";
        
        $__internal_92f1b91e38b346676b3a98909153126d173209cf3fe5ce26845d61960bf824ee->leave($__internal_92f1b91e38b346676b3a98909153126d173209cf3fe5ce26845d61960bf824ee_prof);

        
        $__internal_b01b7f014d5498bc30f96d4f04337fa521c5ad72b6c7095331dc16e86bc49673->leave($__internal_b01b7f014d5498bc30f96d4f04337fa521c5ad72b6c7095331dc16e86bc49673_prof);

    }

    public function getTemplateName()
    {
        return "job/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 30,  133 => 27,  124 => 23,  121 => 22,  119 => 21,  116 => 20,  114 => 19,  106 => 16,  99 => 12,  96 => 11,  79 => 10,  76 => 9,  67 => 8,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/jobs.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"jobs\">
        {% for category in categories %}
        <div>
          <div class=\"category_{{ category.slug }}\">
            <div class=\"feed\">
              <a href=\"\">Feed</a>
            </div>
            <h1><a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.name }}</a></h1>
          
            
            {% include 'job/list.html.twig' with {'jobs': category.activejobs} %}
            
            {% if category.morejobs %}
                <div class=\"more_jobs\">
                  and <a href=\"{{ path('category_show', { 'slug': category.slug }) }}\">{{ category.morejobs }}</a>
                  more...
                </div>
            {% endif %}
            </div>
        </div>
        {% endfor %}
    </div>
{% endblock %}
", "job/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\index.html.twig");
    }
}
