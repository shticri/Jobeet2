<?php

/* category/index.html.twig */
class __TwigTemplate_70a0d894f4260ded5be32096d311b498a776ba5ddb1617ff1de6d8e36004e93a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "category/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0cf46a71c96f57eef804876b9a2f712f6c268d53fcbd25a501bebf4f576fbc43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0cf46a71c96f57eef804876b9a2f712f6c268d53fcbd25a501bebf4f576fbc43->enter($__internal_0cf46a71c96f57eef804876b9a2f712f6c268d53fcbd25a501bebf4f576fbc43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $__internal_d8a1ded8259dce9ab5ded37d638fbe4129070acd7d843f311068a70c7e929c3d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8a1ded8259dce9ab5ded37d638fbe4129070acd7d843f311068a70c7e929c3d->enter($__internal_d8a1ded8259dce9ab5ded37d638fbe4129070acd7d843f311068a70c7e929c3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "category/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0cf46a71c96f57eef804876b9a2f712f6c268d53fcbd25a501bebf4f576fbc43->leave($__internal_0cf46a71c96f57eef804876b9a2f712f6c268d53fcbd25a501bebf4f576fbc43_prof);

        
        $__internal_d8a1ded8259dce9ab5ded37d638fbe4129070acd7d843f311068a70c7e929c3d->leave($__internal_d8a1ded8259dce9ab5ded37d638fbe4129070acd7d843f311068a70c7e929c3d_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_84108cf7c2a5c685a559929e426e1b3c15f500b293b8cc570dfba10a9efba46d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84108cf7c2a5c685a559929e426e1b3c15f500b293b8cc570dfba10a9efba46d->enter($__internal_84108cf7c2a5c685a559929e426e1b3c15f500b293b8cc570dfba10a9efba46d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d761cc572b3001ff39a26eaa27949bb021d72cd356ee6288ae89c6f1f6415433 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d761cc572b3001ff39a26eaa27949bb021d72cd356ee6288ae89c6f1f6415433->enter($__internal_d761cc572b3001ff39a26eaa27949bb021d72cd356ee6288ae89c6f1f6415433_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_d761cc572b3001ff39a26eaa27949bb021d72cd356ee6288ae89c6f1f6415433->leave($__internal_d761cc572b3001ff39a26eaa27949bb021d72cd356ee6288ae89c6f1f6415433_prof);

        
        $__internal_84108cf7c2a5c685a559929e426e1b3c15f500b293b8cc570dfba10a9efba46d->leave($__internal_84108cf7c2a5c685a559929e426e1b3c15f500b293b8cc570dfba10a9efba46d_prof);

    }

    // line 46
    public function block_content($context, array $blocks = array())
    {
        $__internal_910cb40992718ecdb2956adef5308dc741ea0a7e67ed5700112fe2c423d65a7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_910cb40992718ecdb2956adef5308dc741ea0a7e67ed5700112fe2c423d65a7d->enter($__internal_910cb40992718ecdb2956adef5308dc741ea0a7e67ed5700112fe2c423d65a7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_d32d01e9394c12ad3e0549e2866a8e4faeecf7ce6c918a65c7b7b833526d29ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d32d01e9394c12ad3e0549e2866a8e4faeecf7ce6c918a65c7b7b833526d29ff->enter($__internal_d32d01e9394c12ad3e0549e2866a8e4faeecf7ce6c918a65c7b7b833526d29ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 47
        echo "    <div id=\"categories\">
      <table class=\"categories\">
        ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 50
            echo "          <tr class=\"";
            echo twig_escape_filter($this->env, twig_cycle(array(0 => "even", 1 => "odd"), $this->getAttribute($context["loop"], "index", array())), "html", null, true);
            echo "\">
            <td>
              <a href=\"";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("category_show", array("id" => $this->getAttribute($context["category"], "id", array()))), "html", null, true);
            echo "\">
                ";
            // line 53
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "name", array()), "html", null, true);
            echo "
              </a>
            </td>
            
          </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 59
        echo "      </table>
    </div>
";
        
        $__internal_d32d01e9394c12ad3e0549e2866a8e4faeecf7ce6c918a65c7b7b833526d29ff->leave($__internal_d32d01e9394c12ad3e0549e2866a8e4faeecf7ce6c918a65c7b7b833526d29ff_prof);

        
        $__internal_910cb40992718ecdb2956adef5308dc741ea0a7e67ed5700112fe2c423d65a7d->leave($__internal_910cb40992718ecdb2956adef5308dc741ea0a7e67ed5700112fe2c423d65a7d_prof);

    }

    public function getTemplateName()
    {
        return "category/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 59,  107 => 53,  103 => 52,  97 => 50,  80 => 49,  76 => 47,  67 => 46,  55 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/main.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{#{% block content%}
    <h1>Categories list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        {% for category in categories %}
            <tr>
                <td><a href=\"{{ path('category_show', { 'id': category.id }) }}\">{{ category.id }}</a></td>
                <td>{{ category.name }}</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"{{ path('category_show', { 'id': category.id }) }}\">show</a>
                        </li>
                        <li>
                            <a href=\"{{ path('category_edit', { 'id': category.id }) }}\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"{{ path('category_new') }}\">Create a new category</a>
        </li>
    </ul>
{% endblock %} #}

{% block content %}
    <div id=\"categories\">
      <table class=\"categories\">
        {% for category in categories %}
          <tr class=\"{{ cycle(['even', 'odd'], loop.index) }}\">
            <td>
              <a href=\"{{ path('category_show', { 'id': category.id }) }}\">
                {{ category.name }}
              </a>
            </td>
            
          </tr>
        {% endfor %}
      </table>
    </div>
{% endblock %}
", "category/index.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\category\\index.html.twig");
    }
}
