<?php

/* job/show.html.twig */
class __TwigTemplate_39cdcc8d8b1d2fe5840d0f3d77701dc7899e971bdbde6be17f785a1a7b14e0f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "job/show.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfce04a6dc72a4c5a5cad6138eac327213d101f213042fc038dc08acc89fca55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfce04a6dc72a4c5a5cad6138eac327213d101f213042fc038dc08acc89fca55->enter($__internal_bfce04a6dc72a4c5a5cad6138eac327213d101f213042fc038dc08acc89fca55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/show.html.twig"));

        $__internal_834f0ae36563bc7dc1f4bb425dd2af0874c3820793b9e626fc1ec546efbbcb54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_834f0ae36563bc7dc1f4bb425dd2af0874c3820793b9e626fc1ec546efbbcb54->enter($__internal_834f0ae36563bc7dc1f4bb425dd2af0874c3820793b9e626fc1ec546efbbcb54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "job/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bfce04a6dc72a4c5a5cad6138eac327213d101f213042fc038dc08acc89fca55->leave($__internal_bfce04a6dc72a4c5a5cad6138eac327213d101f213042fc038dc08acc89fca55_prof);

        
        $__internal_834f0ae36563bc7dc1f4bb425dd2af0874c3820793b9e626fc1ec546efbbcb54->leave($__internal_834f0ae36563bc7dc1f4bb425dd2af0874c3820793b9e626fc1ec546efbbcb54_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_9f9a69bd96fe6ed77b895ecde41aa3a81aa5700a3c19c7f51a9b4df6c13ebe21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f9a69bd96fe6ed77b895ecde41aa3a81aa5700a3c19c7f51a9b4df6c13ebe21->enter($__internal_9f9a69bd96fe6ed77b895ecde41aa3a81aa5700a3c19c7f51a9b4df6c13ebe21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2524b921618ba3407102a95cedb4ac1e0c883b4507f3459897bf0fc95fcb16d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2524b921618ba3407102a95cedb4ac1e0c883b4507f3459897bf0fc95fcb16d0->enter($__internal_2524b921618ba3407102a95cedb4ac1e0c883b4507f3459897bf0fc95fcb16d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo " is looking for a ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
";
        
        $__internal_2524b921618ba3407102a95cedb4ac1e0c883b4507f3459897bf0fc95fcb16d0->leave($__internal_2524b921618ba3407102a95cedb4ac1e0c883b4507f3459897bf0fc95fcb16d0_prof);

        
        $__internal_9f9a69bd96fe6ed77b895ecde41aa3a81aa5700a3c19c7f51a9b4df6c13ebe21->leave($__internal_9f9a69bd96fe6ed77b895ecde41aa3a81aa5700a3c19c7f51a9b4df6c13ebe21_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b562849fa1475fba80af2be0af2799fef2f1391f09e132af9e10084e1d84447a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b562849fa1475fba80af2be0af2799fef2f1391f09e132af9e10084e1d84447a->enter($__internal_b562849fa1475fba80af2be0af2799fef2f1391f09e132af9e10084e1d84447a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_c3407ecf2b772c869f3c35841863a04d20f0a3c818a9a303f3db9854f3800bba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3407ecf2b772c869f3c35841863a04d20f0a3c818a9a303f3db9854f3800bba->enter($__internal_c3407ecf2b772c869f3c35841863a04d20f0a3c818a9a303f3db9854f3800bba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "  ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
  <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/job.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_c3407ecf2b772c869f3c35841863a04d20f0a3c818a9a303f3db9854f3800bba->leave($__internal_c3407ecf2b772c869f3c35841863a04d20f0a3c818a9a303f3db9854f3800bba_prof);

        
        $__internal_b562849fa1475fba80af2be0af2799fef2f1391f09e132af9e10084e1d84447a->leave($__internal_b562849fa1475fba80af2be0af2799fef2f1391f09e132af9e10084e1d84447a_prof);

    }

    // line 12
    public function block_content($context, array $blocks = array())
    {
        $__internal_518aded4702524772197e1426f58e644ab5ef2d67f113fae076403e1cfb1d42a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_518aded4702524772197e1426f58e644ab5ef2d67f113fae076403e1cfb1d42a->enter($__internal_518aded4702524772197e1426f58e644ab5ef2d67f113fae076403e1cfb1d42a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_64945fd63a31656c993c41185c708b5401a9147a4d432408dade440bf4e5176b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64945fd63a31656c993c41185c708b5401a9147a4d432408dade440bf4e5176b->enter($__internal_64945fd63a31656c993c41185c708b5401a9147a4d432408dade440bf4e5176b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 13
        echo "    <div id=\"job\">
      <h1>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
        echo "</h1>
      <h2>";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "location", array()), "html", null, true);
        echo "</h2>
      <h3>
        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "position", array()), "html", null, true);
        echo "
        <small> - ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "type", array()), "html", null, true);
        echo "</small>
      </h3>
 
      ";
        // line 21
        if ($this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array())) {
            // line 22
            echo "        <div class=\"logo\">
          <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "url", array()), "html", null, true);
            echo "\">
            <img src=\"/uploads/jobs/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "logo", array()), "html", null, true);
            echo "\"
              alt=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "company", array()), "html", null, true);
            echo " logo\" />
          </a>
        </div>
      ";
        }
        // line 29
        echo " 
      <div class=\"description\">
        ";
        // line 31
        echo nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "description", array()), "html", null, true));
        echo "
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "howtoapply", array()), "html", null, true);
        echo "</p>
 
      <div class=\"meta\">
        <small>posted on ";
        // line 39
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "createdat", array()), "m/d/Y"), "html", null, true);
        echo "</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_edit", array("id" => $this->getAttribute((isset($context["job"]) ? $context["job"] : $this->getContext($context, "job")), "id", array()))), "html", null, true);
        echo "\">
          Edit
        </a>
      </div>
    </div>
";
        
        $__internal_64945fd63a31656c993c41185c708b5401a9147a4d432408dade440bf4e5176b->leave($__internal_64945fd63a31656c993c41185c708b5401a9147a4d432408dade440bf4e5176b_prof);

        
        $__internal_518aded4702524772197e1426f58e644ab5ef2d67f113fae076403e1cfb1d42a->leave($__internal_518aded4702524772197e1426f58e644ab5ef2d67f113fae076403e1cfb1d42a_prof);

    }

    public function getTemplateName()
    {
        return "job/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  161 => 39,  155 => 36,  147 => 31,  143 => 29,  136 => 25,  132 => 24,  128 => 23,  125 => 22,  123 => 21,  117 => 18,  113 => 17,  108 => 15,  104 => 14,  101 => 13,  92 => 12,  80 => 9,  75 => 8,  66 => 7,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    {{ job.company }} is looking for a {{ job.position }}
{% endblock %}

{% block stylesheets %}
  {{ parent() }}
  <link rel=\"stylesheet\" href=\"{{ asset('public/css/job.css') }}\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block content %}
    <div id=\"job\">
      <h1>{{ job.company }}</h1>
      <h2>{{ job.location }}</h2>
      <h3>
        {{ job.position }}
        <small> - {{ job.type }}</small>
      </h3>
 
      {% if job.logo %}
        <div class=\"logo\">
          <a href=\"{{ job.url }}\">
            <img src=\"/uploads/jobs/{{ job.logo }}\"
              alt=\"{{ job.company }} logo\" />
          </a>
        </div>
      {% endif %}
 
      <div class=\"description\">
        {{ job.description|nl2br }}
      </div>
 
      <h4>How to apply?</h4>
 
      <p class=\"how_to_apply\">{{ job.howtoapply }}</p>
 
      <div class=\"meta\">
        <small>posted on {{ job.createdat|date('m/d/Y') }}</small>
      </div>
 
      <div style=\"padding: 20px 0\">
        <a href=\"{{ path('job_edit', { 'id': job.id }) }}\">
          Edit
        </a>
      </div>
    </div>
{% endblock %}
", "job/show.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\job\\show.html.twig");
    }
}
