<?php

/* base.html.twig */
class __TwigTemplate_cacf579b6000f723f17482e8fbcf34b983262632f4c235fe52e12381e458265c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_596e4cad21eec0a731d33671b9b69a6368b70a05b56959df9b2e5c9dbe7dd96f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_596e4cad21eec0a731d33671b9b69a6368b70a05b56959df9b2e5c9dbe7dd96f->enter($__internal_596e4cad21eec0a731d33671b9b69a6368b70a05b56959df9b2e5c9dbe7dd96f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a32edbd32337dbb5af87b77046993a570ea591ab3627c3890f29cc794a2058b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a32edbd32337dbb5af87b77046993a570ea591ab3627c3890f29cc794a2058b2->enter($__internal_a32edbd32337dbb5af87b77046993a570ea591ab3627c3890f29cc794a2058b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <title>
      ";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 8
        echo "    </title>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 15
        echo "    <link rel=\"shortcut icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/favicon.ico"), "html", null, true);
        echo "\" />
  </head>
  <body>
    <div id=\"container\">
      <div id=\"header\">
        <div class=\"content\">
          <h1><a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_index");
        echo "\">
            <img src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/logo.jpg"), "html", null, true);
        echo "\" alt=\"Jobeet Job Board\" />
          </a></h1>
 
          <div id=\"sub_header\">
            <div class=\"post\">
              <h2>Ask for people</h2>
              <div>
                <a href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("job_new");
        echo "\">Post a Job</a>
              </div>
            </div>
 
            <div class=\"search\">
              <h2>Ask for a job dsggd</h2>
              <form action=\"\" method=\"get\">
                <input type=\"text\" name=\"keywords\" id=\"search_keywords\" />
                <input type=\"submit\" value=\"search\" />
                <div class=\"help\">
                  Enter some keywords (city, country, position, ...)
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
 
      <div id=\"content\">
        ";
        // line 48
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "FlashBag", array()), "get", array(0 => "notice"), "method")) {
            // line 49
            echo "          <div class=\"flash_notice\">
            ";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flash", array(0 => "notice"), "method"), "html", null, true);
            echo "
          </div>
        ";
        }
        // line 53
        echo " 
        ";
        // line 54
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "FlashBag", array()), "has", array(0 => "error"), "method")) {
            // line 55
            echo "          <div class=\"flash_error\">
            ";
            // line 56
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flash", array(0 => "error"), "method"), "html", null, true);
            echo "
          </div>
        ";
        }
        // line 59
        echo " 
        <div class=\"content\">
            ";
        // line 61
        $this->displayBlock('content', $context, $blocks);
        // line 63
        echo "        </div>
      </div>
 
      <div id=\"footer\">
        <div class=\"content\">
          <span class=\"symfony\">
            <img src=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/jobeet-mini.png"), "html", null, true);
        echo "\" />
            powered by <a href=\"http://www.symfony.com/\">
              <img src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/images/symfony.gif"), "html", null, true);
        echo "\" alt=\"symfony framework\" />
            </a>
          </span>
          <ul>
            <li><a href=\"\">About Jobeet</a></li>
            <li class=\"feed\"><a href=\"\">Full feed</a></li>
            <li><a href=\"\">Jobeet API</a></li>
            <li class=\"last\"><a href=\"\">Affiliates</a></li>
          </ul>
        </div>
      </div>
    </div>
  </body>
</html>
";
        
        $__internal_596e4cad21eec0a731d33671b9b69a6368b70a05b56959df9b2e5c9dbe7dd96f->leave($__internal_596e4cad21eec0a731d33671b9b69a6368b70a05b56959df9b2e5c9dbe7dd96f_prof);

        
        $__internal_a32edbd32337dbb5af87b77046993a570ea591ab3627c3890f29cc794a2058b2->leave($__internal_a32edbd32337dbb5af87b77046993a570ea591ab3627c3890f29cc794a2058b2_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_2bfc34eff943520e3a0a68660d1a309a0a4611c6b3394cdb8c57939e445f3896 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2bfc34eff943520e3a0a68660d1a309a0a4611c6b3394cdb8c57939e445f3896->enter($__internal_2bfc34eff943520e3a0a68660d1a309a0a4611c6b3394cdb8c57939e445f3896_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fc524345fa934b06fd4e39e3936f73533013de893b028e045d449c2afeb37fa8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc524345fa934b06fd4e39e3936f73533013de893b028e045d449c2afeb37fa8->enter($__internal_fc524345fa934b06fd4e39e3936f73533013de893b028e045d449c2afeb37fa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 6
        echo "        Jobeet - Your best job board
      ";
        
        $__internal_fc524345fa934b06fd4e39e3936f73533013de893b028e045d449c2afeb37fa8->leave($__internal_fc524345fa934b06fd4e39e3936f73533013de893b028e045d449c2afeb37fa8_prof);

        
        $__internal_2bfc34eff943520e3a0a68660d1a309a0a4611c6b3394cdb8c57939e445f3896->leave($__internal_2bfc34eff943520e3a0a68660d1a309a0a4611c6b3394cdb8c57939e445f3896_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ea9476c1c37ca0acd0ca91ac01b6127ba8cf4f40c67a023edd0a5f86bb4cc59e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ea9476c1c37ca0acd0ca91ac01b6127ba8cf4f40c67a023edd0a5f86bb4cc59e->enter($__internal_ea9476c1c37ca0acd0ca91ac01b6127ba8cf4f40c67a023edd0a5f86bb4cc59e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_7e8e3349eb75677dd8b1bd9ad66ca3657363e9a1e97183eb9970ef86735792ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e8e3349eb75677dd8b1bd9ad66ca3657363e9a1e97183eb9970ef86735792ba->enter($__internal_7e8e3349eb75677dd8b1bd9ad66ca3657363e9a1e97183eb9970ef86735792ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 11
        echo "      <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/main.css"), "html", null, true);
        echo "\" type=\"text/css\" media=\"all\" />
    ";
        
        $__internal_7e8e3349eb75677dd8b1bd9ad66ca3657363e9a1e97183eb9970ef86735792ba->leave($__internal_7e8e3349eb75677dd8b1bd9ad66ca3657363e9a1e97183eb9970ef86735792ba_prof);

        
        $__internal_ea9476c1c37ca0acd0ca91ac01b6127ba8cf4f40c67a023edd0a5f86bb4cc59e->leave($__internal_ea9476c1c37ca0acd0ca91ac01b6127ba8cf4f40c67a023edd0a5f86bb4cc59e_prof);

    }

    // line 13
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a625fb5049d1e758f72ca8a96458906340101502f5913526bde314395c8d55c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a625fb5049d1e758f72ca8a96458906340101502f5913526bde314395c8d55c2->enter($__internal_a625fb5049d1e758f72ca8a96458906340101502f5913526bde314395c8d55c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_7285a058c72499ba3a4b7f664a939a9079114efca5e76f5408efdd91edc84266 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7285a058c72499ba3a4b7f664a939a9079114efca5e76f5408efdd91edc84266->enter($__internal_7285a058c72499ba3a4b7f664a939a9079114efca5e76f5408efdd91edc84266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 14
        echo "    ";
        
        $__internal_7285a058c72499ba3a4b7f664a939a9079114efca5e76f5408efdd91edc84266->leave($__internal_7285a058c72499ba3a4b7f664a939a9079114efca5e76f5408efdd91edc84266_prof);

        
        $__internal_a625fb5049d1e758f72ca8a96458906340101502f5913526bde314395c8d55c2->leave($__internal_a625fb5049d1e758f72ca8a96458906340101502f5913526bde314395c8d55c2_prof);

    }

    // line 61
    public function block_content($context, array $blocks = array())
    {
        $__internal_6733718e06ba6d921966bbbb26a16c4d0c17e3b1d950906d78b9319725ef9de7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6733718e06ba6d921966bbbb26a16c4d0c17e3b1d950906d78b9319725ef9de7->enter($__internal_6733718e06ba6d921966bbbb26a16c4d0c17e3b1d950906d78b9319725ef9de7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_208618200773974c9ffd5442bfc914e02a548e72e26e38b05a8997de575ea410 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_208618200773974c9ffd5442bfc914e02a548e72e26e38b05a8997de575ea410->enter($__internal_208618200773974c9ffd5442bfc914e02a548e72e26e38b05a8997de575ea410_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 62
        echo "            ";
        
        $__internal_208618200773974c9ffd5442bfc914e02a548e72e26e38b05a8997de575ea410->leave($__internal_208618200773974c9ffd5442bfc914e02a548e72e26e38b05a8997de575ea410_prof);

        
        $__internal_6733718e06ba6d921966bbbb26a16c4d0c17e3b1d950906d78b9319725ef9de7->leave($__internal_6733718e06ba6d921966bbbb26a16c4d0c17e3b1d950906d78b9319725ef9de7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  231 => 62,  222 => 61,  212 => 14,  203 => 13,  190 => 11,  181 => 10,  170 => 6,  161 => 5,  136 => 71,  131 => 69,  123 => 63,  121 => 61,  117 => 59,  111 => 56,  108 => 55,  106 => 54,  103 => 53,  97 => 50,  94 => 49,  92 => 48,  70 => 29,  60 => 22,  56 => 21,  46 => 15,  43 => 13,  41 => 10,  37 => 8,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <title>
      {% block title %}
        Jobeet - Your best job board
      {% endblock %}
    </title>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    {% block stylesheets %}
      <link rel=\"stylesheet\" href=\"{{ asset('public/css/main.css') }}\" type=\"text/css\" media=\"all\" />
    {% endblock %}
    {% block javascripts %}
    {% endblock %}
    <link rel=\"shortcut icon\" href=\"{{ asset('public/images/favicon.ico') }}\" />
  </head>
  <body>
    <div id=\"container\">
      <div id=\"header\">
        <div class=\"content\">
          <h1><a href=\"{{ path('job_index') }}\">
            <img src=\"{{ asset('public/images/logo.jpg') }}\" alt=\"Jobeet Job Board\" />
          </a></h1>
 
          <div id=\"sub_header\">
            <div class=\"post\">
              <h2>Ask for people</h2>
              <div>
                <a href=\"{{ path('job_new') }}\">Post a Job</a>
              </div>
            </div>
 
            <div class=\"search\">
              <h2>Ask for a job dsggd</h2>
              <form action=\"\" method=\"get\">
                <input type=\"text\" name=\"keywords\" id=\"search_keywords\" />
                <input type=\"submit\" value=\"search\" />
                <div class=\"help\">
                  Enter some keywords (city, country, position, ...)
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
 
      <div id=\"content\">
        {% if app.session.FlashBag.get('notice') %}
          <div class=\"flash_notice\">
            {{ app.session.flash('notice') }}
          </div>
        {% endif %}
 
        {% if app.session.FlashBag.has('error') %}
          <div class=\"flash_error\">
            {{ app.session.flash('error') }}
          </div>
        {% endif %}
 
        <div class=\"content\">
            {% block content %}
            {% endblock %}
        </div>
      </div>
 
      <div id=\"footer\">
        <div class=\"content\">
          <span class=\"symfony\">
            <img src=\"{{ asset('public/images/jobeet-mini.png') }}\" />
            powered by <a href=\"http://www.symfony.com/\">
              <img src=\"{{ asset('public/images/symfony.gif') }}\" alt=\"symfony framework\" />
            </a>
          </span>
          <ul>
            <li><a href=\"\">About Jobeet</a></li>
            <li class=\"feed\"><a href=\"\">Full feed</a></li>
            <li><a href=\"\">Jobeet API</a></li>
            <li class=\"last\"><a href=\"\">Affiliates</a></li>
          </ul>
        </div>
      </div>
    </div>
  </body>
</html>
", "base.html.twig", "D:\\CURS WEB DEVELOPER\\UwAmp\\www\\jobeet\\app\\Resources\\views\\base.html.twig");
    }
}
