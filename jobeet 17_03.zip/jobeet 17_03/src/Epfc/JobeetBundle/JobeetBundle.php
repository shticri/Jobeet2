<?php

namespace Epfc\JobeetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class JobeetBundle extends Bundle
{
}
